// PO-TION: eigenes Fenster (Electron). Startet den lokalen Dienst und zeigt die Oberfläche.
// Diese Datei gehört zum Code-Paket und kommt mit kleinen Updates mit. Geladen wird sie vom Starter (main.js).
const { app, BrowserWindow, shell, Menu, nativeTheme, dialog, globalShortcut, systemPreferences, screen, Notification } = require("electron");
const { spawn, execFile } = require("child_process");
const path = require("path");
const fs = require("fs");
const os = require("os");
const http = require("http");

const PORT = 4317;
const URL = `http://127.0.0.1:${PORT}`;
const P = global.POTION; // vom Starter: welcher Code-Stand, welche Laufzeit
const VERSION = P.core.v;
const SUP = P.sup;
let win = null;
let server = null;
let quitting = false;

// Links im Standardbrowser öffnen und den Browser nach vorne holen.
// shell.openExternal lässt ihn auf dem Mac manchmal im Hintergrund, "open -a" aktiviert ihn zuverlässig.
function openLink(url) {
  if (/^x-apple\.systempreferences:/i.test(url)) return void shell.openExternal(url);
  if (!/^(https?|mailto):/i.test(url)) return;
  if (process.platform !== "darwin") return void shell.openExternal(url);
  let browser = "";
  try { browser = app.getApplicationNameForProtocol(url.startsWith("mailto:") ? "mailto:" : "https://") || ""; } catch {}
  const args = browser ? ["-a", browser, url] : [url];
  execFile("/usr/bin/open", args, (err) => { if (err) shell.openExternal(url, { activate: true }); });
}

if (!app.requestSingleInstanceLock()) app.quit();
app.on("second-instance", () => { if (win) { if (win.isMinimized()) win.restore(); win.show(); win.focus(); } });

function get(p, timeout = 1500) {
  return new Promise((resolve) => {
    const req = http.get(URL + p, { timeout }, (res) => {
      let body = "";
      res.on("data", (c) => (body += c));
      res.on("end", () => { try { resolve(JSON.parse(body)); } catch { resolve(null); } });
    });
    req.on("error", () => resolve(null));
    req.on("timeout", () => { req.destroy(); resolve(null); });
  });
}
function post(p) {
  return new Promise((resolve) => {
    const req = http.request(URL + p, { method: "POST", headers: { "x-crxs": "1" }, timeout: 2000 }, (res) => { res.resume(); res.on("end", resolve); });
    req.on("error", resolve); req.on("timeout", () => { req.destroy(); resolve(); });
    req.end();
  });
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** Dienst sicherstellen: läuft eine andere Version, wird sie abgelöst */
async function ensureServer() {
  const h = await get("/api/health");
  if (h && h.version === VERSION) return true;
  if (h) { await post("/api/quit"); await sleep(1200); }
  fs.mkdirSync(SUP, { recursive: true });
  const log = fs.openSync(path.join(SUP, "crxs.log"), "a");
  fs.writeSync(log, `\n[${new Date().toISOString()}] Starte Dienst ${VERSION} aus ${P.core.dir}\n`);
  server = spawn(P.bun, [path.join(P.core.dir, "server.js")], {
    cwd: P.core.dir, detached: true, stdio: ["ignore", log, log],
    env: { ...process.env, POTION_APP_PATH: appBundlePath(), POTION_SHELL: "electron", POTION_RUNTIME: P.runtime, POTION_CORE_ROOT: P.coreRoot, BUN_INSTALL_CACHE_DIR: path.join(SUP, ".bun-cache") },
  });
  server.unref();
  for (let i = 0; i < 100; i++) {
    const r = await get("/api/health");
    if (r && r.version === VERSION) return true;
    await sleep(200);
  }
  return false;
}
function appBundlePath() {
  // .../PO-TION.app/Contents/Resources/app -> .../PO-TION.app
  return path.resolve(process.resourcesPath, "..", "..");
}

function bg() { return nativeTheme.shouldUseDarkColors ? "#0E0A14" : "#F6F3F9"; }

async function createWindow() {
  win = new BrowserWindow({
    width: 1440, height: 920, minWidth: 900, minHeight: 640,
    title: "PO-TION", backgroundColor: bg(), show: false,
    titleBarStyle: "hiddenInset", trafficLightPosition: { x: 18, y: 22 },
    webPreferences: { contextIsolation: true, sandbox: true, spellcheck: true },
  });
  win.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(`<html><body style="margin:0;background:${bg()};font:14px -apple-system;color:#8E859D;display:grid;place-items:center;height:100vh;-webkit-app-region:drag">PO-TION startet …</body></html>`)}`);
  win.once("ready-to-show", () => win.show());
  // Externe Links im Standardbrowser öffnen
  win.webContents.setWindowOpenHandler(({ url }) => { if (!url.startsWith(URL)) openLink(url); return { action: "deny" }; });
  win.webContents.on("will-navigate", (e, url) => { if (!url.startsWith(URL) && !url.startsWith("data:")) { e.preventDefault(); openLink(url); } });
  win.on("close", (e) => { if (!quitting && process.platform === "darwin") { e.preventDefault(); win.hide(); } });
  const ok = await ensureServer();
  if (!ok && P.fallback) {
    // Neuer Code-Stand startet nicht: zurück auf den Stand, der mit der App kam
    P.fallback(`Dienst ${VERSION} hat nicht geantwortet`);
    return;
  }
  if (!ok) {
    dialog.showErrorBox("PO-TION startet nicht", `Der lokale Dienst antwortet nicht.\nDetails: ${path.join(SUP, "crxs.log")}`);
    return;
  }
  win.loadURL(URL + "/?shell=electron");
}

function buildMenu() {
  const t = [
    { label: "PO-TION", submenu: [
      { role: "about", label: "Über PO-TION" },
      { type: "separator" },
      { label: "Einstellungen …", accelerator: "Cmd+,", click: () => { win?.show(); win?.webContents.executeJavaScript('location.hash = "#/einstellungen"'); } },
      { type: "separator" },
      { role: "hide", label: "PO-TION ausblenden" }, { role: "hideOthers", label: "Andere ausblenden" }, { role: "unhide", label: "Alle einblenden" },
      { type: "separator" },
      { role: "quit", label: "PO-TION beenden" },
    ] },
    { label: "Bearbeiten", submenu: [
      { role: "undo", label: "Widerrufen" }, { role: "redo", label: "Wiederholen" }, { type: "separator" },
      { role: "cut", label: "Ausschneiden" }, { role: "copy", label: "Kopieren" }, { role: "paste", label: "Einsetzen" }, { role: "selectAll", label: "Alles auswählen" },
    ] },
    { label: "Darstellung", submenu: [
      { role: "reload", label: "Neu laden" }, { type: "separator" },
      { role: "resetZoom", label: "Originalgröße" }, { role: "zoomIn", label: "Vergrößern" }, { role: "zoomOut", label: "Verkleinern" },
      { type: "separator" }, { role: "togglefullscreen", label: "Vollbild" },
      { type: "separator" }, { role: "toggleDevTools", label: "Entwicklerwerkzeuge" },
    ] },
    { label: "Fenster", submenu: [{ role: "minimize", label: "Im Dock ablegen" }, { role: "zoom", label: "Zoomen" }, { role: "front", label: "Alle nach vorne bringen" }] },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(t));
}

// ---------- Screenshot per globalem Kürzel ----------
// Bereich wählen wie mit ⌘⇧4 (macOS "screencapture"), dann kleines Fenster zum Zuordnen.
let capKey = null, capBusy = false, capWin = null;
function postJson(p, body) {
  return new Promise((resolve) => {
    const data = Buffer.from(JSON.stringify(body || {}));
    const req = http.request(URL + p, { method: "POST", headers: { "x-crxs": "1", "Content-Type": "application/json", "Content-Length": data.length }, timeout: 5000 }, (res) => {
      let b = ""; res.on("data", (c) => (b += c)); res.on("end", () => { try { resolve(JSON.parse(b)); } catch { resolve(null); } });
    });
    req.on("error", () => resolve(null)); req.on("timeout", () => { req.destroy(); resolve(null); });
    req.end(data);
  });
}
async function syncCaptureShortcut() {
  const c = await get("/api/capture/config");
  if (!c) return;
  const want = c.shortcut || "";
  if (want === capKey) return;
  if (capKey) { try { globalShortcut.unregister(capKey); } catch {} }
  capKey = null;
  let ok = true;
  if (want) {
    try { ok = globalShortcut.register(want, () => startCapture()); } catch { ok = false; }
    if (ok) capKey = want;
  }
  postJson("/api/capture/state", { shortcut: want, ok });
}
async function startCapture() {
  if (capBusy || process.platform !== "darwin") return;
  capBusy = true;
  try {
    const st = systemPreferences.getMediaAccessStatus("screen");
    if (st === "denied" || st === "restricted") {
      const r = await dialog.showMessageBox({ type: "info", buttons: ["Systemeinstellungen öffnen", "Abbrechen"], defaultId: 0, message: "PO-TION braucht die Freigabe „Bildschirmaufnahme“",
        detail: "Sonst sieht der Screenshot nur den Schreibtisch. Schalte PO-TION unter Datenschutz & Sicherheit → Bildschirm- & Systemaudioaufnahme ein und starte PO-TION danach neu." });
      if (r.response === 0) shell.openExternal("x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture");
      return;
    }
    const cfg = await get("/api/capture/config");
    if (!cfg || !cfg.dir) return;
    fs.mkdirSync(cfg.dir, { recursive: true });
    const file = path.join(cfg.dir, `cap-${Date.now()}.png`);
    // -i: Bereich wählen (Leertaste wechselt zu Fenster), -x: ohne Ton
    await new Promise((res) => execFile("/usr/sbin/screencapture", ["-i", "-x", "-t", "png", file], () => res()));
    if (!fs.existsSync(file) || fs.statSync(file).size < 100) return; // mit Esc abgebrochen
    const r = await postJson("/api/capture/new", { path: file });
    if (r && r.token) openCaptureWindow(r.token);
  } finally { capBusy = false; }
}
function openCaptureWindow(token) {
  if (capWin && !capWin.isDestroyed()) capWin.close();
  const area = screen.getDisplayNearestPoint(screen.getCursorScreenPoint()).workArea;
  const W = 600, H = 640;
  capWin = new BrowserWindow({
    width: W, height: H, x: Math.round(area.x + (area.width - W) / 2), y: Math.round(area.y + Math.max(20, (area.height - H) / 3)),
    type: "panel", resizable: false, minimizable: false, maximizable: false, fullscreenable: false, alwaysOnTop: true,
    titleBarStyle: "hidden", backgroundColor: nativeTheme.shouldUseDarkColors ? "#181320" : "#FBF9FD", show: false, title: "Screenshot ablegen",
    webPreferences: { contextIsolation: true, sandbox: true, spellcheck: true },
  });
  try { capWin.setWindowButtonVisibility(false); } catch {}
  try { capWin.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true, skipTransformProcessType: true }); } catch {}
  capWin.webContents.setWindowOpenHandler(({ url }) => { openLink(url); return { action: "deny" }; });
  capWin.loadURL(`${URL}/capture?token=${encodeURIComponent(token)}`);
  capWin.once("ready-to-show", () => { capWin.show(); capWin.focus(); });
  capWin.on("closed", () => { capWin = null; });
}

// ---------- Erinnerungen vor Fristen (Mac-Mitteilung) ----------
const shown = new Set();
async function pullReminders() {
  const r = await postJson("/api/reminders/pull", {});
  for (const x of (r && r.reminders) || []) {
    const key = `${x.identifier}|${x.date}|${x.time}`;
    if (shown.has(key) || !Notification.isSupported()) continue;
    shown.add(key);
    const n = new Notification({
      title: x.minutes > 0 ? `In ${x.minutes} min fällig · ${x.time} Uhr` : `Jetzt fällig · ${x.time} Uhr`,
      body: `${x.identifier} ${x.title}`,
      silent: false,
    });
    n.on("click", () => {
      if (!win) return;
      if (win.isMinimized()) win.restore();
      win.show(); win.focus();
      win.webContents.executeJavaScript(`location.hash = "#/t/${encodeURIComponent(x.identifier)}"`).catch(() => {});
    });
    n.show();
  }
}

app.setName("PO-TION");
app.setAboutPanelOptions({ applicationName: "PO-TION", applicationVersion: VERSION, copyright: "Lokal auf deinem Mac" });
app.whenReady().then(async () => {
  buildMenu();
  await createWindow();
  // Kürzel für Screenshots anmelden und Änderungen aus den Einstellungen übernehmen
  syncCaptureShortcut();
  setInterval(syncCaptureShortcut, 15000);
  // Erinnerungen abholen
  setTimeout(pullReminders, 5000);
  setInterval(pullReminders, 20000);
  app.on("browser-window-focus", () => syncCaptureShortcut());
});
app.on("activate", async () => {
  if (!win) return createWindow();
  win.show();
  // Dienst kann sich nach langer Pause beendet haben
  if (!(await get("/api/health"))) { await ensureServer(); win.loadURL(URL + "/?shell=electron"); }
});
app.on("before-quit", () => { quitting = true; });
app.on("will-quit", (e) => {
  try { globalShortcut.unregisterAll(); } catch {}
  if (app.__stopped) return;
  e.preventDefault();
  app.__stopped = true;
  post("/api/quit").finally(() => app.quit());
});
