// PO-TION Oberfläche · 14-history-archive.js
// Klassische Skripte im gemeinsamen globalen Bereich, Reihenfolge laut ui/js (Dateiname). Start in 99-boot.js.
"use strict";
// ---------- Verlauf ----------
const HIST_ICON = { create: "✦", state: "→", done: "✓", prio: "!", due: "◷", title: "T", project: "▤", milestone: "⚑", check: "✓", uncheck: "○", add: "+", remove: "−", notes: "✎", file: "📎", jira: "J", label: "#", archive: "⌫", restore: "↺", comment: "❝", ai: "✦", nudge: "↗", estimate: "⏱" };
function dayLabel(iso) {
  const d = new Date(iso), t = new Date();
  const k = (x) => x.toDateString();
  const y = new Date(t); y.setDate(t.getDate() - 1);
  if (k(d) === k(t)) return "Heute";
  if (k(d) === k(y)) return "Gestern";
  return d.toLocaleDateString("de-DE", { weekday: "short", day: "numeric", month: "long", year: d.getFullYear() !== t.getFullYear() ? "numeric" : undefined });
}
function renderHistory(entries, what) {
  if (!entries.length) return `<div class="sec-head" style="padding:0"><h2>Verlauf</h2></div><p class="muted hist-empty">Noch keine Änderungen festgehalten. Ab jetzt landet hier jede Änderung an ${what === "Projekt" ? "diesem Projekt" : "dieser Aufgabe"}.</p>`;
  const groups = [];
  for (const e of entries) {
    const l = dayLabel(e.at);
    if (!groups.length || groups[groups.length - 1].label !== l) groups.push({ label: l, items: [] });
    groups[groups.length - 1].items.push(e);
  }
  const LIMIT = 14;
  let n = 0;
  const body = groups.map((g) => `<div class="hist-day"><div class="hist-dlabel">${esc(g.label)}</div><ol>${g.items.map((e) => {
    n++;
    const t = new Date(e.at).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" });
    const txt = esc(e.text).replace(/\b([A-Z]{2,6}-\d+)\b/g, (m) => e.ref === m || /^[A-Z]{2,6}-\d+$/.test(m) ? `<button class="linkbtn idf" data-open="${m}">${m}</button>` : m);
    if (e.comment) return `<li class="hist-item hi-comment is-cmt${n > LIMIT ? " more" : ""}"><span class="hist-ico" aria-hidden="true">❝</span><div class="hist-bubble cm-item${e.editable ? " mine" : ""}" ${e.id ? `data-cm-id="${esc(e.id)}"` : ""}><div class="hb-head"><b>${esc(e.who || "Du")}</b>${srcBadge(e)}${(e.alsoJira || []).map((j) => `<a class="cm-src jira" href="${esc(j.url)}" target="_blank" rel="noopener" title="Auch in Jira gepostet">+ Jira ${esc(j.key)}</a>`).join("")}${e.edited ? `<span class="muted">bearbeitet</span>` : ""}${e.editable && e.id ? `<span class="cm-acts"><button class="linkbtn" data-cm-edit>Bearbeiten</button><button class="linkbtn danger" data-cm-del>Löschen</button></span>` : ""}<time>${t}</time></div><div class="hb-body cm-body">${fmtComment(e.text)}</div></div></li>`;
    return `<li class="hist-item hi-${e.icon}${n > LIMIT ? " more" : ""}"><span class="hist-ico" aria-hidden="true">${HIST_ICON[e.icon] || "•"}</span><span class="hist-text">${txt}</span><span class="hist-meta">${e.source === "linear" ? `<span class="hist-src">Linear${e.who ? " · " + esc(e.who) : ""}</span>` : `<span class="hist-src potion">PO-TION</span>`}<time>${t}</time></span></li>`;
  }).join("")}</ol></div>`).join("");
  const nc = entries.filter((e) => e.comment).length;
  return `<div class="sec-head" style="padding:0"><h2>Verlauf</h2>${nc ? `<div class="seg hist-seg" role="tablist"><button class="seg-b on" data-hist-f="all">Alles</button><button class="seg-b" data-hist-f="cmt">Kommentare ${nc}</button><button class="seg-b" data-hist-f="chg">Änderungen</button></div>` : `<span>${entries.length} ${entries.length === 1 ? "Änderung" : "Änderungen"}</span>`}</div>
    <div class="hist-list${entries.length > LIMIT ? " clipped" : ""}">${body}</div>
    ${entries.length > LIMIT ? `<button class="linkbtn hist-all" data-act="hist-all">Alle ${entries.length} anzeigen</button>` : ""}`;
}
async function loadIssueHistory(id) {
  const box = $("#hist");
  try {
    const list = await api("/api/issues/" + encodeURIComponent(id) + "/history");
    if (S.detail?.identifier === id && $("#hist")) $("#hist").innerHTML = renderHistory(list, "Aufgabe");
  } catch (e) { if (box) box.innerHTML = `<div class="sec-head" style="padding:0"><h2>Verlauf</h2></div><p class="err">${esc(e.message)}</p>`; }
}

// ---------- Archiv ----------
async function renderArchive() {
  S.view = "archive";
  setViewTheme("archive");
  renderDock();
  const tab = location.hash.includes("projekte") ? "projects" : "tasks";
  app.innerHTML = topbar() + `<main class="archive">
    <header class="ar-head"><span class="kind-badge arch">${I.archive}Archiv</span><h1>Abgeschlossen</h1><p>Erledigte, verworfene und gelöschte Aufgaben und Projekte. Alles bleibt in Linear und lässt sich wieder öffnen.</p></header>
    <div class="ar-bar">
      <div class="seg" role="tablist"><a class="seg-b${tab === "tasks" ? " on" : ""}" href="#/archiv" role="tab">Aufgaben</a><a class="seg-b${tab === "projects" ? " on" : ""}" href="#/archiv/projekte" role="tab">Projekte</a></div>
      <label class="ar-search">${I.search}<input id="ar-q" placeholder="Im Archiv filtern" autocomplete="off"></label>
    </div>
    <div id="ar-list" class="ar-list"><div class="ar-skel"></div><div class="ar-skel"></div><div class="ar-skel"></div></div>
  </main>`;
  S.archive = { tab, items: [], next: null };
  $("#ar-q").addEventListener("input", () => drawArchive());
  await loadArchive();
}
async function loadArchive(more = false) {
  const A = S.archive;
  try {
    if (A.tab === "tasks") {
      const r = await api("/api/archive/tasks" + (more && A.next ? "?after=" + encodeURIComponent(A.next) : ""));
      A.items = more ? A.items.concat(r.items) : r.items;
      A.next = r.next;
    } else {
      A.items = (await api("/api/archive/projects")).map((p) => ({ ...p, at: p.archivedAt || p.completedAt || p.updatedAt }));
      A.next = null;
    }
    drawArchive();
  } catch (e) { $("#ar-list").innerHTML = `<p class="err">${esc(e.message)}</p>`; }
}
function drawArchive() {
  const A = S.archive, box = $("#ar-list");
  if (!box) return;
  const q = ($("#ar-q")?.value || "").toLowerCase().trim();
  const list = A.items.filter((x) => !q || `${x.identifier || ""} ${x.title || x.name} ${x.project || ""}`.toLowerCase().includes(q));
  if (!list.length) { box.innerHTML = `<p class="muted ar-empty">${q ? "Nichts gefunden." : A.tab === "tasks" ? "Noch keine erledigten Aufgaben." : "Noch keine abgeschlossenen Projekte."}</p>`; return; }
  const groups = [];
  for (const x of list) {
    const m = new Date(x.at).toLocaleDateString("de-DE", { month: "long", year: "numeric" });
    if (!groups.length || groups[groups.length - 1].m !== m) groups.push({ m, items: [] });
    groups[groups.length - 1].items.push(x);
  }
  const KL = { done: "Erledigt", canceled: "Verworfen", archived: "Gelöscht" };
  let i = 0;
  box.innerHTML = groups.map((g) => `<section class="ar-month"><h2>${esc(g.m)}</h2><div class="panel">${g.items.map((x) => {
    const d = new Date(x.at).toLocaleDateString("de-DE", { day: "numeric", month: "numeric" });
    i++;
    if (A.tab === "tasks") return `<div class="ar-row" style="--i:${Math.min(i, 20)}"><button class="ar-main" data-open="${esc(x.identifier)}"><span class="ar-ico k-${x.kind}">${x.kind === "done" ? I.check("currentColor", 12) : x.kind === "canceled" ? I.x : I.archive}</span><span class="idf">${esc(x.identifier)}</span><span class="ar-title">${esc(x.title)}</span>${x.project ? `<span class="ar-proj">${I.proj}${esc(x.project)}</span>` : ""}</button><span class="ar-state k-${x.kind}">${KL[x.kind]}</span><time>${d}</time><button class="btn small ar-reopen" data-reopen="${esc(x.id)}" data-archived="${x.kind === "archived" ? 1 : 0}">Wieder öffnen</button></div>`;
    return `<div class="ar-row" style="--i:${Math.min(i, 20)}"><span class="ar-main"><span class="ar-ico k-done">${I.proj}</span><span class="ar-title">${esc(x.name)}</span></span><span class="ar-state k-${x.archivedAt ? "archived" : "done"}">${x.archivedAt ? "Archiviert" : "Abgeschlossen"}</span><time>${d}</time>${x.archivedAt ? `<button class="btn small" data-prestore="${esc(x.id)}">Zurückholen</button>` : `<a class="btn small" href="#/p/${esc(x.id)}" style="text-decoration:none">Öffnen</a>`}<a class="icon-btn sm" href="${esc(x.url)}" target="_blank" rel="noopener" aria-label="In Linear öffnen">${I.out}</a></div>`;
  }).join("")}</div></section>`).join("") + (A.next ? `<button class="btn ar-more" data-act="ar-more">Ältere laden</button>` : "");
}
