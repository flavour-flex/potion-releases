// PO-TION Oberfläche · 07-project.js
// Klassische Skripte im gemeinsamen globalen Bereich, Reihenfolge laut ui/js (Dateiname). Start in 99-boot.js.
"use strict";
// ---------- Projektseite ----------
async function openProject(id) {
  S.view = "project";
  if (!S.project || S.project.id !== id) app.innerHTML = topbar() + `<main class="wrap"><p class="muted">Lade Projekt…</p></main>`;
  try {
    S.project = await api("/api/projects/" + encodeURIComponent(id));
    S.loadedAt = Date.now();
  } catch (e) {
    app.innerHTML = topbar() + `<main class="wrap"><div class="hint">${esc(e.message)}</div></main>`;
    return;
  }
  renderProject();
}

function renderProject() {
  const p = S.project;
  const msClass = { reached: "ms-reached", soon: "ms-soon", late: "ms-late", planned: "" };
  const tagClass = { reached: "ok", soon: "hot", late: "hot", planned: "muted" };
  const ringFor = (k) => ({ done: "ring done", wait: "ring wait", started: "ring half", vendor: "ring vendor", review: "ring review", open: "ring", backlog: "ring dim" })[k] || "ring";
  const extFile = (n) => (n.split(".").pop() || "").toUpperCase().slice(0, 4);
  setViewTheme("project");
  app.innerHTML = `<header class="top"><div class="brand" style="gap:14px"><a class="brand-link mini" href="#/" aria-label="PO-TION Startseite">${FLASK(34)}</a>
      <button class="back" data-act="back">${I.back}Zurück</button>
      <span class="kind-badge proj">${I.proj}Projekt</span><span style="font-size:13.5px">${esc(p.name)}</span></div>
      ${hdrSearch()}<div class="top-right"><span id="model-pill">${modelPill()}</span>${p.url ? `<a href="${esc(p.url)}" target="_blank" rel="noopener" style="display:inline-flex;align-items:center;gap:6px;font-size:13px;text-decoration:none">In Linear öffnen ${I.out}</a>` : `<span class="local-tag" title="Liegt nur auf diesem Mac">${I.lock}lokal</span>`}${jiraBtn()}</div></header>
  <main class="wrap project">
    <section class="p-head p-hero">
      <div class="p-title"><div class="p-glyph" aria-hidden="true">${I.proj}</div><h1>${esc(p.name)}</h1>${p.description ? `<p>${esc(p.description)}</p>` : ""}<div class="tags p-tags">${p.targetDate ? `<span class="tag">Ziel ${esc(new Date(p.targetDate + "T12:00:00").toLocaleDateString("de-DE", { day: "2-digit", month: "2-digit", year: "numeric" }))}</span>` : ""}<span class="tag">${p.progress.done}/${p.progress.total} erledigt</span><button class="tag tag-more" data-more="project" aria-label="Umwandeln oder löschen" title="Umwandeln oder löschen">${I.more}</button></div></div>
      <div class="p-stats">
        <div class="stat"><small>Fortschritt</small><b>${p.progress.done} / ${p.progress.total}</b><span class="bar wide"><span style="width:${p.progress.pct}%"></span></span></div>
        <div class="stat"><small>Nächster Meilenstein</small><b class="sm">${esc(p.nextMilestone?.name || "–")}</b>${p.nextMilestone ? `<span class="${p.nextMilestone.soon ? "hot" : "muted"}" style="font-size:12.5px">${esc(p.nextMilestone.when)} · ${p.nextMilestone.open} offen</span>` : ""}</div>
        <div class="stat"><small>Hängt</small><b class="${p.stuckSummary.count ? "hot" : ""}">${p.stuckSummary.count}</b><span class="muted" style="font-size:12.5px">${p.stuckSummary.count ? `älteste ${p.stuckSummary.oldest} Tage` : "nichts blockiert"}</span></div>
      </div>
    </section>

    ${p.milestones.length ? `<section style="display:flex;flex-direction:column;gap:10px">
      <div class="sec-head"><h2>Meilensteine</h2><button class="linkbtn tl-open" data-timeline="">${I.flag}Zeitstrahl ansehen</button></div>
      <div class="ms-grid">${[...p.milestones].sort((a, b) => (a.dateRaw || "9999").localeCompare(b.dateRaw || "9999")).map((m) => `<button class="ms ${msClass[m.state]}" data-ms-open="${esc(m.id)}" title="Meilenstein öffnen">
        <span class="ms-top"><span class="muted">${esc(m.date)}</span><span class="ms-tr"><span class="${tagClass[m.state]}">${esc(m.tag)}</span><span class="ms-more" role="button" tabindex="0" data-more="ms" data-ms-id="${esc(m.id)}" aria-label="Meilenstein umwandeln oder löschen" title="Umwandeln oder löschen">${I.more}</span></span></span>
        <b>${esc(m.name)}</b><span class="bar wide"><span style="width:${m.pct}%"></span></span>
        <span class="muted" style="font-size:12.5px">${m.total ? `${m.done} von ${m.total} erledigt` : "noch keine Aufgaben"}</span></button>`).join("")}</div>
    </section>` : ""}

    <section class="p-layout">
      <div class="p-main">
        ${p.hint ? `<div class="hint">${I.spark}<span>${esc(p.hint)}</span></div>` : ""}
        ${renderFileTiles(p.files, "Ablage/" + p.name, "Dateien ins Fenster ziehen, PO-TION ordnet sie einer Aufgabe im Projekt zu")}
        <div class="p-notes">
          <div class="job-slot" id="job-slot"></div>
          <div class="sec-head"><h2>Projekt-Notizen</h2><span id="pnotes-state"></span></div>
          <div id="pnotes-host" class="notes-editor"></div>
        </div>
        <section class="cmts" id="cmts" data-target="p:${esc(p.id)}"></section>
        <section class="hist">${renderHistory(p.history || [], "Projekt")}</section>
      </div>

      <aside class="p-side">
        <div class="p-block">
          <div class="sec-head"><h2>Jetzt dran</h2><span>nach Dringlichkeit</span></div>
          ${p.now.length ? p.now.map((t) => `<button class="now-card" data-open="${esc(t.identifier)}">
            <span class="prio-dot u-${t.urgency}"></span>
            <span class="row-main"><span class="tc-title"><span class="idf">${esc(t.identifier)}</span><b>${esc(t.title)}</b></span><span class="row-meta">${esc(t.why)}</span></span>
            ${t.dueLabel ? `<span class="due ${t.urgency}">${esc(t.dueLabel)}</span>` : ""}</button>`).join("") : `<div class="panel empty">Nichts offen. Schreib unten, was als Nächstes ansteht.</div>`}
        </div>
        ${p.stuck.length ? `<div class="p-block">
          <div class="sec-head"><h2>Hängt</h2><span>liegt bei anderen</span></div>
          <div class="panel stuck">${p.stuck.map((x) => `<div class="stuck-row">
            <button class="row-main plain" data-open="${esc(x.identifier)}"><span class="tc-title"><span class="idf">${esc(x.identifier)}</span><b>${esc(x.title)}</b></span>${x.blocks ? `<span class="row-meta">${esc(x.blocks)}</span>` : ""}</button>
            <div class="stuck-meta"><span class="tag">${esc(x.who)}</span><span class="due urgent">${esc(x.since)}</span><button class="btn small" data-nudge="${esc(x.identifier)}">Nachhaken</button></div></div>`).join("")}</div>
        </div>` : ""}
        <div class="p-block">
          <div class="sec-head"><h2>Offene Entscheidungen</h2><span>${p.decisions.length}</span></div>
          ${p.decisions.length ? p.decisions.map((x) => `<button class="side-card" data-open="${esc(x.identifier)}"><b>${esc(x.title)}</b><span>${esc(x.identifier)} · ${esc(x.who)}</span></button>`).join("") : `<div class="side-card muted" style="font-size:13px">Keine. Schreib z. B. „Entscheiden: Connector oder API?“</div>`}
        </div>
        <div class="p-block">
          <div class="sec-head"><h2>Alle Aufgaben</h2><span>${p.milestones.length ? "nach Meilenstein" : ""}</span></div>
          <div class="panel">${p.groups.length ? p.groups.map((g) => `<div class="g-head"><span>${esc(g.name)}</span><span class="muted">${esc(g.count)}</span></div>
            ${g.items.map((i) => `<button class="g-row ${i.kind === "done" ? "is-done" : ""}" data-open="${esc(i.identifier)}"><span class="sel-box" data-sel="${esc(i.identifier)}" role="checkbox" aria-checked="false" aria-label="${esc(i.identifier)} auswählen" title="Auswählen (⇧ für Bereich)"></span><span class="${ringFor(i.kind)}"></span><span class="g-text"><span class="g-title">${esc(i.title)}</span><span class="g-sub"><span class="idf">${esc(i.identifier)}</span>${i.meta ? `<span>${esc(i.meta)}</span>` : ""}${i.decision ? `<span class="tag">Entscheidung</span>` : ""}${jiraBadges(i.jira)}</span></span></button>`).join("")}`).join("") : `<div class="empty">Noch keine Aufgaben im Projekt.</div>`}</div>
        </div>
      </aside>
    </section>
  </main>`;
  mountProjectNotes(p);
  loadComments("p:" + p.id);
  renderDock();
  watchJobs();
  if (S.pendingTimeline) { const ms = S.pendingTimeline; S.pendingTimeline = null; setTimeout(() => openTimeline(ms), 200); }
}

async function nudge(btn) {
  btn.disabled = true;
  try {
    const r = await api("/api/nudge", { method: "POST", body: { identifier: btn.dataset.nudge } });
    try { await navigator.clipboard.writeText(r.text); toast("Nachfrage-Text kopiert, Datum in der Aufgabe vermerkt"); }
    catch { toast("Datum vermerkt. Text: " + r.text); }
    btn.textContent = "Nachgehakt";
  } catch (e) {
    btn.disabled = false;
    toast(e.message);
  }
}

let projTimer = null;
function mountProjectNotes(p) {
  const host = $("#pnotes-host");
  if (S.projEditor && S.projEditor.id === p.id) { host.replaceWith(S.projEditor.el); return; }
  destroyProjectNotes();
  const ed = { id: p.id, el: host, handle: null, draft: undefined, saved: p.notes };
  S.projEditor = ed;
  const onChange = (md) => {
    ed.draft = md;
    const st = $("#pnotes-state"); if (st) st.textContent = "…";
    clearTimeout(projTimer);
    projTimer = setTimeout(flushProjectNotes, 1200);
  };
  if (window.crxsEditor) window.crxsEditor.mount(host, p.notes || "", onChange).then((h) => (ed.handle = h)).catch(() => mountPlainNotes(host, p.notes, onChange));
  else mountPlainNotes(host, p.notes, onChange);
}

async function flushProjectNotes() {
  clearTimeout(projTimer);
  const ed = S.projEditor;
  if (!ed || ed.draft === undefined || ed.draft === ed.saved) return;
  const v = ed.draft;
  try {
    await api("/api/projects/" + encodeURIComponent(ed.id), { method: "PATCH", body: { notes: v } });
    ed.saved = v;
    const st = $("#pnotes-state"); if (st && ed.draft === v) st.textContent = "gespeichert";
  } catch (e) { toast("Projekt-Notizen nicht gespeichert: " + e.message); }
}

function destroyProjectNotes() {
  flushProjectNotes();
  try { S.projEditor?.handle?.destroy(); } catch {}
  S.projEditor = null;
}

// ---------- KI im Hintergrund an dieser Aufgabe / diesem Projekt ----------
const JOBS = { handled: new Set(), shownDone: new Map() };
function jobKey() {
  if (S.view === "detail" && S.detail) return "i:" + S.detail.identifier;
  if (S.view === "project" && S.project) return "p:" + S.project.id;
  if (S.view === "milestone" && S.ms) return "m:" + S.ms.id;
  return null;
}
function watchJobs() {
  clearTimeout(watchJobs.t);
  const key = jobKey();
  if (!key) return;
  const tick = async () => {
    if (jobKey() !== key) return;
    let r;
    try { r = await api("/api/jobs?key=" + encodeURIComponent(key)); } catch { r = { jobs: [] }; }
    if (jobKey() !== key) return;
    let active = false;
    for (const j of r.jobs) {
      if (j.active) { active = true; continue; }
      // fertig geworden, nachdem diese Seite geladen wurde -> Notizen auffrischen
      if (!JOBS.handled.has(j.id) && j.endedAt > (S.loadedAt || 0) - 1500) {
        JOBS.handled.add(j.id);
        JOBS.shownDone.set(j.id, Date.now());
        if (j.ok && j.block) await applyJobResult(key, j).catch((e) => toast(e.message));
        else if (!j.ok) toast(j.message);
      }
    }
    drawJobs(r.jobs);
    watchJobs.t = setTimeout(tick, active ? 1200 : 5000);
  };
  tick();
}
function drawJobs(list) {
  const slot = $("#job-slot");
  if (!slot) return;
  const now = Date.now();
  const show = list.filter((j) => j.active || (JOBS.shownDone.has(j.id) && now - JOBS.shownDone.get(j.id) < 12000));
  slot.innerHTML = show.map((j) => j.active
    ? `<div class="job run" role="status"><span class="job-orb" aria-hidden="true"><i></i></span><div class="job-txt"><b>${esc(j.label)}</b><span>${esc(j.detail || "Startet …")}${j.elapsed >= 3 ? ` · ${j.elapsed} s` : ""}</span></div><span class="job-line" aria-hidden="true"></span></div>`
    : `<div class="job ${j.ok ? "ok" : "fail"}" role="status"><span class="job-orb" aria-hidden="true">${j.ok ? I.check("currentColor", 14) : "!"}</span><div class="job-txt"><b>${esc(j.ok ? "Fertig" : "Nicht geklappt")}</b><span>${esc(j.message || "")}</span></div></div>`).join("");
  // Dateikachel des Screenshots schimmern lassen, solange gelesen wird
  document.querySelectorAll(".file-tile.reading").forEach((t) => t.classList.remove("reading"));
  for (const j of list) if (j.active && j.file) document.querySelectorAll(".file-tile").forEach((t) => { if (t.title === j.file) t.classList.add("reading"); });
}
/** Zusammenfassung übernehmen, ohne eigene, noch ungespeicherte Notizen zu verlieren */
async function applyJobResult(key, j) {
  const head = j.block.split("\n")[0];
  const merge = (base) => (base.includes(head) ? base : (base.trim() ? base.trim() + "\n\n" : "") + j.block);
  if (key.startsWith("i:") && S.detail) {
    const id = S.detail.identifier;
    const ed = S.editor && S.editor.id === id ? S.editor : null;
    const dirty = !!ed && ed.draft !== undefined && ed.draft !== ed.saved;
    clearTimeout(notesTimer);
    let fresh = await api("/api/issues/" + encodeURIComponent(id));
    const want = merge(dirty ? ed.draft : fresh.notes || "");
    if (want !== (fresh.notes || "")) fresh = await api("/api/issues/" + encodeURIComponent(id), { method: "PATCH", body: { notes: want } });
    if (S.detail?.identifier !== id) return;
    try { S.editor?.handle?.destroy(); } catch {}
    S.editor = null;
    S.detail = fresh;
    S.loadedAt = Date.now();
    renderDetail();
  } else if (key.startsWith("p:") && S.project) {
    const id = S.project.id;
    const ed = S.projEditor && S.projEditor.id === id ? S.projEditor : null;
    const dirty = !!ed && ed.draft !== undefined && ed.draft !== ed.saved;
    clearTimeout(projTimer);
    let fresh = await api("/api/projects/" + encodeURIComponent(id));
    const want = merge(dirty ? ed.draft : fresh.notes || "");
    if (want !== (fresh.notes || "")) { await api("/api/projects/" + encodeURIComponent(id), { method: "PATCH", body: { notes: want } }); fresh = await api("/api/projects/" + encodeURIComponent(id)); }
    if (S.project?.id !== id) return;
    try { S.projEditor?.handle?.destroy(); } catch {}
    S.projEditor = null;
    S.project = fresh;
    S.loadedAt = Date.now();
    renderProject();
  }
  setTimeout(() => { const h = document.querySelector("#notes-host, #pnotes-host"); h?.classList.add("notes-flash"); setTimeout(() => h?.classList.remove("notes-flash"), 1800); }, 60);
}

// ---------- Notizen-Editor ----------
// Der Editor bleibt beim Neuzeichnen der Seite erhalten (Cursor, Undo), er wird nur umgehängt.
let notesTimer = null;

function mountNotes(d) {
  const host = $("#notes-host");
  if (S.editor && S.editor.id === d.identifier) {
    host.replaceWith(S.editor.el);
    return;
  }
  destroyNotes();
  const ed = { id: d.identifier, el: host, handle: null, draft: undefined };
  S.editor = ed;
  const onChange = (md) => {
    ed.draft = md;
    const st = $("#notes-state");
    if (st) st.textContent = "…";
    clearTimeout(notesTimer);
    notesTimer = setTimeout(() => flushNotes(), 1200);
  };
  if (window.crxsEditor) {
    window.crxsEditor.mount(host, d.notes || "", onChange).then((h) => (ed.handle = h)).catch((e) => {
      console.error(e);
      mountPlainNotes(host, d.notes, onChange);
    });
  } else mountPlainNotes(host, d.notes, onChange);
}

function mountPlainNotes(host, text, onChange) {
  host.innerHTML = `<label for="notes" class="sr">Notizen</label><textarea id="notes" class="notes" placeholder="Notizen, Kontext, Links …"></textarea>`;
  const ta = host.querySelector("textarea");
  ta.value = text || "";
  ta.addEventListener("input", () => onChange(ta.value));
}

function destroyNotes() {
  flushNotes();
  try { S.editor?.handle?.destroy(); } catch {}
  S.editor = null;
}

async function flushNotes() {
  clearTimeout(notesTimer);
  const ed = S.editor;
  if (!ed || ed.draft === undefined || ed.draft === ed.saved) return;
  const v = ed.draft;
  try {
    await api("/api/issues/" + encodeURIComponent(ed.id), { method: "PATCH", body: { notes: v } });
    ed.saved = v;
    if (S.detail?.identifier === ed.id) S.detail.notes = v;
    const st = $("#notes-state");
    if (st && ed.draft === v) st.textContent = "gespeichert";
  } catch (e) {
    toast("Notizen nicht gespeichert: " + e.message);
  }
}

async function patch(body, rerender = false) {
  try {
    const ed = S.editor;
    // ungespeicherte Notizen gleich mitschicken, damit nichts überschrieben wird
    if (ed && ed.id === S.detail.identifier && ed.draft !== undefined && ed.draft !== ed.saved && body.notes === undefined) {
      body.notes = ed.draft;
      ed.saved = ed.draft;
      clearTimeout(notesTimer);
    }
    const prev = S.detail, ident = prev.identifier;
    const d = await api("/api/issues/" + encodeURIComponent(ident), { method: "PATCH", body });
    S.detail = d;
    const back = undoPatchFor(body, prev);
    if (back) pushUndo(back.label, () => api("/api/issues/" + encodeURIComponent(ident), { method: "PATCH", body: back.body }));
    S.home = null;
    if (rerender) {
      renderDetail();
      if (body.addItem) $("#add-item")?.focus();
    }
  } catch (e) {
    toast(e.message);
    throw e;
  }
}

/** Gegenänderung für eine Detail-Änderung (für ⌘Z) */
function undoPatchFor(body, prev) {
  const k = Object.keys(body).filter((x) => x !== "notes");
  if (!k.length) return null;
  const b = {};
  let label = "";
  if ("title" in body) { b.title = prev.title; label = "Titel"; }
  if ("state" in body) { b.state = prev.kind; label = `Status (${prev.state})`; }
  if ("priority" in body) { b.priority = prev.priority; label = "Priorität"; }
  if ("due" in body || "dueTime" in body) { b.due = prev.due || null; b.dueTime = prev.dueTime || null; label = "Fälligkeit"; }
  if ("estimateMin" in body) { b.estimateMin = prev.estimateMin || null; label = "Schätzung"; }
  if ("project" in body) { b.project = prev.project || null; b.milestone = prev.milestone || null; label = "Projekt"; }
  if ("milestone" in body && !("project" in body)) { b.milestone = prev.milestone || null; label = "Meilenstein"; }
  if ("toggle" in body || "removeItem" in body || "addItem" in body || "setItems" in body) { b.setItems = prev.items.map((x) => ({ text: x.text, done: x.done })); label = "removeItem" in body ? "Checklisten-Punkt entfernen" : "addItem" in body ? "Checklisten-Punkt hinzufügen" : "Checkliste"; }
  return Object.keys(b).length ? { body: b, label: `${prev.identifier}: ${label}` } : null;
}
