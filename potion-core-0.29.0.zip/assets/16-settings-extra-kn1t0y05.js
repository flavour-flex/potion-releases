// PO-TION Oberfläche · 16-settings-extra.js
// Klassische Skripte im gemeinsamen globalen Bereich, Reihenfolge laut ui/js (Dateiname). Start in 99-boot.js.
"use strict";
// ---------- Erinnerungen (Einstellungen) ----------
async function loadReminders() {
  const box = $("#rem-box");
  if (!box) return;
  let c;
  try { c = await api("/api/reminders/config"); } catch (e) { box.innerHTML = `<p class="err">${esc(e.message)}</p>`; return; }
  const inApp = document.documentElement.classList.contains("electron");
  box.innerHTML = setRow("Vorlauf", `Gilt für Aufgaben mit Uhrzeit bei der Fälligkeit, z. B. „bis Freitag 14 Uhr“.${inApp ? "" : `<span class="cap-st">${statusDot("warn", "Mitteilungen gibt es nur in der PO-TION-App")}</span>`}`,
    `<div class="seg wide" role="radiogroup">${c.options.map((m) => `<label class="seg-b${c.lead === m ? " on" : ""}"><input type="radio" name="rem-lead" value="${m}" ${c.lead === m ? "checked" : ""}>${m ? m + " min vorher" : "Aus"}</label>`).join("")}</div>`);
  box.querySelectorAll("input[name=rem-lead]").forEach((r) => r.addEventListener("change", async () => {
    await api("/api/reminders/config", { method: "POST", body: { lead: Number(r.value) } }).catch((e) => toast(e.message));
    toast(Number(r.value) ? `Erinnerung ${r.value} min vor der Frist` : "Erinnerungen aus");
    loadReminders();
  }));
}

// ---------- Screenshots (Einstellungen) ----------
async function loadCapture() {
  const box = $("#cap-box");
  if (!box) return;
  let c;
  try { c = await api("/api/capture/config"); } catch (e) { box.innerHTML = `<p class="err">${esc(e.message)}</p>`; return; }
  const inApp = document.documentElement.classList.contains("electron");
  const st = c.state;
  const status = !c.shortcut ? statusDot("off", "Aus")
    : !inApp ? statusDot("warn", "Nur in der PO-TION-App, nicht im Browser")
    : st && st.shortcut === c.shortcut && !st.ok ? statusDot("err", "Von einer anderen App belegt, wähl ein anderes")
    : st && st.shortcut === c.shortcut ? statusDot("ok", "Aktiv") : statusDot("warn", "Wird gleich übernommen");
  box.innerHTML = `
    ${setRow("Tastenkürzel", `Danach wählst du einen Bereich wie mit ⌘⇧4. Leertaste wechselt auf ein ganzes Fenster, Esc bricht ab.<span class="cap-st">${status}</span>`, `<div class="seg wide" role="radiogroup">${c.options.map((o) => `<label class="seg-b${c.shortcut === o.id ? " on" : ""}"><input type="radio" name="cap-key" value="${esc(o.id)}" ${c.shortcut === o.id ? "checked" : ""}>${esc(o.label)}</label>`).join("")}</div>`)}
    ${setRow("KI-Zusammenfassung", "Vorauswahl im Fenster: Text aus dem Screenshot lesen (Apple Vision, auf dem Mac) und in die Notizen zusammenfassen.", `<label class="cap-ai mini"><input type="checkbox" id="cap-sum" ${c.summarize ? "checked" : ""}><span class="cap-sw" aria-hidden="true"></span><span>${c.summarize ? "An" : "Aus"}</span></label>`)}
    ${setRow("Berechtigung", "macOS fragt beim ersten Screenshot nach „Bildschirmaufnahme“. Ohne Freigabe zeigt das Bild nur den Schreibtisch.", `<a class="btn small" href="x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture" style="text-decoration:none">Freigabe prüfen ${I.out}</a>`)}`;
  box.querySelectorAll("input[name=cap-key]").forEach((r) => r.addEventListener("change", async () => {
    await api("/api/capture/config", { method: "POST", body: { shortcut: r.value } }).catch((e) => toast(e.message));
    toast(r.value ? "Kürzel geändert, gilt in wenigen Sekunden" : "Screenshot-Kürzel ausgeschaltet");
    setTimeout(loadCapture, 300);
    setTimeout(loadCapture, 16000);
  }));
  $("#cap-sum")?.addEventListener("change", async (e) => {
    await api("/api/capture/config", { method: "POST", body: { summarize: e.target.checked } }).catch((x) => toast(x.message));
    loadCapture();
  });
}

// ---------- Linear-Kontingent ----------
async function loadQuota(force = false) {
  const box = $("#quota-box");
  if (!box) return;
  if (force) box.classList.add("busy");
  let q;
  try { q = await api("/api/linear-usage" + (force ? "?force=1" : "")); }
  catch (e) { box.innerHTML = `<p class="err" style="padding:20px">${esc(e.message)}</p>`; return; }
  box.classList.remove("busy");
  const lim = q.limit;
  const pct = lim ? Math.min(100, Math.round((q.active / lim) * 100)) : null;
  const level = !lim ? "ok" : pct >= 90 ? "crit" : pct >= 70 ? "warn" : "ok";
  const seg = (n, cls) => (lim ? `<span class="q-seg ${cls}" style="width:${(n / Math.max(lim, q.active)) * 100}%"></span>` : "");
  const planLabel = q.plan === "free" ? "Free-Plan" : q.planKnown ? `Abo: ${q.plan.charAt(0).toUpperCase() + q.plan.slice(1)}` : "Plan nicht erkennbar";
  const msg = !q.planKnown
    ? "Linear verrät über die Schnittstelle nicht, welches Abo ihr habt. Zur Sicherheit rechnet PO-TION mit dem Free-Limit nicht, die Zahlen unten stimmen trotzdem."
    : !lim ? "Euer Abo hat kein Limit für Vorgänge."
    : level === "crit" ? `Fast voll: Ab ${lim} kannst du keine neuen Aufgaben mehr anlegen, auch nicht über PO-TION. Archiviere erledigte Aufgaben.`
    : level === "warn" ? "Wird langsam voll. Erledigte Aufgaben regelmäßig archivieren hält dich unter der Grenze."
    : `Alles im grünen Bereich, noch ${lim - q.active} Vorgänge frei.`;
  const checked = new Date(q.checkedAt).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" });
  box.innerHTML = `<div class="q-top">
      <div class="q-num"><span class="kind-badge ${q.plan === "free" ? "arch" : "proj"}">${esc(planLabel)}</span><b>${q.active}${lim ? `<small> / ${lim}</small>` : ""}</b><span class="muted">aktive Vorgänge im Workspace${pct !== null ? ` · ${pct} %` : ""}</span></div>
      <div class="q-ring lvl-${level}" style="--p:${pct ?? 0}" aria-hidden="true"><span>${pct !== null ? pct + "%" : "∞"}</span></div>
    </div>
    ${lim ? `<div class="q-bar" role="img" aria-label="${q.open} offen, ${q.completed} erledigt, ${q.canceled} verworfen von ${lim}">${seg(q.open, "s-open")}${seg(q.completed, "s-done")}${seg(q.canceled, "s-cancel")}<span class="q-limit"></span></div>` : ""}
    <div class="q-stats">
      <div><span><i class="q-dot s-open"></i>Offen</span><b>${q.open}</b></div>
      <div><span><i class="q-dot s-done"></i>Erledigt</span><b>${q.completed}</b></div>
      <div><span><i class="q-dot s-cancel"></i>Verworfen</span><b>${q.canceled}</b></div>
      <div><span><i class="q-dot s-arch"></i>Archiviert <em>zählt nicht</em></span><b>${q.archived ?? "–"}</b></div>
    </div>
    <div class="q-msg lvl-${level}"><span>${level === "ok" ? "✓" : "!"}</span>${esc(msg)}</div>
    <div class="q-actions">
      ${q.cleanupCandidates ? `<button class="btn" data-act="q-clean" data-n="${q.cleanupCandidates}">${q.cleanupCandidates} abgeschlossene Aufgaben archivieren <span class="muted">(älter als 30 Tage)</span></button>` : `<span class="muted">Keine abgeschlossenen Aufgaben älter als 30 Tage.</span>`}
      <span class="q-check muted">geprüft ${checked} · <button class="linkbtn" data-act="q-refresh">neu prüfen</button></span>
    </div>`;
}


// ---------- Datenquelle ----------
function dataSourceBox(st, isSettings, noName = false) {
  const b = st.backend || {};
  const c = st.config || {};
  const nameRow = setRow("Dein Name", "Für die Begrüßung und als Bearbeiter in Aufgaben", `<input class="in" id="f-name" value="${esc(c.userName || "")}" placeholder="Vorname Nachname" autocomplete="name">`, "f-name")
    + setRow("Dienstleister", "Namen externer Partner, durch Komma getrennt. „CHR-12 bei Name“ setzt dann den Status „Beim Dienstleister“.", `<input class="in" id="f-vendors" value="${esc((c.vendors || []).join(", "))}" placeholder="z. B. Agentur Nord, IT-Partner">`, "f-vendors")
    + setRow("Deine Rolle", "Hilft der KI beim Einordnen, z. B. Fachbegriffe und Dienstleister", `<input class="in" id="f-role" value="${esc(c.role || "")}" placeholder="z. B. Salesforce Product Owner">`, "f-role");
  if (noName) return dataSourceBox(st, isSettings).replace(nameRow, "");
  if (!isSettings) {
    const mode = S.setupMode || "local";
    return `<div class="ds-pick" role="radiogroup">
      <button type="button" class="ds-opt${mode === "local" ? " on" : ""}" data-setup-mode="local"><span class="ds-ico">${I.mac}</span><b>Nur auf diesem Mac</b><span>Alles bleibt lokal. Kein Konto nötig, ideal für Datenschutz.</span></button>
      <button type="button" class="ds-opt${mode === "linear" ? " on" : ""}" data-setup-mode="linear"><span class="ds-ico">${I.cloud}</span><b>Mit Linear</b><span>Aufgaben liegen in deinem Linear-Workspace, auch auf dem Handy sichtbar.</span></button>
    </div>${nameRow}`;
  }
  const lc = b.localCounts;
  if (b.backend === "local") {
    return `<div class="ds-now"><span class="ds-ico big">${I.mac}</span><div><b>Nur auf diesem Mac</b><span>${lc ? `${lc.issues} ${lc.issues === 1 ? "Aufgabe" : "Aufgaben"}, ${lc.projects} ${lc.projects === 1 ? "Projekt" : "Projekte"}, ${lc.archived} im Archiv` : "noch leer"}${b.importedFrom ? ` · übernommen aus ${esc(b.importedFrom)}` : ""}</span><span class="mono ds-file">${esc(b.file || "")}</span></div></div>
      ${nameRow}
      <div class="ds-actions" id="ds-actions">
        <span class="muted">Tägliche Sicherung in „backups“, 14 Tage aufbewahrt.</span>
        ${st.hasLinearKey ? `<span class="ds-btns"><button type="button" class="btn primary" data-ds="pull">Aus Linear übernehmen …</button><button type="button" class="btn" data-ds="to-linear">Zurück zu Linear …</button></span>` : `<span class="muted">Um Daten aus Linear zu holen oder zurückzugehen, verbinde zuerst <a href="#/einstellungen/verbindungen" data-cx-open="linear">Linear</a>.</span>`}
      </div>`;
  }
  return `<div class="ds-now"><span class="ds-ico big">${I.cloud}</span><div><b>Linear</b><span>Aufgaben liegen in deinem Linear-Workspace.</span></div></div>
    ${nameRow}
    <div class="ds-actions" id="ds-actions">
      <span class="muted">Lokal heißt: nichts verlässt mehr deinen Mac, kein 250er-Limit.</span>
      <button type="button" class="btn primary" data-ds="to-local">Auf „Nur auf diesem Mac“ umstellen …</button>
    </div>`;
}
async function dsRun(body, label) {
  const box = $("#ds-actions");
  box.innerHTML = `<div class="work" style="width:100%">${workBox().replace(/^<div class="work"[^>]*>/, "").replace(/<\/div>$/, "")}</div>`;
  box.querySelector(".work-label").textContent = label;
  startWorkPoll();
  try {
    const r = await api("/api/backend", { method: "POST", body });
    stopWorkPoll();
    S.home = null; S.searchIndex = null;
    await loadStatus();
    toast(r.pulled ? `${r.pulled.issues} Aufgaben und ${r.pulled.projects} Projekte aus Linear übernommen` : r.exported ? `${r.exported.issues} Aufgaben und ${r.exported.projects} Projekte nach Linear übertragen` : r.backend === "local" ? "Umgestellt: Alles liegt jetzt auf diesem Mac" : "Umgestellt auf Linear");
    renderSetup(true);
  } catch (e) {
    stopWorkPoll();
    box.innerHTML = `<p class="err">${esc(e.message)}</p><button type="button" class="btn" data-act="ds-reset">Zurück</button>`;
  }
}
