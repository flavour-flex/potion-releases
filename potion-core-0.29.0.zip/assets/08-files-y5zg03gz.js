// PO-TION Oberfläche · 08-files.js
// Klassische Skripte im gemeinsamen globalen Bereich, Reihenfolge laut ui/js (Dateiname). Start in 99-boot.js.
"use strict";
// ---------- Dateien ablegen ----------
const drop = $("#drop");
const dropInner = $("#drop-inner");
let dragDepth = 0;
let fileQueue = [];
let dropBusy = false;

function showDropHint() {
  dropInner.innerHTML = `<div class="drop-card"><div class="drop-head"><span>Loslassen zum Ablegen</span><h2>${S.view === "detail" && S.detail ? "Zu " + esc(S.detail.identifier) + " ablegen" : "PO-TION ordnet die Datei zu"}</h2></div></div>`;
  drop.hidden = false;
}

window.addEventListener("dragenter", (e) => {
  if (!e.dataTransfer?.types?.includes("Files") || S.view === "setup") return;
  dragDepth++;
  if (!dropBusy) showDropHint();
});
window.addEventListener("dragover", (e) => { if (e.dataTransfer?.types?.includes("Files")) e.preventDefault(); });
window.addEventListener("dragleave", () => {
  dragDepth = Math.max(0, dragDepth - 1);
  if (!dragDepth && !dropBusy) drop.hidden = true;
});
window.addEventListener("drop", (e) => {
  if (!e.dataTransfer?.files?.length) return;
  e.preventDefault();
  dragDepth = 0;
  if (S.view === "setup") return;
  handleFiles([...e.dataTransfer.files]);
});

function handleFiles(files) {
  if (!files.length) return;
  fileQueue.push(...files);
  if (!dropBusy) nextFile();
}

async function nextFile() {
  const f = fileQueue.shift();
  if (!f) { dropBusy = false; drop.hidden = true; return; }
  dropBusy = true;
  drop.hidden = false;
  const rest = fileQueue.length ? ` · noch ${fileQueue.length} weitere` : "";
  dropInner.innerHTML = `<div class="drop-card"><div class="drop-head"><span>Lese ${esc(f.name)} lokal${rest}</span><h2>Einen Moment…</h2></div></div>`;
  const fd = new FormData();
  fd.append("file", f);
  let a;
  try {
    a = await api("/api/files/analyze", { method: "POST", body: fd });
  } catch (e) {
    toast(e.message);
    return nextFile();
  }
  // In der Detailansicht: direkt zur offenen Aufgabe
  if (S.view === "detail" && S.detail) {
    await commitFile({ token: a.token, identifier: S.detail.identifier, cleanName: a.suggestion.cleanName });
    return nextFile();
  }
  renderFileSheet(a, rest);
}

function renderFileSheet(a, rest) {
  const sg = a.suggestion;
  let sel = sg.best?.identifier || null;
  const kb = (s) => (s > 1e6 ? (s / 1e6).toFixed(1).replace(".", ",") + " MB" : Math.max(1, Math.round(s / 1e3)) + " KB");
  const choice = (t, why) => `<button class="choice ${sel === t.identifier ? "sel" : ""}" data-pick="${esc(t.identifier)}">
      <span style="min-width:0"><span class="tc-title"><span class="idf">${esc(t.identifier)}</span><b style="font-weight:500">${esc(t.title)}</b></span>${why ? `<small>${esc(why)}</small>` : ""}</span>
      ${sel === t.identifier ? I.check("#B49BFF", 18) : ""}</button>`;
  const draw = async () => {
    const cands = [sg.best, sg.alternative].filter(Boolean);
    const conf = { hoch: "Passt sehr wahrscheinlich zu", mittel: "Passt vermutlich zu", niedrig: "Am ehesten" }[sg.confidence] || "Vorschlag";
    dropInner.innerHTML = `<div class="drop-card">
      <div class="drop-head"><span>Datei erkannt${rest}</span><h2>Wohin soll das?</h2></div>
      <div class="sheet">
        <div style="display:flex;align-items:center;gap:14px"><span class="badge b-oth" style="width:44px;height:44px;border-radius:11px;font-size:12px">${esc(a.ext)}</span>
          <span class="file-main"><b style="font-size:15px;font-weight:500">${esc(a.name)}</b><span>${kb(a.size)} · ${a.readable ? "lokal gelesen, nichts hochgeladen" : "Inhalt nicht lesbar, Zuordnung nach Dateiname"}</span></span></div>
        <div style="display:flex;flex-direction:column;gap:8px">
          <span class="lbl">${cands.length ? conf : "Keine passende Aufgabe gefunden"}</span>
          ${cands.map((t, i) => choice(t, i === 0 ? sg.reason : "")).join("")}
          <label for="other" class="sr">Andere Aufgabe</label>
          <select id="other"><option value="">Andere Aufgabe wählen…</option></select>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px">
          <label class="lbl" for="clean">Dateiname</label>
          <input type="text" id="clean" value="${esc(sg.cleanName)}">
          <span class="lbl">Eine Kopie wird abgelegt, der Verweis landet im Linear-Issue.</span>
        </div>
        <div class="actions">
          <button class="btn" data-act="skip-file">Überspringen</button>
          <button class="btn" data-act="new-from-file">Neue Aufgabe daraus</button>
          <button class="btn primary" data-act="commit-file" ${sel ? "" : "disabled"}>Zuordnen &amp; ablegen</button>
        </div>
      </div></div>`;
    try {
      const tasks = await api("/api/tasks");
      const o = $("#other");
      if (o) o.insertAdjacentHTML("beforeend", tasks.map((t) => `<option value="${esc(t.identifier)}" ${sel === t.identifier && !cands.some((c) => c.identifier === sel) ? "selected" : ""}>${esc(t.identifier)} · ${esc(t.title)}</option>`).join(""));
    } catch {}
    $("#other")?.addEventListener("change", (e) => { if (e.target.value) { sel = e.target.value; drawSel(); } });
  };
  const drawSel = () => {
    dropInner.querySelectorAll("[data-pick]").forEach((b) => {
      const on = b.dataset.pick === sel;
      b.classList.toggle("sel", on);
      b.lastElementChild?.tagName === "svg" && b.lastElementChild.remove();
      if (on) b.insertAdjacentHTML("beforeend", I.check("#B49BFF", 18));
    });
    const o = $("#other");
    if (o && ![...dropInner.querySelectorAll("[data-pick]")].some((b) => b.dataset.pick === sel)) o.value = sel || "";
    else if (o) o.value = "";
    const c = dropInner.querySelector('[data-act="commit-file"]');
    if (c) c.disabled = !sel;
  };
  dropInner.onclick = async (e) => {
    const p = e.target.closest("[data-pick]");
    if (p) { sel = p.dataset.pick; drawSel(); return; }
    const act = e.target.closest("[data-act]")?.dataset.act;
    if (act === "skip-file") return nextFile();
    if (act === "commit-file" && sel) { await commitFile({ token: a.token, identifier: sel, cleanName: $("#clean").value }); return nextFile(); }
    if (act === "new-from-file") { await commitFile({ token: a.token, newTaskTitle: sg.newTaskTitle || $("#clean").value, cleanName: $("#clean").value }); return nextFile(); }
  };
  draw();
}

async function commitFile(body) {
  try {
    const r = await api("/api/files/commit", { method: "POST", body });
    toast(`Abgelegt bei ${r.identifier}: ${r.name}`);
    if (S.view === "detail" && S.detail?.identifier === r.identifier) openDetail(r.identifier);
    else if (S.view === "home") refreshLists();
    else if (S.view === "project") openProject(S.project.id);
  } catch (e) {
    toast(e.message);
  }
}
