// PO-TION Oberfläche · 05-dock.js
// Klassische Skripte im gemeinsamen globalen Bereich, Reihenfolge laut ui/js (Dateiname). Start in 99-boot.js.
"use strict";
// ---------- Globales Eingabefeld unten ----------
function dockChips() {
  const h = S.home || {};
  if (S.view === "detail" && S.detail) {
    const k = S.detail.kind;
    const say = (label, text) => `<button class="chip" data-say="${esc(text)}">${label}</button>`;
    const hasFiles = (S.detail.files || []).some((f) => READABLE_RE.test(f.name));
    return [
      hasFiles && `<button class="chip chip-ai" data-say="Fasse die Dateien zusammen und schreib es in die Notizen">${I.spark}Dateien zusammenfassen</button>`,
      k !== "done" && say("Erledigt", "erledigt"),
      k !== "doing" && say("In Arbeit", "in Arbeit"),
      k !== "vendor" && say("Beim Dienstleister", "beim Dienstleister"),
      k !== "waiting" && `<button class="chip" data-fill="wartet auf ">Wartet auf …</button>`,
      k !== "review" && say("Abnahme", "in Abnahme"),
      `<button class="chip" data-fill="Neuer Checkpunkt: ">Checkpunkt +</button>`,
      `<button class="chip" data-fill="Fällig am ">Fälligkeit</button>`,
    ].filter(Boolean).join("");
  }
  if (S.view === "project" && S.project) {
    return `${(S.project.files || []).some((f) => READABLE_RE.test(f.name)) ? `<button class="chip chip-ai" data-say="Fasse die Dateien im Projekt zusammen">${I.spark}Dateien zusammenfassen</button>` : ""}
      <button class="chip" data-say="Was hängt?">Was hängt?</button>
      <button class="chip" data-fill="Neue Aufgabe: ">Aufgabe +</button>
      <button class="chip" data-fill="Neuer Meilenstein: ">Meilenstein +</button>
      <button class="chip" data-fill="Entscheiden: ">Entscheidung +</button>
      <button class="chip" data-quick="plan">Plan meinen Tag</button>`;
  }
  if (S.view === "milestone" && S.ms) {
    return `<button class="chip" data-fill="Neue Aufgabe: ">Aufgabe +</button>
      <button class="chip chip-ai" data-say="Fasse die Kommentare zusammen">${I.spark}Kommentare zusammenfassen</button>
      <button class="chip" data-say="Was ist noch offen?">Was ist offen?</button>`;
  }
  return `<button class="chip" data-quick="plan">Plan meinen Tag</button>
    <button class="chip" data-quick="overdue">Überfällig?</button>
    ${h.reviewCount ? `<button class="chip" data-quick="review">Abnahme · ${h.reviewCount}</button>` : ""}
    ${h.jira?.configured ? `<button class="chip ${h.jira.news ? "chip-hot" : ""}" data-quick="jira">${h.jira.news ? `Jira · ${h.jira.news} neu` : "Neu in Jira?"}</button>` : ""}
    ${h.untriagedCount ? `<button class="chip" data-act="triage">Inbox sortieren · ${h.untriagedCount}</button>` : ""}
    ${h.waitingCount ? `<button class="chip" data-quick="waiting">Was hängt? · ${h.waitingCount}</button>` : ""}
    <button class="chip" data-quick="done">Rückblick</button>
    <button class="chip" data-act="new-project">Neues Projekt</button>`;
}

const READABLE_RE = /\.(pdf|pptx|docx|xlsx|txt|md|csv|json|eml|html?|xml|ya?ml|png|jpe?g|heic)$/i;
const IMG_RE = /\.(png|jpe?g|gif|webp)$/i;

// Umschalter Schnell / Genau, sobald beide Modelle auf dem Mac liegen
function modelSwitch() {
  const l = S.status?.llm;
  if (!l || (l.installed || []).length < 2) return "";
  const busy = l.phase !== "ready";
  return `<div class="mswitch${busy ? " busy" : ""}" role="radiogroup" aria-label="Sprachmodell" title="${busy ? "Modell wird gewechselt …" : "Schnell: Qwen3 4B · Genau: Qwen3 8B"}">
    ${[["4b", "Schnell"], ["8b", "Genau"]].map(([v, t]) => `<button type="button" role="radio" aria-checked="${l.size === v}" class="${l.size === v ? "on" : ""}" data-model="${v}" ${busy ? "disabled" : ""}>${t}</button>`).join("")}
  </div>`;
}

function dockPlaceholder() {
  if (S.view === "detail" && S.detail) return `Zu ${S.detail.identifier}: Änderung, Checkpunkt, Status oder Frage …`;
  if (S.view === "project" && S.project) return `Im Projekt „${S.project.name}“: Aufgabe, Meilenstein, Entscheidung oder Frage …`;
  if (S.view === "milestone" && S.ms) return `Im Meilenstein „${S.ms.name}“: neue Aufgabe oder Frage …`;
  return "Aufgabe, Projekt oder Frage … z. B. „Leg ein Projekt WISMO an“";
}

function renderDock() {
  const dock = $("#dock");
  if (!["home", "project", "detail", "milestone"].includes(S.view)) { dock.hidden = true; document.body.classList.remove("has-dock"); return; }
  const keep = $("#cmd")?.value ?? S.draft ?? "";
  const label = S.view === "detail" && S.detail ? S.detail.identifier : S.view === "project" && S.project ? S.project.name : S.view === "milestone" && S.ms ? S.ms.name : "";
  dock.hidden = false;
  document.body.classList.add("has-dock");
  dock.innerHTML = `<div class="dock-inner">
    <div id="dock-status">${dockStatus()}</div>
    <div id="dock-reply" class="dock-reply" ${S.dockReply ? "" : "hidden"}>${S.dockReply || ""}</div>
    <div class="composer">
      ${label ? `<span class="dock-ctx">${S.view === "detail" ? "Aufgabe" : S.view === "milestone" ? "Meilenstein" : "Projekt"} · ${esc(label)}</span>` : ""}
      <label for="cmd" class="sr">Eingabe</label>
      <textarea id="cmd" rows="1" placeholder="${esc(dockPlaceholder())}"></textarea>
      <div class="composer-row">
        <div class="chips">${dockChips()}</div>
        <div class="send-row">
          <span class="dock-kbd" aria-hidden="true"><span class="dk-idle"><kbd>${MOD}</kbd><kbd>K</kbd> zum Schreiben</span><span class="dk-active"><kbd>↵</kbd> senden · <kbd>⇧</kbd><kbd>↵</kbd> neue Zeile</span></span>
          <span id="mswitch-slot">${modelSwitch()}</span>
          ${S.home?.outbox ? `<span class="pill warn" title="Wird automatisch nachgeholt"><span class="dot"></span>${S.home.outbox} wartet</span>` : ""}
          <label class="sq" style="cursor:pointer" aria-label="Datei anhängen">${I.clip}<input type="file" multiple class="sr" id="file-pick"></label>
          <button class="sq primary" aria-label="Senden" id="send">${I.up}</button>
        </div>
      </div>
    </div>
  </div>`;
  const ta = $("#cmd");
  ta.value = keep;
  const fit = () => { ta.style.height = "auto"; ta.style.height = Math.min(ta.scrollHeight, 200) + "px"; };
  fit();
  ta.addEventListener("input", () => { S.draft = ta.value; fit(); });
  ta.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey && !e.isComposing) { e.preventDefault(); send(); }
  });
  $("#send").addEventListener("click", () => send());
  $("#file-pick").addEventListener("change", (e) => handleFiles([...e.target.files]));
  // Platz für das Eingabefeld freihalten
  requestAnimationFrame(() => document.documentElement.style.setProperty("--dock-h", dock.offsetHeight + "px"));
}

function dockReply(html) {
  S.dockReply = `<button class="dock-close" data-act="dock-close" aria-label="Schließen">${I.x}</button>${html}`;
  const r = $("#dock-reply");
  if (!r) return;
  r.innerHTML = S.dockReply;
  r.hidden = false;
}

async function quick(kind) {
  thinking(true);
  try {
    const r = await api("/api/quick", { method: "POST", body: { kind } });
    thinking(false);
    pushMsg({ role: "assistant", text: r.reply, cards: r.cards });
  } catch (e) {
    thinking(false);
    toast(e.message);
  }
}

async function refreshLists() {
  try {
    const h = await api("/api/home");
    S.home = { ...h, chat: S.home.chat };
    const panel = $(".col-main .panel");
    if (panel) panel.innerHTML = renderNext(h.next);
    const day = $(".day");
    if (day) day.innerHTML = renderDay(h);
    const ps = $("#proj-strip");
    if (ps) ps.innerHTML = renderProjects(h.projects);
    const ch = $("#dock .chips");
    if (ch && S.view === "home") ch.innerHTML = dockChips();
  } catch {}
}

// ---------- Triage ----------
async function triage() {
  thinking(true);
  try {
    const r = await api("/api/triage", { method: "POST" });
    thinking(false);
    if (!r.items.length) return pushMsg({ role: "assistant", text: "Alles ist schon sortiert." });
    S.triage = r.items;
    const rows = r.items.map((x, i) => `<label class="tri-row"><input type="checkbox" checked data-tri="${i}">
      <span><span class="idf">${esc(x.identifier)}</span> ${esc(x.title)}
      <small>${esc(x.priorityLabel)}${x.project ? " · " + esc(x.project) : ""}${x.dueLabel ? " · fällig " + esc(x.dueLabel) : ""} — ${esc(x.reason)}</small></span></label>`).join("");
    pushMsg({ role: "assistant", text: `Vorschlag für ${r.items.length} unsortierte ${r.items.length === 1 ? "Aufgabe" : "Aufgaben"}:`, extra: `<div class="tri">${rows}</div><div class="msg-actions"><button class="btn small primary" data-act="tri-apply">Ausgewählte übernehmen</button></div>` });
  } catch (e) {
    thinking(false);
    pushMsg({ role: "assistant", text: "Sortieren ging nicht: " + e.message });
  }
}

async function applyTriage(btn) {
  const items = [...document.querySelectorAll("[data-tri]")].filter((c) => c.checked).map((c) => S.triage[Number(c.dataset.tri)]);
  btn.disabled = true;
  try {
    await api("/api/triage/apply", { method: "POST", body: { items } });
    btn.textContent = "Übernommen";
    refreshLists();
  } catch (e) {
    btn.disabled = false;
    toast(e.message);
  }
}
