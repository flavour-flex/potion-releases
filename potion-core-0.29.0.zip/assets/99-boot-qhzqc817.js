// PO-TION Oberfläche · 99-boot.js
// Klassische Skripte im gemeinsamen globalen Bereich, Reihenfolge laut ui/js (Dateiname). Start in 99-boot.js.
"use strict";
// Erst starten, wenn alle Module geladen sind
(async function start() {
  try { await loadStatus(); } catch { app.innerHTML = `<div class="setup"><div class="setup-card"><h1>PO-TION startet…</h1></div></div>`; setTimeout(start, 1000); return; }
  route();
  // Status alle 2 s, solange das Modell lädt, sonst alle 30 s
  (async function poll() {
    const before = S.status?.llm?.phase;
    try { await loadStatus(); } catch {}
    if (before !== "ready" && S.status?.llm?.phase === "ready") toast("Lokales Modell ist bereit");
    setTimeout(poll, S.status?.llm?.phase === "ready" ? 30000 : 2000);
  })();
  // Liste regelmäßig auffrischen (Änderungen aus Linear selbst)
  setInterval(() => {
    if (S.busy || document.visibilityState !== "visible") return;
    if (S.view === "home") refreshLists();
  }, 60000);
})();
