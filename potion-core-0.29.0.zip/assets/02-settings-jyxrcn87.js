// PO-TION Oberfläche · 02-settings.js
// Klassische Skripte im gemeinsamen globalen Bereich, Reihenfolge laut ui/js (Dateiname). Start in 99-boot.js.
"use strict";
// ---------- Einrichtung / Einstellungen ----------
// ---------- Farbschema ----------
function themePref() { try { return localStorage.getItem("potion-theme") || "system"; } catch { return "system"; } }
function applyTheme(pref = themePref()) {
  const dark = pref === "dark" || (pref === "system" && !matchMedia("(prefers-color-scheme: light)").matches);
  document.documentElement.dataset.theme = dark ? "dark" : "light";
}
function setTheme(pref) { try { localStorage.setItem("potion-theme", pref); } catch {} applyTheme(pref); }
matchMedia("(prefers-color-scheme: light)").addEventListener?.("change", () => applyTheme());
applyTheme();

// ---------- Einrichtung / Einstellungen ----------
const DAYS = [[1, "Mo"], [2, "Di"], [3, "Mi"], [4, "Do"], [5, "Fr"], [6, "Sa"], [0, "So"]];
function statusDot(kind, text) { return `<span class="st st-${kind}"><span class="dot"></span>${esc(text)}</span>`; }
function setRow(label, help, control, id) {
  return `<div class="set-row"><div class="set-label">${id ? `<label for="${id}">${label}</label>` : `<span>${label}</span>`}${help ? `<small>${help}</small>` : ""}</div><div class="set-ctl">${control}</div></div>`;
}
function setSection(id, title, desc, status, rows) {
  return `<section class="set-sec" id="sec-${id}"><div class="set-sec-head"><div><h2>${title}</h2>${desc ? `<p>${desc}</p>` : ""}</div>${status || ""}</div><div class="set-card">${rows}</div></section>`;
}
function hourOpts(sel, from, to) { let o = ""; for (let h = from; h <= to; h++) o += `<option value="${h}" ${h === sel ? "selected" : ""}>${String(h).padStart(2, "0")}:00</option>`; return o; }

function renderSetup(isSettings = false) {
  if (isSettings) return renderSettings();
  S.view = "setup";
  setViewTheme("settings");
  renderDock();
  const st = S.status || {};
  const c = st.config || {};
  const days = c.workDays || [1, 2, 3, 4, 5];
  const linStatus = st.setup ? statusDot("ok", "Verbunden") : statusDot("off", "Fehlt");
  const jiraStatus = !st.jira?.configured ? statusDot("off", "Nicht verbunden") : st.jira.error ? statusDot("err", "Fehler") : statusDot("ok", "Verbunden");
  const calStatus = !(c.icsUrls || []).length ? statusDot("off", "Kein Kalender") : st.calendar?.error ? statusDot("err", "Fehler") : statusDot("ok", "Abonniert");
  const l = st.llm || {};
  const llmStatus = l.phase === "ready" ? statusDot("ok", "Bereit") : l.phase === "error" ? statusDot("err", "Fehler") : statusDot("load", "Lädt");
  const tp = themePref();
  const local = st.backend?.backend === "local" || (!isSettings && S.setupMode !== "linear");
  const nav = [["daten", "Datenquelle"], ["verbindungen", "Verbindungen"], ...(isSettings && !local ? [["linear", "Linear-Kontingent"]] : []), ["planung", "Planung"], ...(isSettings ? [["erinnerungen", "Erinnerungen"]] : []), ["ki", "KI-Modell"], ...(isSettings ? [["nutzung", "Token-Zähler"]] : []), ["darstellung", "Darstellung"], ...(isSettings ? [["screenshots", "Screenshots"], ["app", "App"]] : [])];

  app.innerHTML = (isSettings ? topbar() : "") + `<main class="settings${isSettings ? "" : " first-run"}">
    <header class="set-head">
      ${isSettings ? "" : `<span class="logo big">${FLASK(64)}</span>`}
      <h1>${isSettings ? "Einstellungen" : "PO-TION einrichten"}</h1>
      <p>${isSettings ? "Verbindungen, Planung und Aussehen. Schlüssel liegen im macOS-Schlüsselbund, das Modell läuft auf diesem Mac." : "Wähle, wo deine Aufgaben liegen, und sag mir deinen Namen. Alles andere kannst du später ergänzen."}</p>
    </header>
    <div class="set-layout">
      <nav class="set-nav" aria-label="Bereiche">${nav.map(([id, t]) => `<a href="#sec-${id}" data-scroll="sec-${id}">${t}</a>`).join("")}</nav>
      <form class="set-main" id="setup-form" novalidate>
        ${setSection("daten", "Datenquelle", "Wo deine Aufgaben, Projekte und Notizen gespeichert werden.", "", dataSourceBox(st, isSettings))}
        ${setSection("verbindungen", "Verbindungen", "Woher PO-TION Tickets und Termine liest.", "", `
          <div class="set-group${local && !isSettings ? " hide-local" : ""}" id="grp-linear"><div class="set-group-head"><b>Linear</b>${local ? statusDot("off", "Nicht genutzt") : linStatus}</div>
            ${setRow("API-Key", "Linear → Einstellungen → Sicherheit &amp; Zugriff → Persönliche API-Keys", `<input class="in mono" id="f-key" type="password" autocomplete="off" placeholder="${st.hasLinearKey ? "Gespeichert, leer lassen zum Behalten" : "lin_api_…"}">`, "f-key")}
          </div>
          <div class="set-group"><div class="set-group-head"><b>Jira</b>${jiraStatus}</div>
            ${setRow("Adresse", "Die Atlassian-Adresse deiner Firma", `<input class="in" id="f-jbase" type="url" placeholder="https://firma.atlassian.net" value="${esc(c.jiraBase || "")}">`, "f-jbase")}
            ${setRow("E-Mail", "", `<input class="in" id="f-jmail" type="email" placeholder="deine.mail@firma.de" value="${esc(c.jiraEmail || "")}">`, "f-jmail")}
            ${setRow("API-Token", `id.atlassian.com → Sicherheit → API-Token. Nur Lesezugriff.${st.jira?.error ? `<span class="set-err">${esc(st.jira.error)}</span>` : ""}`, `<input class="in mono" id="f-jtoken" type="password" autocomplete="off" placeholder="${st.jira?.hasToken ? "Gespeichert, leer lassen zum Behalten" : "API-Token"}">`, "f-jtoken")}
          </div>
          <div class="set-group"><div class="set-group-head"><b>Kalender</b>${calStatus}</div>
            ${setRow("ICS-Links", `Nur belegt/frei wird genutzt. Ein Link pro Zeile.${st.calendar?.error ? `<span class="set-err">${esc(st.calendar.error)}</span>` : ""}`, `<textarea class="in mono" id="f-ics" rows="2" placeholder="https://outlook.office365.com/…/calendar.ics">${esc((c.icsUrls || []).join("\n"))}</textarea>`, "f-ics")}
          </div>`)}
        ${isSettings && !local ? setSection("linear", "Linear-Kontingent", "Im Free-Plan sind 250 aktive Vorgänge pro Workspace erlaubt. Erledigte und verworfene zählen mit, archivierte nicht.", "", `<div class="quota" id="quota-box"><p class="muted" style="padding:20px">Prüfe Linear …</p></div>`) : ""}
        ${setSection("planung", "Planung", "Danach richten sich Tagesplan und freie Fokuszeit.", "", `
          ${setRow("Arbeitszeit", "", `<div class="ctl-inline"><select class="in" id="f-ws" aria-label="Beginn">${hourOpts(c.workStart ?? 8, 5, 12)}</select><span class="muted">bis</span><select class="in" id="f-we" aria-label="Ende">${hourOpts(c.workEnd ?? 18, 13, 22)}</select></div>`)}
          ${setRow("Arbeitstage", "", `<div class="day-pick">${DAYS.map(([d, n]) => `<label class="wd"><input type="checkbox" name="wd" value="${d}" ${days.includes(d) ? "checked" : ""}><span>${n}</span></label>`).join("")}</div>`)}
          ${setRow("Ablageordner", "Hierhin sortiert PO-TION abgelegte Dateien.", `<div class="ctl-inline"><input class="in mono" id="f-dir" type="text" value="${esc(c.ablageDir || "")}"><button type="button" class="btn" data-act="pick">Wählen</button></div>`, "f-dir")}`)}
        ${setSection("ki", "KI-Modell", "Läuft lokal, nichts verlässt den Mac.", llmStatus, `
          ${setRow("Modell", "Das genauere Modell versteht unklare Eingaben besser, antwortet aber langsamer. Wird beim Wechsel einmal geladen.", `<div class="seg wide" role="radiogroup">
            <label class="seg-b${(c.modelSize || "4b") === "4b" ? " on" : ""}"><input type="radio" name="model" value="4b" ${(c.modelSize || "4b") === "4b" ? "checked" : ""}>Schnell<small>Qwen3 4B · 2,5 GB</small></label>
            <label class="seg-b${c.modelSize === "8b" ? " on" : ""}"><input type="radio" name="model" value="8b" ${c.modelSize === "8b" ? "checked" : ""}>Genauer<small>Qwen3 8B · 5 GB</small></label></div>`)}
          <div class="set-row column"><div class="model-box" id="model-box">${modelBox()}</div></div>`)}
        ${isSettings ? setSection("nutzung", "Token-Zähler", "Wie viel das lokale Modell gelesen und geschrieben hat. Läuft auf deinem Mac und kostet nichts.", "", `<div class="usage" id="usage-box"><p class="muted" style="padding:20px">Lade …</p></div>`) : ""}
        ${setSection("darstellung", "Darstellung", "Gilt sofort, ohne Speichern.", "", `
          ${setRow("Farbschema", "", `<div class="seg wide" role="radiogroup">${[["system", "Wie macOS"], ["light", "Hell"], ["dark", "Dunkel"]].map(([v, t]) => `<label class="seg-b${tp === v ? " on" : ""}"><input type="radio" name="theme" value="${v}" ${tp === v ? "checked" : ""}>${t}</label>`).join("")}</div>`)}`)}
        ${isSettings ? setSection("erinnerungen", "Erinnerungen", "Eine Mac-Mitteilung vor Fristen mit Uhrzeit. Ein Klick darauf öffnet die Aufgabe. Gilt sofort, ohne Speichern.", "", `<div id="rem-box"><p class="muted" style="padding:12px 0">Lade …</p></div>`) : ""}
        ${isSettings ? setSection("screenshots", "Screenshots", "Überall am Mac per Tastenkürzel einen Bereich aufnehmen und direkt einer Aufgabe oder einem Projekt zuordnen. Gilt sofort, ohne Speichern.", "", `<div id="cap-box"><p class="muted" style="padding:12px 0">Lade …</p></div>`) : ""}
        ${isSettings ? setSection("app", "App", "", "", `
          ${setRow("Version", "Updates kommen aus dem PO-TION-Download-Repo auf GitHub. Installiert wird nur, wenn du es bestätigst.", `<div class="upd" id="upd-box">${updBox(st.update, st.version)}</div>`)}
          ${setRow("Beenden", "Stoppt den lokalen Dienst und das Modell. Zum Starten PO-TION wieder öffnen.", `<button type="button" class="btn" data-act="quit">PO-TION beenden</button>`)}`) : ""}
        <div class="set-bar">
          <p class="err" id="setup-err" hidden></p>
          <span class="muted set-bar-hint" id="set-dirty">${isSettings ? "Keine Änderungen" : ""}</span>
          ${isSettings ? `<a class="btn" href="#/" style="text-decoration:none">Abbrechen</a>` : ""}
          <button type="submit" class="btn primary" id="setup-go">${isSettings ? "Speichern" : "Loslegen"}</button>
        </div>
      </form>
    </div>
  </main>`;

  if (isSettings) { loadUsage(); loadCapture(); loadReminders(); if (!local) loadQuota(); }
  const form = $("#setup-form");
  form.addEventListener("input", (e) => {
    if (e.target.name === "theme" || e.target.closest?.("#cap-box, #rem-box")) return;
    const d = $("#set-dirty");
    if (d && isSettings) { d.textContent = "Ungespeicherte Änderungen"; d.classList.add("dirty"); }
  });
  form.addEventListener("change", (e) => {
    const t = e.target;
    if (t.type === "radio") t.closest(".seg").querySelectorAll(".seg-b").forEach((b) => b.classList.toggle("on", b.contains(t)));
    if (t.name === "theme") setTheme(t.value);
  });
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const err = $("#setup-err");
    err.hidden = true;
    const btn = $("#setup-go");
    btn.disabled = true;
    btn.textContent = "Prüfe…";
    try {
      if (!isSettings) {
        const name = $("#f-name")?.value.trim();
        if (!name) throw new Error("Wie heißt du? Der Name erscheint in der Begrüßung.");
        if (S.setupMode !== "linear") await api("/api/backend", { method: "POST", body: { mode: "local", import: false, userName: name } });
      }
      const r = await api("/api/settings", {
        method: "POST",
        body: {
          userName: $("#f-name")?.value || undefined,
          role: $("#f-role")?.value ?? undefined,
          vendors: $("#f-vendors") ? $("#f-vendors").value.split(",").map((x) => x.trim()).filter(Boolean) : undefined,
          backend: !isSettings && S.setupMode !== "linear" ? "local" : undefined,
          linearKey: $("#f-key").value,
          icsUrls: $("#f-ics").value.split(/\s+/).filter(Boolean),
          ablageDir: $("#f-dir").value,
          workStart: parseInt($("#f-ws").value, 10),
          workEnd: parseInt($("#f-we").value, 10),
          workDays: [...form.querySelectorAll("input[name=wd]:checked")].map((x) => Number(x.value)),
          jiraBase: $("#f-jbase").value,
          modelSize: form.querySelector("input[name=model]:checked")?.value || "4b",
          jiraEmail: $("#f-jmail").value,
          jiraToken: $("#f-jtoken").value,
        },
      });
      await loadStatus();
      toast(r.who ? `Gespeichert. Verbunden mit ${r.who.org} als ${r.who.name}` : "Gespeichert");
      location.hash = "#/";
      route();
    } catch (ex) {
      err.textContent = ex.message;
      err.hidden = false;
    } finally {
      btn.disabled = false;
      btn.textContent = isSettings ? "Speichern" : "Loslegen";
    }
  });
}

// ================= Einstellungen (neu): Bereiche, Suche, Sofort-Speichern, Verbindungs-Marktplatz =================
const SETI = {
  user: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"/></svg>`,
  plug: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 7V3M15 7V3M7 7h10v4a5 5 0 0 1-10 0z"/><path d="M12 16v5"/></svg>`,
  work: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="13" r="8"/><path d="M12 9v4l2.5 2.5M9 2h6"/></svg>`,
  ai: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5z"/></svg>`,
  data: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><ellipse cx="12" cy="5.5" rx="8" ry="3"/><path d="M4 5.5v13c0 1.7 3.6 3 8 3s8-1.3 8-3v-13M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/></svg>`,
  app: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="3"/><path d="M3 9h18"/><circle cx="6.5" cy="6.5" r=".6" fill="currentColor"/><circle cx="9" cy="6.5" r=".6" fill="currentColor"/></svg>`,
  ok: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>`,
};
const SET_AREAS = [
  { id: "allgemein", title: "Allgemein", icon: SETI.user, desc: "Wer du bist und wie PO-TION aussieht." },
  { id: "verbindungen", title: "Verbindungen", icon: SETI.plug, desc: "Dienste, aus denen PO-TION liest. Jede Verbindung zeigt, was sie liest und was den Mac verlässt." },
  { id: "arbeitsweise", title: "Arbeitsweise", icon: SETI.work, desc: "Arbeitszeit, Erinnerungen, Screenshots und Tastenkürzel." },
  { id: "ki", title: "KI", icon: SETI.ai, desc: "Das Sprachmodell läuft komplett auf diesem Mac." },
  { id: "daten", title: "Daten", icon: SETI.data, desc: "Wo deine Aufgaben liegen, Sicherung und Archiv." },
  { id: "app", title: "App", icon: SETI.app, desc: "Version, Updates und Hilfe." },
];
// Zeile mit Suchbegriffen und Platz für "Gespeichert"
function srow(label, help, control, opts = {}) {
  const kw = [label, help, opts.kw || ""].join(" ").replace(/<[^>]+>/g, " ").toLowerCase();
  return `<div class="set-row srow${opts.column ? " column" : ""}" data-kw="${esc(kw)}"${opts.id ? ` id="row-${opts.id}"` : ""}>
    <div class="set-label">${opts.for ? `<label for="${opts.for}">${label}</label>` : `<span>${label}</span>`}${help ? `<small>${help}</small>` : ""}</div>
    <div class="set-ctl">${control}<span class="row-state" aria-live="polite"></span></div></div>`;
}
function sgroup(title, rows, kw = "") {
  return `<div class="sgroup" data-kw="${esc((title + " " + kw).toLowerCase())}"><h3>${title}</h3><div class="sgroup-box">${rows}</div></div>`;
}

function renderSettings() {
  S.view = "setup";
  setViewTheme("settings");
  renderDock();
  const st = S.status || {};
  const c = st.config || {};
  const area = (location.hash.split("/")[2] || S.setArea || "allgemein").replace(/[^a-z]/g, "");
  S.setArea = SET_AREAS.some((a) => a.id === area) ? area : "allgemein";
  const days = c.workDays || [1, 2, 3, 4, 5];
  const tp = themePref();
  const local = st.backend?.backend === "local";
  const l = st.llm || {};
  const llmStatus = l.phase === "ready" ? statusDot("ok", "Bereit") : l.phase === "error" ? statusDot("err", "Fehler") : statusDot("load", "Lädt");

  const body = {
    allgemein: sgroup("Über dich", `
        ${srow("Dein Name", "Für die Begrüßung und als Bearbeiter in Aufgaben.", `<input class="in" id="s-name" data-save="userName" value="${esc(c.userName || "")}" placeholder="Vorname Nachname" autocomplete="name">`, { for: "s-name" })}
        ${srow("Deine Rolle", "Hilft der KI beim Einordnen von Fachbegriffen.", `<input class="in" id="s-role" data-save="role" value="${esc(c.role || "")}" placeholder="z. B. Salesforce Product Owner">`, { for: "s-role", kw: "ki prompt" })}
        ${srow("Dienstleister", "Externe Partner, durch Komma getrennt. „CHR-12 bei Name“ setzt dann „Beim Dienstleister“.", `<input class="in" id="s-vendors" data-save="vendors" value="${esc((c.vendors || []).join(", "))}" placeholder="z. B. Agentur Nord, IT-Partner">`, { for: "s-vendors", kw: "partner agentur extern" })}`)
      + sgroup("Darstellung", srow("Farbschema", "", `<div class="seg wide" role="radiogroup">${[["system", "Wie macOS"], ["light", "Hell"], ["dark", "Dunkel"]].map(([v, t]) => `<label class="seg-b${tp === v ? " on" : ""}"><input type="radio" name="theme" value="${v}" ${tp === v ? "checked" : ""}>${t}</label>`).join("")}</div>`, { kw: "hell dunkel dark light theme" })),
    verbindungen: `<div id="cx-root"><p class="muted" style="padding:12px 0">Lade Verbindungen …</p></div>`,
    arbeitsweise: sgroup("Arbeitszeit", `
        ${srow("Arbeitszeit", "Danach richten sich Tagesplan und freie Fokuszeit.", `<div class="ctl-inline"><select class="in" id="s-ws" data-save="workStart" aria-label="Beginn">${hourOpts(c.workStart ?? 8, 5, 12)}</select><span class="muted">bis</span><select class="in" id="s-we" data-save="workEnd" aria-label="Ende">${hourOpts(c.workEnd ?? 18, 13, 22)}</select></div>`, { kw: "beginn ende uhrzeit" })}
        ${srow("Arbeitstage", "", `<div class="day-pick" data-save="workDays">${DAYS.map(([d, n]) => `<label class="wd"><input type="checkbox" name="wd" value="${d}" ${days.includes(d) ? "checked" : ""}><span>${n}</span></label>`).join("")}</div>`, { kw: "wochentage montag freitag" })}`)
      + sgroup("Erinnerungen", `<div id="rem-box"><p class="muted" style="padding:12px 0">Lade …</p></div>`, "mitteilung frist vorlauf benachrichtigung")
      + sgroup("Screenshots", `<div id="cap-box"><p class="muted" style="padding:12px 0">Lade …</p></div>`, "bildschirmfoto kürzel aufnahme texterkennung")
      + sgroup("Dateien", srow("Ablageordner", "Hierhin sortiert PO-TION abgelegte Dateien und Screenshots.", `<div class="ctl-inline"><input class="in mono" id="f-dir" data-save="ablageDir" type="text" value="${esc(c.ablageDir || "")}"><button type="button" class="btn" data-act="pick">Wählen</button></div>`, { for: "f-dir", kw: "ordner finder ablage" }))
      + sgroup("Tastenkürzel", srow("Übersicht", "", `<div class="kbd-list">
          <span><kbd>⌘</kbd><kbd>K</kbd> In den Chat schreiben</span><span><kbd>⌘</kbd><kbd>J</kbd> Suche</span>
          <span><kbd>⌘</kbd><kbd>⇧</kbd><kbd>2</kbd> Screenshot ablegen</span><span><kbd>⌘</kbd><kbd>,</kbd> Einstellungen</span><span><kbd>esc</kbd> Schließen</span></div>`, { column: true, kw: "shortcut tasten" }), "shortcut"),
    ki: sgroup("Sprachmodell", `
        ${srow("Modell", "Das genauere Modell versteht unklare Eingaben besser, antwortet aber langsamer. Wird beim Wechsel einmal geladen.", `<div class="seg wide" role="radiogroup" data-save="modelSize">
          <label class="seg-b${(c.modelSize || "4b") === "4b" ? " on" : ""}"><input type="radio" name="model" value="4b" ${(c.modelSize || "4b") === "4b" ? "checked" : ""}>Schnell<small>Qwen3 4B · 2,5 GB</small></label>
          <label class="seg-b${c.modelSize === "8b" ? " on" : ""}"><input type="radio" name="model" value="8b" ${c.modelSize === "8b" ? "checked" : ""}>Genauer<small>Qwen3 8B · 5 GB</small></label></div>`, { kw: "qwen schnell genau llm" })}
        ${srow(`Status ${llmStatus}`, "", `<div class="model-box" id="model-box">${modelBox()}</div>`, { column: true, kw: "download modell laden" })}`)
      + sgroup("Token-Zähler", `<div class="usage" id="usage-box"><p class="muted" style="padding:20px">Lade …</p></div>`, "kosten gespart haiku verbrauch"),
    daten: sgroup("Datenquelle", `<div class="srow column" data-kw="datenquelle linear lokal mac umstellen übernehmen backup sicherung">${dataSourceBox(st, true, true)}</div>`)
      + (!local && st.hasLinearKey ? sgroup("Linear-Kontingent", `<div class="quota" id="quota-box"><p class="muted" style="padding:20px">Prüfe Linear …</p></div>`, "250 limit free plan archiviert") : "")
      + sgroup("Archiv", srow("Erledigte und archivierte Aufgaben", "Alles, was erledigt, verworfen oder gelöscht wurde, lässt sich dort zurückholen.", `<a class="btn" href="#/archiv" style="text-decoration:none">Archiv öffnen</a>`, { kw: "gelöscht wiederherstellen" })),
    app: sgroup("Version", srow("Updates", "Kleine Updates laden nur den Code (wenige MB). Installiert wird nur, wenn du es bestätigst.", `<div class="upd" id="upd-box">${updBox(st.update, st.version)}</div>`, { column: true, kw: "update version aktualisieren" }))
      + sgroup("Hilfe", srow("Hilfe & FAQ", "Wie PO-TION funktioniert, Schritt für Schritt.", `<a class="btn" href="#/hilfe" style="text-decoration:none">Hilfe öffnen</a>`, { kw: "faq anleitung" }))
      + sgroup("Beenden", srow("PO-TION beenden", "Stoppt den lokalen Dienst und das Modell. Zum Starten PO-TION wieder öffnen.", `<button type="button" class="btn" data-act="quit">Beenden</button>`, { kw: "quit stoppen" })),
  };

  app.innerHTML = topbar() + `<main class="settings s2">
    <div class="s2-layout">
      <aside class="s2-side">
        <h1>Einstellungen</h1>
        <label class="s2-search">${I.search}<input id="set-q" placeholder="Einstellung suchen …" autocomplete="off" spellcheck="false"></label>
        <nav class="s2-nav" aria-label="Bereiche">${SET_AREAS.map((a) => `<a href="#/einstellungen/${a.id}" class="${a.id === S.setArea ? "on" : ""}" data-area="${a.id}"><span class="s2-ico">${a.icon}</span>${a.title}${a.id === "verbindungen" ? `<em id="cx-count"></em>` : ""}</a>`).join("")}</nav>
        <p class="s2-foot">${I.lock}<span>Schlüssel liegen im macOS-Schlüsselbund. Änderungen gelten sofort.</span></p>
      </aside>
      <div class="s2-main" id="s2-main">
        ${SET_AREAS.map((a) => `<section class="s2-area" data-area="${a.id}" ${a.id === S.setArea ? "" : "hidden"}>
          <header class="s2-head"><h2>${a.title}</h2><p>${a.desc}</p></header>
          ${body[a.id]}
        </section>`).join("")}
        <p class="s2-none muted" hidden>Keine Einstellung gefunden.</p>
      </div>
    </div>
  </main>`;

  loadUsage(); loadCapture(); loadReminders(); loadConnectors(S.cxOpenNext); S.cxOpenNext = null;
  if (!local && st.hasLinearKey) loadQuota();
  const main = $("#s2-main");
  // Sofort speichern
  const timers = {};
  const save = async (el) => {
    const key = el.dataset.save;
    let val;
    if (key === "workDays") val = [...el.querySelectorAll("input:checked")].map((x) => Number(x.value));
    else if (key === "modelSize") val = el.querySelector("input:checked")?.value;
    else if (key === "vendors") val = el.value.split(",").map((x) => x.trim()).filter(Boolean);
    else if (key === "workStart" || key === "workEnd") val = parseInt(el.value, 10);
    else val = el.value;
    const state = el.closest(".set-ctl")?.querySelector(".row-state");
    if (state) { state.className = "row-state busy"; state.textContent = "Speichert …"; }
    try {
      await api("/api/settings/patch", { method: "POST", body: { [key]: val } });
      if (state) { state.className = "row-state ok"; state.innerHTML = `${SETI.ok}Gespeichert`; setTimeout(() => { if (state.classList.contains("ok")) state.className = "row-state"; }, 1800); }
      loadStatus().catch(() => {});
    } catch (e) {
      if (state) { state.className = "row-state err"; state.textContent = e.message; }
    }
  };
  main.addEventListener("input", (e) => {
    const el = e.target.closest("[data-save]");
    if (!el || e.target.type === "radio" || e.target.type === "checkbox" || el.tagName === "SELECT") return;
    clearTimeout(timers[el.dataset.save]);
    timers[el.dataset.save] = setTimeout(() => save(el), 800);
  });
  main.addEventListener("change", (e) => {
    const t = e.target;
    if (t.type === "radio") t.closest(".seg")?.querySelectorAll(".seg-b").forEach((b) => b.classList.toggle("on", b.contains(t)));
    if (t.name === "theme") { setTheme(t.value); return; }
    const el = t.closest("[data-save]");
    if (!el || el.closest("#cap-box, #rem-box")) return;
    clearTimeout(timers[el.dataset.save]);
    save(el);
  });
  // Suche über alle Bereiche
  $("#set-q").addEventListener("input", (e) => filterSettings(e.target.value));
}
function filterSettings(v) {
  const words = v.toLowerCase().trim().split(/\s+/).filter(Boolean);
  const main = $("#s2-main");
  main.classList.toggle("searching", words.length > 0);
  let any = 0;
  main.querySelectorAll(".s2-area").forEach((a) => {
    if (!words.length) { a.hidden = a.dataset.area !== S.setArea; a.querySelectorAll(".srow, .sgroup, .cx-card").forEach((r) => (r.hidden = false)); return; }
    let hit = 0;
    a.querySelectorAll(".sgroup").forEach((g) => {
      const gkw = g.dataset.kw || "";
      let gh = 0;
      g.querySelectorAll(".srow").forEach((r) => { const ok = words.every((w) => (r.dataset.kw + " " + gkw).includes(w)); r.hidden = !ok; if (ok) gh++; });
      if (!g.querySelector(".srow") && words.every((w) => (gkw + " " + g.textContent.toLowerCase()).includes(w))) gh++;
      g.hidden = !gh; hit += gh;
    });
    a.querySelectorAll(".cx-card").forEach((card) => { const ok = words.every((w) => card.textContent.toLowerCase().includes(w)); card.hidden = !ok; if (ok) hit++; });
    a.hidden = !hit; any += hit;
  });
  main.querySelector(".s2-none").hidden = !words.length || any > 0;
}

// ---------- Verbindungen (Marktplatz) ----------
const CX_STATE = { connected: ["ok", "Verbunden"], error: ["err", "Fehler"], off: ["off", "Nicht verbunden"], unused: ["off", "Nicht genutzt"], planned: ["plan", "Geplant"] };
const cxMono = (n) => n.replace(/\(.*\)/, "").split(/[\s&]+/).filter(Boolean).slice(0, 2).map((w) => w[0]).join("").toUpperCase();
async function loadConnectors(openId) {
  const root = $("#cx-root");
  if (!root) return;
  let r;
  try { r = await api("/api/connectors"); } catch (e) { root.innerHTML = `<p class="err">${esc(e.message)}</p>`; return; }
  S.cx = r;
  const n = r.connectors.filter((x) => x.status.state === "connected").length;
  const cnt = $("#cx-count"); if (cnt) cnt.textContent = n ? String(n) : "";
  const f = S.cxFilter || "all";
  const cats = [{ id: "all", label: "Alle" }, ...r.categories.filter((cat) => r.connectors.some((x) => x.category === cat.id))];
  const live = r.connectors.filter((x) => !x.planned), planned = r.connectors.filter((x) => x.planned);
  const card = (x, i) => {
    const [cls, label] = CX_STATE[x.status.state] || ["off", ""];
    const btn = x.planned ? "Geplant" : x.status.state === "connected" || x.status.state === "unused" ? "Verwalten" : x.status.state === "error" ? "Reparieren" : !x.can.connect ? "Ansehen" : "Hinzufügen";
    return `<button type="button" class="cx-card cat-${x.category} st-${x.status.state}${x.planned ? " planned" : ""}" data-cx="${esc(x.id)}" ${f !== "all" && x.category !== f ? "hidden" : ""} style="--i:${i}">
      <span class="cx-top"><span class="cx-mono">${esc(cxMono(x.name))}</span><span class="cx-pill p-${cls}"><i></i>${esc(x.status.text || label)}</span></span>
      <b>${esc(x.name)}</b><span class="cx-blurb">${esc(x.blurb)}</span>
      <span class="cx-foot"><span>${esc((r.categories.find((c2) => c2.id === x.category) || {}).label || "")}</span><span class="cx-act">${btn}${x.planned ? "" : " →"}</span></span>
    </button>`;
  };
  root.innerHTML = `<div class="cx-bar"><div class="cx-filter" role="tablist">${cats.map((cat) => `<button type="button" class="chip${f === cat.id ? " on" : ""}" data-cxf="${cat.id}">${esc(cat.label)}</button>`).join("")}</div><span class="muted">${n} von ${live.length} verbunden</span></div>
    <div class="cx-grid">${live.map(card).join("")}</div>
    <h3 class="cx-sub">Demnächst</h3>
    <div class="cx-grid">${planned.map((x, i) => card(x, i + live.length)).join("")}</div>`;
  if (openId) openConnector(openId);
}
function openConnector(id) {
  const x = S.cx?.connectors.find((c2) => c2.id === id);
  if (!x) return;
  closeConnector(true);
  const [cls] = CX_STATE[x.status.state] || ["off"];
  const field = (fl) => {
    const show = fl.showIf ? ` data-show-if="${esc(fl.showIf.field)}=${esc(fl.showIf.value)}"` : "";
    if (fl.type === "choice") return `<fieldset class="cx-field cx-choice" data-name="${esc(fl.id)}"${show}><legend>${esc(fl.label)}</legend>${fl.options.map((o) => `<label class="cx-opt${o.value === fl.value ? " on" : ""}"><input type="radio" name="${esc(fl.id)}" value="${esc(o.value)}" ${o.value === fl.value ? "checked" : ""}><span><b>${esc(o.label)}</b>${o.hint ? `<small>${esc(o.hint)}</small>` : ""}</span></label>`).join("")}</fieldset>`;
    if (fl.type === "multi") { const on = new Set((fl.value || "").split(",")); return `<fieldset class="cx-field cx-multi" data-name="${esc(fl.id)}"${show}><legend>${esc(fl.label)}</legend>${fl.options.map((o) => `<label class="cx-chk"><input type="checkbox" value="${esc(o.value)}" ${on.has(o.value) ? "checked" : ""}><span class="cx-box-i"></span><span>${esc(o.label)}${o.hint ? `<small>${esc(o.hint)}</small>` : ""}</span></label>`).join("")}</fieldset>`; }
    if (fl.type === "select") return `<label class="cx-field"${show}><span>${esc(fl.label)}</span><select class="in" name="${esc(fl.id)}">${fl.options.map((o) => `<option value="${esc(o.value)}" ${o.value === fl.value ? "selected" : ""}>${esc(o.label)}</option>`).join("")}</select>${fl.help ? `<small>${esc(fl.help)}</small>` : ""}</label>`;
    if (fl.type === "toggle") return `<label class="cx-field cx-toggle"${show}><input type="checkbox" name="${esc(fl.id)}" ${fl.value === "1" ? "checked" : ""}><span class="cap-sw" aria-hidden="true"></span><span><b>${esc(fl.label)}</b>${fl.help ? `<small>${esc(fl.help)}</small>` : ""}</span></label>`;
    const ph = fl.type === "secret" && fl.hasValue ? "Gespeichert, leer lassen zum Behalten" : fl.placeholder || "";
    const input = fl.type === "lines"
      ? `<textarea class="in mono" name="${esc(fl.id)}" rows="3" placeholder="${esc(ph)}">${esc(fl.value || "")}</textarea>`
      : `<input class="in${fl.type === "secret" ? " mono" : ""}" name="${esc(fl.id)}" type="${fl.type === "secret" ? "password" : fl.type}" value="${esc(fl.value || "")}" placeholder="${esc(ph)}" autocomplete="off" spellcheck="false">`;
    return `<label class="cx-field"><span>${esc(fl.label)}</span>${input}${fl.help ? `<small>${esc(fl.help)}</small>` : ""}</label>`;
  };
  const connected = ["connected", "unused", "error"].includes(x.status.state) && x.status.state !== "off";
  document.body.insertAdjacentHTML("beforeend", `<div class="cx-sheet" role="dialog" aria-modal="true" aria-label="${esc(x.name)}"><div class="cx-panel">
    <header class="cx-head"><span class="cx-mono big cat-${esc(x.category)}">${esc(cxMono(x.name))}</span><div><h2>${esc(x.name)}</h2><span class="cx-pill p-${cls}"><i></i>${esc(x.status.text)}</span></div><button class="dock-close" data-act="cx-close" aria-label="Schließen">${I.x}</button></header>
    <div class="cx-body">
      <p class="cx-lead">${esc(x.blurb)}</p>
      ${x.status.detail ? `<p class="cx-detail st-${x.status.state}">${esc(x.status.detail)}</p>` : ""}
      ${x.planned ? `<div class="cx-box"><b>Noch nicht verfügbar</b><p class="muted">Diese Verbindung ist geplant. Sag Bescheid, wenn sie dir wichtig ist, dann kommt sie früher.</p></div>` : ""}
      ${x.steps.length ? `<div class="cx-box"><b>So richtest du es ein</b><ol class="cx-steps">${x.steps.map((s2) => `<li>${esc(s2)}</li>`).join("")}</ol>${x.link ? `<a href="${esc(x.link.url)}" target="_blank" rel="noopener" class="cx-link">${esc(x.link.label)} ${I.out}</a>` : ""}</div>` : ""}
      ${x.fields.length ? `<form class="cx-form" id="cx-form">${x.fields.map(field).join("")}</form>` : ""}
      <p class="cx-msg" id="cx-msg" role="status"></p>
      <div class="cx-btns">
        ${x.can.connect ? `<button type="button" class="btn primary" data-cxa="connect">${connected ? "Speichern & prüfen" : x.fields.length ? "Verbinden" : x.id === "apple-calendar" ? "Verbinden & Zugriff erlauben" : "Verbinden"}</button>` : ""}
        ${x.can.test && connected ? `<button type="button" class="btn" data-cxa="test">Verbindung testen</button>` : ""}
        ${x.can.test && !x.can.connect && x.status.state === "connected" ? "" : ""}
        ${x.can.disconnect && connected ? `<button type="button" class="btn ghost danger" data-cxa="disconnect">Trennen</button>` : ""}
        ${!x.can.connect && x.status.state === "off" && x.id === "confluence" ? `<button type="button" class="btn primary" data-cx-switch="jira">Jira verbinden</button>` : ""}
      </div>
      <div class="cx-box cx-privacy"><b>${I.lock}Datenschutz</b>
        <dl><dt>Liest</dt><dd>${x.reads.map(esc).join("<br>")}</dd>
        <dt>Schreibt</dt><dd>${x.writes.length ? x.writes.map(esc).join("<br>") : "Nichts, nur lesen"}</dd>
        <dt>Verlässt den Mac</dt><dd>${esc(x.leaves)}</dd></dl>
      </div>
    </div>
  </div></div>`);
  const sh = $(".cx-sheet");
  sh.dataset.cx = id;
  requestAnimationFrame(() => sh.classList.add("in"));
  sh.querySelector("input, textarea")?.focus();
  sh.addEventListener("click", (e) => { if (e.target === sh) closeConnector(); });
  sh.querySelector("#cx-form")?.addEventListener("submit", (e) => { e.preventDefault(); cxRun(id, x.can.connect ? "connect" : "test"); });
  sh.querySelector("#cx-form")?.addEventListener("change", () => cxShowIf(sh));
  cxShowIf(sh);
}
function closeConnector(instant) {
  const sh = $(".cx-sheet");
  if (!sh) return;
  if (instant) return sh.remove();
  sh.classList.remove("in");
  setTimeout(() => sh.remove(), 220);
}
async function cxRun(id, action) {
  const sh = $(".cx-sheet");
  const msg = $("#cx-msg");
  if (action === "disconnect" && !confirmInline(sh.querySelector("[data-cxa=disconnect]"))) return;
  const values = cxValues(sh);
  sh.querySelectorAll("[data-cxa]").forEach((b) => (b.disabled = true));
  msg.className = "cx-msg busy";
  msg.textContent = action === "connect" ? (id === "apple-calendar" && !sh.querySelector("#cx-form") ? "Wartet auf deine Freigabe in macOS …" : "Prüft den Zugang …") : action === "test" ? "Testet …" : "Trennt …";
  try {
    const r = await api(`/api/connectors/${encodeURIComponent(id)}/${action}`, { method: "POST", body: { values } });
    msg.className = "cx-msg ok";
    msg.innerHTML = `${SETI.ok}${esc(r.message)}`;
    await loadStatus().catch(() => {});
    await loadConnectors();
    if (action !== "test") setTimeout(() => { if ($(".cx-sheet")?.dataset.cx === id) openConnector(id); const m2 = $("#cx-msg"); if (m2) { m2.className = "cx-msg ok"; m2.innerHTML = `${SETI.ok}${esc(r.message)}`; } }, 50);
    else sh.querySelectorAll("[data-cxa]").forEach((b) => (b.disabled = false));
  } catch (e) {
    msg.className = "cx-msg err";
    msg.textContent = e.message;
    sh.querySelectorAll("[data-cxa]").forEach((b) => (b.disabled = false));
  }
}
function cxValues(sh) {
  const v = {};
  sh.querySelectorAll("#cx-form input:not([type=radio]):not([type=checkbox]), #cx-form select, #cx-form textarea").forEach((el) => { if (el.name) v[el.name] = el.value; });
  sh.querySelectorAll("#cx-form input[type=radio]:checked").forEach((el) => (v[el.name] = el.value));
  sh.querySelectorAll("#cx-form .cx-toggle input").forEach((el) => (v[el.name] = el.checked ? "1" : "0"));
  sh.querySelectorAll("#cx-form .cx-multi").forEach((fs) => (v[fs.dataset.name] = [...fs.querySelectorAll("input:checked")].map((x) => x.value).join(",")));
  return v;
}
/** Felder nur zeigen, wenn ihre Bedingung erfüllt ist (z. B. Zielkalender nur bei "Lesen & schreiben") */
function cxShowIf(sh) {
  const v = cxValues(sh);
  sh.querySelectorAll("[data-show-if]").forEach((el) => { const [f, val] = el.dataset.showIf.split("="); el.hidden = v[f] !== val; });
  sh.querySelectorAll(".cx-choice .cx-opt").forEach((o) => o.classList.toggle("on", o.querySelector("input").checked));
}
// Trennen braucht einen zweiten Klick (keine Browser-Dialoge)
function confirmInline(btn) {
  if (!btn) return true;
  if (btn.dataset.sure) return true;
  btn.dataset.sure = "1";
  btn.textContent = "Wirklich trennen?";
  setTimeout(() => { if (btn.isConnected) { delete btn.dataset.sure; btn.textContent = "Trennen"; } }, 4000);
  return false;
}
document.addEventListener("click", (e) => {
  const co = e.target.closest("[data-cx-open]");
  if (co) { S.cxOpenNext = co.dataset.cxOpen; S.setArea = "verbindungen"; if (location.hash.startsWith("#/einstellungen")) { e.preventDefault(); renderSettings(); } return; }
  const cf = e.target.closest("[data-cxf]");
  if (cf) {
    S.cxFilter = cf.dataset.cxf;
    document.querySelectorAll("[data-cxf]").forEach((b) => b.classList.toggle("on", b === cf));
    document.querySelectorAll(".cx-card").forEach((c2) => { c2.hidden = S.cxFilter !== "all" && !c2.classList.contains("cat-" + S.cxFilter); });
    return;
  }
  const cc = e.target.closest("[data-cx]");
  if (cc && !e.target.closest(".cx-sheet")) return openConnector(cc.dataset.cx);
  const sw = e.target.closest("[data-cx-switch]");
  if (sw) return openConnector(sw.dataset.cxSwitch);
  const ca = e.target.closest("[data-cxa]");
  if (ca) return cxRun($(".cx-sheet").dataset.cx, ca.dataset.cxa);
  if (e.target.closest("[data-act=cx-close]")) return closeConnector();
  const na = e.target.closest(".s2-nav a[data-area]");
  if (na) { e.preventDefault(); history.replaceState(null, "", "#/einstellungen/" + na.dataset.area); S.setArea = na.dataset.area; const q = $("#set-q"); if (q) q.value = ""; filterSettings(""); document.querySelectorAll(".s2-nav a").forEach((a) => a.classList.toggle("on", a === na)); $("#s2-main")?.scrollTo?.({ top: 0 }); window.scrollTo({ top: 0 }); }
});
document.addEventListener("keydown", (e) => { if (e.key === "Escape" && $(".cx-sheet")) { e.stopPropagation(); closeConnector(); } }, true);

function modelBox() {
  const l = S.status?.llm || {};
  const gb = (n) => (n / 1e9).toFixed(1).replace(".", ",");
  const pct = l.total ? Math.round((l.done / l.total) * 100) : l.phase === "ready" ? 100 : 0;
  const right = l.total ? `${gb(l.done)} / ${gb(l.total)} GB` : l.phase === "ready" ? "bereit" : "";
  const sub = {
    ready: "Läuft komplett offline auf diesem Mac.",
    error: "Fehler: " + (l.message || ""),
    unsupported: l.message,
  }[l.phase] || "Einmaliger Download, danach komplett offline.";
  return `<div class="split"><span style="font-weight:500">Lokales Modell</span><span class="mono muted" style="font-size:12px">${esc(right)}</span></div>
    <span class="bar"><span style="width:${pct}%"></span></span>
    <span class="muted" style="font-size:12.5px">${esc(l.phase === "ready" || l.phase === "error" || l.phase === "unsupported" ? sub : (l.message || "Startet") + " · " + sub)}</span>
    ${l.phase === "error" ? `<div><button type="button" class="btn small" data-act="llm-retry">Erneut versuchen</button></div>` : ""}`;
}
