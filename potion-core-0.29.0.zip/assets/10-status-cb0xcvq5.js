// PO-TION Oberfläche · 10-status.js
// Klassische Skripte im gemeinsamen globalen Bereich, Reihenfolge laut ui/js (Dateiname). Start in 99-boot.js.
"use strict";
// ---------- Start ----------
async function loadStatus() {
  S.status = await api("/api/status");
  const pill = $("#model-pill");
  if (pill) pill.innerHTML = modelPill();
  const mb = $("#model-box");
  if (mb) mb.innerHTML = modelBox();
  const sw = $("#mswitch-slot");
  if (sw) sw.innerHTML = modelSwitch();
  const ds = $("#dock-status");
  if (ds) {
    const was = ds.innerHTML !== "";
    ds.innerHTML = dockStatus();
    if (was !== (ds.innerHTML !== "")) requestAnimationFrame(() => document.documentElement.style.setProperty("--dock-h", $("#dock").offsetHeight + "px"));
  }
  document.body.classList.toggle("model-loading", !!S.status?.llm && !["ready", "error", "unsupported"].includes(S.status.llm.phase));
  // Während das Modell lädt oder wechselt, öfter nachsehen
  clearTimeout(loadStatus.t);
  if (S.status?.llm && !["ready", "error", "unsupported"].includes(S.status.llm.phase)) loadStatus.t = setTimeout(() => loadStatus().catch(() => {}), 1000);
}

