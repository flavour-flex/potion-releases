// PO-TION Oberfläche · 01-core.js
// Klassische Skripte im gemeinsamen globalen Bereich, Reihenfolge laut ui/js (Dateiname). Start in 99-boot.js.
// PO-TION (crxs) – Oberfläche (ohne Framework, ohne Build)
"use strict";

const $ = (s, el = document) => el.querySelector(s);
const app = $("#app");
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

// ---------- API ----------
async function api(path, opts = {}) {
  const init = { method: opts.method || "GET", headers: { "x-crxs": "1" } };
  if (opts.body instanceof FormData) init.body = opts.body;
  else if (opts.body !== undefined) {
    init.headers["Content-Type"] = "application/json";
    init.body = JSON.stringify(opts.body);
  }
  const brew = init.method !== "GET";
  if (brew) { api.pending = (api.pending || 0) + 1; document.body.classList.add("brewing"); }
  let r;
  try { r = await fetch(path, init); }
  finally { if (brew && --api.pending <= 0) document.body.classList.remove("brewing"); }
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || `Fehler ${r.status}`);
  if (brew && !path.startsWith("/api/jira/") && typeof jiraAskSoon === "function") jiraAskSoon();
  return data;
}

// ---------- Hinweise und Rückgängig (ein System für alles) ----------
// toast(text) oder toast(text, { undo: async () => {}, undoLabel: "…", link: { href, label } })
// Jede Aktion mit undo landet zusätzlich im Rückgängig-Stapel und ist mit ⌘Z erreichbar.
const UNDO = { stack: [] };
let toastTimer;
function pushUndo(label, fn) {
  if (typeof fn !== "function") return;
  UNDO.stack.push({ label, fn, at: Date.now() });
  if (UNDO.stack.length > 25) UNDO.stack.shift();
}
async function runUndo(entry) {
  if (!entry) return;
  UNDO.stack = UNDO.stack.filter((x) => x !== entry);
  try { await entry.fn(); S.home = null; S.searchIndex = null; toast(`Rückgängig: ${entry.label}`); afterUndo(); }
  catch (x) { toast(x.message); }
}
function afterUndo() {
  if (S.view === "detail" && S.detail) openDetail(S.detail.identifier);
  else if (S.view === "project" && S.project) openProject(S.project.id);
  else if (S.view === "milestone" && S.ms) openMilestone(S.ms.id);
  else route();
  if (document.querySelector(".tl") && S.project) api("/api/projects/" + encodeURIComponent(S.project.id)).then((p) => { S.project = p; closeTimeline(true); openTimeline(null, true); }).catch(() => {});
}
function toast(msg, opt = {}) {
  document.querySelector(".toast-undo")?.remove();
  let entry = null;
  if (opt.undo) { entry = { label: opt.undoLabel || String(msg).replace(/\.$/, ""), fn: opt.undo, at: Date.now() }; UNDO.stack.push(entry); if (UNDO.stack.length > 25) UNDO.stack.shift(); }
  document.body.insertAdjacentHTML("beforeend", `<div class="toast-undo" role="status" aria-live="polite"><span>${esc(msg)}</span>${opt.link ? `<a class="btn small" href="${esc(opt.link.href)}">${esc(opt.link.label)}</a>` : ""}${entry ? `<button class="btn small" data-undo-t title="Rückgängig (⌘Z)">Rückgängig</button>` : ""}<button class="tu-x" data-undo-x aria-label="Schließen">${I.x}</button></div>`);
  const el = $(".toast-undo"); el._entry = entry;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.remove(), entry || opt.link ? 10000 : 3800);
}
document.addEventListener("keydown", (e) => {
  if (!(e.metaKey || e.ctrlKey) || e.shiftKey || e.key.toLowerCase() !== "z") return;
  const t = e.target;
  if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.isContentEditable)) return; // dort gilt das normale Rückgängig beim Tippen
  const last = UNDO.stack[UNDO.stack.length - 1];
  if (!last) { toast("Nichts zum Rückgängigmachen."); e.preventDefault(); return; }
  e.preventDefault();
  runUndo(last);
});
document.addEventListener("click", async (e) => {
  const tu = e.target.closest("[data-undo-t]");
  if (tu) { const el = tu.closest(".toast-undo"); tu.disabled = true; el.remove(); await runUndo(el._entry); return; }
  if (e.target.closest("[data-undo-x]")) e.target.closest(".toast-undo")?.remove();
}, true);
const chatUndoLabel = (reply) => String(reply || "Änderung").split(/[.:\n]/)[0].slice(0, 70);
/** Server-Rückgängig (/api/undo) als Funktion */
const serverUndo = (u) => () => api("/api/undo", { method: "POST", body: u });

// ---------- Icons ----------
const I = {
  search: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.6-3.6"/></svg>`,
  check: (c = "#0E0A14", s = 18) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="${c}" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 12l5 5L20 6"/></svg>`,
  spark: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#B49BFF" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3l2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5z"/></svg>`,
  cal: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#B49BFF" stroke-width="2" stroke-linecap="round" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="3"/><path d="M3 10h18M8 3v4M16 3v4"/></svg>`,
  gear: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#D2CADF" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M2 12h3M19 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1"/></svg>`,
  clip: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#D2CADF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 11.5l-8.6 8.6a5 5 0 0 1-7-7l8.6-8.6a3.5 3.5 0 0 1 5 5l-8.6 8.6a2 2 0 0 1-2.8-2.8l8-8"/></svg>`,
  up: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#0E0A14" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 19V5M5 12l7-7 7 7"/></svg>`,
  back: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 18l-6-6 6-6"/></svg>`,
  out: `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 17L17 7M8 7h9v9"/></svg>`,
  plus: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#92889F" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>`,
  x: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>`,
  folder: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#D2CADF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>`,
};

// Logo: Rundkolben mit Elixier. Blubbert, während die KI arbeitet.
const FLASK = (size = 30) => `<svg class="flask" width="${size}" height="${size}" viewBox="0 0 32 32" aria-hidden="true">
  <defs>
    <linearGradient id="fl-liq" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#B49BFF"/><stop offset="1" stop-color="#7AF0C8"/></linearGradient>
    <clipPath id="fl-clip"><path d="M13.4 5.5v6.1a9 9 0 1 0 5.2 0V5.5z"/></clipPath>
  </defs>
  <g class="fl-body">
    <g clip-path="url(#fl-clip)">
      <path class="fl-liquid" fill="url(#fl-liq)" d="M-16 18.6c3 0 4.5-1.4 8-1.4s5 1.4 8 1.4 4.5-1.4 8-1.4 5 1.4 8 1.4 4.5-1.4 8-1.4 5 1.4 8 1.4 4.5-1.4 8-1.4V40h-48z"/>
      <circle class="fl-b b1" cx="13" cy="25" r="1.4"/>
      <circle class="fl-b b2" cx="18.5" cy="26" r="1"/>
      <circle class="fl-b b3" cx="16" cy="27.5" r="0.8"/>
      <circle class="fl-b b4" cx="20" cy="24" r="0.7"/>
    </g>
    <path d="M13.4 5.5v6.1a9 9 0 1 0 5.2 0V5.5" fill="none" stroke="#F1ECF7" stroke-width="1.8" stroke-linejoin="round"/>
    <path d="M11.6 5.2h8.8" stroke="#F1ECF7" stroke-width="1.8" stroke-linecap="round"/>
  </g>
  <circle class="fl-s s1" cx="16" cy="4" r="1.3"/>
  <circle class="fl-s s2" cx="14.5" cy="4" r="0.9"/>
  <circle class="fl-s s3" cx="17.5" cy="4" r="1"/>
</svg>`;
const WORDMARK = `<span class="brand-name" aria-label="PO-TION">PO<span class="wm-dash">-</span>TION</span>`;

I.proj = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/></svg>`;
I.task = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M8 12.5l2.6 2.6L16 9.5"/></svg>`;
I.flag = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 21V4M5 4h11l-2 4 2 4H5"/></svg>`;
I.help = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M9.5 9.2a2.6 2.6 0 0 1 5 .9c0 1.7-2.5 2.2-2.5 3.9M12 17h.01"/></svg>`;
I.archive = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="5" rx="1.5"/><path d="M5 9v9a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V9M10 13h4"/></svg>`;
I.search = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>`;
I.conf = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 3h9l4 4v14H6z"/><path d="M15 3v4h4M9 12h7M9 16h7"/></svg>`;
I.lock = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>`;
I.cloud = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 18a5 5 0 1 1 1.6-9.7A6 6 0 0 1 20 11a4 4 0 0 1-1 7.9z"/></svg>`;
I.mac = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/></svg>`;
const setViewTheme = (v) => { document.body.dataset.view = v; };
// PO-TION gibt es nur für den Mac: Tastenkürzel immer mit ⌘
const IS_MAC = true;
const MOD = "⌘";
// Tastenkürzel klein im Kopf
function updChip() {
  const u = S.status?.update;
  return u?.available ? `<button class="upd-chip" data-act="upd-open" title="Neue Version verfügbar">${I.spark}Update ${esc(u.latest)}</button>` : "";
}
function updBox(u, current) {
  const cur = `<span class="mono">${esc(current || "")}</span>`;
  if (!u) return `${cur}<button type="button" class="btn small" data-act="upd-check">Nach Updates suchen</button>`;
  if (u.available) return `<div class="upd-new"><div><b>Version ${esc(u.latest)} ist da</b><span class="muted">installiert: ${esc(current)}${u.size ? ` · ${u.size < 1e7 ? (u.size / 1e6).toFixed(1).replace(".", ",") : (u.size / 1e6).toFixed(0)} MB${u.mode === "core" ? " (nur der Code)" : ""}` : ""}</span></div>
    ${u.notes ? `<div class="upd-notes">${esc(u.notes).replace(/\n/g, "<br>")}</div>` : ""}
    <div class="upd-act"><button type="button" class="btn primary" data-act="upd-install">Jetzt aktualisieren</button><span class="muted">PO-TION startet danach neu. Deine Daten bleiben unverändert.</span></div></div>`;
  return `${cur}<span class="muted">${u.error ? esc(u.error) : "Aktuell"}</span><button type="button" class="btn small" data-act="upd-check">Nach Updates suchen</button>`;
}
function hdrSearch() {
  return `<button class="hdr-search" data-act="kbd-search" title="Aufgaben, Projekte und Kennungen durchsuchen">
    <span class="hs-ico">${I.search}</span>
    <span class="hs-text"><span>Suche nach</span><span class="hs-rot" aria-hidden="true"><b><i>Aufgaben</i><i>Projekten</i><i>Meilensteinen</i><i>Kennungen</i><i>Aufgaben</i></b></span></span>
    <span class="hs-keys"><kbd>${MOD}</kbd><kbd>J</kbd></span>
  </button>`;
}

// Eigenes Fenster (Electron): Platz für die Fensterknöpfe, Kopfzeile zum Verschieben
try {
  if (new URLSearchParams(location.search).get("shell") === "electron") sessionStorage.setItem("potion-shell", "electron");
  if (sessionStorage.getItem("potion-shell") === "electron") document.documentElement.classList.add("electron");
} catch {}

// ---------- Zustand ----------
const S = { status: null, home: null, busy: false, pendingUndo: null, view: "home", detail: null };

const secs = (n) => (n >= 90 ? `${Math.round(n / 60)} min` : `${Math.max(1, n)} s`);
function modelPill() {
  const l = S.status?.llm;
  if (!l) return "";
  if (l.phase === "ready") return `<span class="pill"><span class="dot"></span>${l.size === "8b" ? "Genaues Modell bereit" : "Lokales Modell bereit"}</span>`;
  if (l.phase === "error") return `<a class="pill warn" href="#/einstellungen/ki" style="text-decoration:none" title="${esc(l.message)}"><span class="dot"></span>Modell: Fehler · Details</a>`;
  if (l.phase === "unsupported") return `<span class="pill warn"><span class="dot"></span>Ohne Modell</span>`;
  const pct = l.pct ?? (l.total ? Math.round((l.done / l.total) * 100) : null);
  return `<span class="pill load" title="${esc(loadLine(l))}"><span class="dot"></span>${esc(l.message || "Modell startet")}${pct !== null ? ` · ${pct} %` : ""}${pct !== null ? `<span class="pill-bar"><i style="width:${pct}%"></i></span>` : ""}</span>`;
}
function loadLine(l) {
  const bits = [l.stage || l.message || "Startet"];
  if (l.phase === "model" && l.total) bits.push(`${(l.done / 1e9).toFixed(1).replace(".", ",")} von ${(l.total / 1e9).toFixed(1).replace(".", ",")} GB`);
  if (l.eta) bits.push(`noch ca. ${secs(l.eta)}`);
  else if (l.elapsed > (l.expected || 0) && l.phase === "starting") bits.push(`dauert länger als sonst, ${secs(l.elapsed)} bisher`);
  return bits.join(" · ");
}
// Streifen über dem Eingabefeld, solange das Modell lädt
function dockStatus() {
  const l = S.status?.llm;
  if (!l || ["ready", "error", "unsupported"].includes(l.phase)) return "";
  const pct = l.pct ?? 0;
  const name = l.size === "8b" ? "Genaues Modell" : "Schnelles Modell";
  return `<div class="load-strip" role="status"><span class="ls-flask">${FLASK(22)}</span><div class="ls-main"><div class="ls-text"><b>${esc(name)}</b> ${esc(loadLine(l))}</div><span class="ls-bar"><i style="width:${pct}%"></i></span></div><span class="ls-pct">${pct} %</span></div>`;
}

function jiraBtn() {
  const n = S.home?.jiraUnlinked;
  if (!S.status?.jira?.configured && !n) return "";
  return `<button class="jira-btn${n ? " has" : ""}" data-act="jira-inbox" title="Mir zugewiesene Jira-Tickets ohne Aufgabe in PO-TION">Jira${n ? `<b>${n}</b>` : ""}</button>`;
}

function topbar(right = "") {
  return `<header class="top">
    <div class="brand"><a class="brand-link" href="#/" aria-label="PO-TION Startseite"><span class="logo">${FLASK(40)}</span>${WORDMARK}</a></div>
    ${hdrSearch()}<div class="top-right">${updChip()}<span id="model-pill">${modelPill()}</span>${right}${jiraBtn()}<a class="icon-btn" href="#/hilfe" aria-label="Hilfe" title="Hilfe & FAQ">${I.help}</a><a class="icon-btn" href="#/archiv" aria-label="Archiv" title="Archiv">${I.archive}</a><button class="icon-btn" aria-label="Einstellungen" data-act="settings">${I.gear}</button></div>
  </header>`;
}

// ---------- Router ----------
function route() {
  // Antwortfläche gehört zur Ansicht: beim Wechsel schließen
  const target = location.hash;
  if (S.lastHash !== target) {
    S.dockReply = null;
    const rr = $("#dock-reply");
    if (rr) rr.hidden = true;
  }
  S.lastHash = target;
  const jp = $("#jira-pop");
  if (jp) jp.hidden = true;
  closeTimeline(true);
  const m = /^#\/t\/(.+)$/.exec(location.hash);
  if (S.editor && (!m || decodeURIComponent(m[1]) !== S.editor.id)) destroyNotes();
  if (!S.status?.setup) return renderSetup();
  if (location.hash.startsWith("#/einstellungen")) return renderSettings();
  if (location.hash.startsWith("#/archiv")) return renderArchive();
  if (location.hash.startsWith("#/hilfe")) return renderHelp();
  if (location.hash.startsWith("#/kalender")) return renderCalendar();
  closeSearch(true);
  const pm = /^#\/p\/(.+)$/.exec(location.hash);
  if (S.projEditor && (!pm || decodeURIComponent(pm[1]) !== S.projEditor.id)) destroyProjectNotes();
  if (m) return openDetail(decodeURIComponent(m[1]));
  if (pm) return openProject(decodeURIComponent(pm[1]));
  const mm = /^#\/m\/(.+)$/.exec(location.hash);
  if (S.msEditor && (!mm || decodeURIComponent(mm[1]) !== S.msEditor.id)) destroyMsNotes();
  if (mm) return openMilestone(decodeURIComponent(mm[1]));
  return renderHome();
}
window.addEventListener("hashchange", route);
