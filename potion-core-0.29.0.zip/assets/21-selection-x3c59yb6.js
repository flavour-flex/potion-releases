// PO-TION Oberfläche · 21-selection.js
// Klassische Skripte im gemeinsamen globalen Bereich, Reihenfolge laut ui/js (Dateiname). Start in 99-boot.js.
"use strict";
// ================= Mehrfachauswahl =================
const SEL = { ids: new Set(), last: null, opts: null, pending: null };
function selApply() {
  document.querySelectorAll("[data-sel]").forEach((b) => {
    const on = SEL.ids.has(b.dataset.sel);
    b.setAttribute("aria-checked", on ? "true" : "false");
    b.closest(".row, .g-row")?.classList.toggle("selected", on);
  });
  document.body.classList.toggle("selecting", SEL.ids.size > 0);
  drawSelBar();
}
function selClear() { SEL.ids.clear(); SEL.pending = null; SEL.last = null; selApply(); }
new MutationObserver(() => { if (SEL.ids.size || document.querySelector(".row.selected, .g-row.selected")) { clearTimeout(selApply.t); selApply.t = setTimeout(selApply, 30); } }).observe(document.getElementById("app"), { childList: true, subtree: true });
window.addEventListener("hashchange", () => { if (SEL.ids.size) selClear(); });
document.addEventListener("click", (e) => {
  const box = e.target.closest("[data-sel]");
  const row = e.target.closest(".row[data-open], .g-row[data-open]");
  if (!box && !(row && (e.metaKey || e.shiftKey || SEL.ids.size))) return;
  // Im Auswahl-Modus schaltet ein Klick auf die Zeile die Auswahl um, statt zu öffnen
  const id = box ? box.dataset.sel : row.querySelector("[data-sel]")?.dataset.sel;
  if (!id) return;
  e.preventDefault(); e.stopPropagation();
  if (e.shiftKey && SEL.last) {
    const all = [...document.querySelectorAll("[data-sel]")].map((x) => x.dataset.sel);
    const a = all.indexOf(SEL.last), b = all.indexOf(id);
    if (a >= 0 && b >= 0) for (const x of all.slice(Math.min(a, b), Math.max(a, b) + 1)) SEL.ids.add(x);
  } else if (SEL.ids.has(id)) SEL.ids.delete(id); else SEL.ids.add(id);
  SEL.last = id; SEL.pending = null;
  selApply();
}, true);
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && SEL.ids.size && !e.target.closest?.("input, textarea, select")) { e.stopPropagation(); selClear(); }
  if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "a" && SEL.ids.size && !e.target.closest?.("input, textarea, [contenteditable]")) { e.preventDefault(); document.querySelectorAll("[data-sel]").forEach((b) => SEL.ids.add(b.dataset.sel)); selApply(); }
}, true);
async function drawSelBar() {
  let bar = $("#sel-bar");
  if (!SEL.ids.size) { bar?.remove(); return; }
  if (!SEL.opts) { SEL.opts = await api("/api/bulk/options").catch(() => ({ states: [], projects: [] })); }
  if (!bar) { document.body.insertAdjacentHTML("beforeend", `<div id="sel-bar" class="sel-bar" role="toolbar" aria-label="Ausgewählte Aufgaben"></div>`); bar = $("#sel-bar"); }
  const n = SEL.ids.size, P2 = SEL.pending;
  const prioL = ["", "Dringend", "Hoch", "Mittel", "Niedrig"];
  bar.innerHTML = P2
    ? `<span class="sb-n">${n} ${n === 1 ? "Aufgabe" : "Aufgaben"}</span><span class="sb-q">${esc(P2.label)}?</span><button class="btn small primary" data-sb-go>${P2.change.delete ? "Ja, löschen" : "Anwenden"}</button><button class="linkbtn" data-sb-cancel>Abbrechen</button>`
    : `<span class="sb-n">${n} ausgewählt</span>
      <select data-sb="state" aria-label="Status setzen"><option value="">Status …</option>${SEL.opts.states.map((x) => `<option value="${esc(x.value)}">${esc(x.label)}</option>`).join("")}</select>
      <select data-sb="priority" aria-label="Priorität setzen"><option value="">Priorität …</option>${[1, 2, 3, 4].map((k) => `<option value="${k}">${prioL[k]}</option>`).join("")}</select>
      <select data-sb="due" aria-label="Fälligkeit setzen"><option value="">Fällig …</option><option value="today">Heute</option><option value="tomorrow">Morgen</option><option value="friday">Freitag</option><option value="nextweek">Nächsten Montag</option><option value="pick">Datum wählen …</option><option value="none">Keine Fälligkeit</option></select>
      <select data-sb="project" aria-label="Projekt setzen"><option value="">Projekt …</option>${SEL.opts.projects.map((x) => `<option value="${esc(x.name)}">${esc(x.name)}</option>`).join("")}<option value="__none">Ohne Projekt</option></select>
      <button class="btn small danger-ghost" data-sb-del>${I.trash}Löschen</button>
      <button class="tu-x" data-sb-clear aria-label="Auswahl aufheben" title="Auswahl aufheben (Esc)">${I.x}</button>`;
}
function dueFrom(v) {
  const d = new Date(); d.setHours(12, 0, 0, 0);
  const iso = (x) => x.toISOString().slice(0, 10);
  if (v === "today") return iso(d);
  if (v === "tomorrow") { d.setDate(d.getDate() + 1); return iso(d); }
  if (v === "friday") { const add = (5 - d.getDay() + 7) % 7 || 7; d.setDate(d.getDate() + (d.getDay() === 5 ? 0 : add)); return iso(d); }
  if (v === "nextweek") { const add = (8 - d.getDay()) % 7 || 7; d.setDate(d.getDate() + add); return iso(d); }
  return null;
}
document.addEventListener("change", (e) => {
  const sel = e.target.closest?.("[data-sb]");
  if (!sel || !sel.value) return;
  const k = sel.dataset.sb, v = sel.value, opt = sel.options[sel.selectedIndex].text;
  if (k === "state") SEL.pending = { change: { state: v }, label: `Status → „${opt}“` };
  if (k === "priority") SEL.pending = { change: { priority: Number(v) }, label: `Priorität → „${opt}“` };
  if (k === "project") SEL.pending = { change: { project: v === "__none" ? null : v }, label: v === "__none" ? "Aus dem Projekt nehmen" : `Ins Projekt „${opt}“ verschieben` };
  if (k === "due") {
    if (v === "pick") {
      sel.outerHTML = `<input type="date" data-sb-date aria-label="Fälligkeit wählen">`;
      const inp = $("[data-sb-date]"); inp.focus(); inp.showPicker?.();
      inp.addEventListener("change", () => { if (inp.value) { SEL.pending = { change: { due: inp.value }, label: `Fällig am ${inp.value.split("-").reverse().join(".")}` }; drawSelBar(); } });
      return;
    }
    const d = v === "none" ? null : dueFrom(v);
    SEL.pending = { change: { due: d }, label: d ? `Fällig am ${d.split("-").reverse().join(".")}` : "Fälligkeit entfernen" };
  }
  drawSelBar();
});
document.addEventListener("click", async (e) => {
  if (e.target.closest("[data-sb-clear]")) return selClear();
  if (e.target.closest("[data-sb-cancel]")) { SEL.pending = null; return drawSelBar(); }
  if (e.target.closest("[data-sb-del]")) { SEL.pending = { change: { delete: true }, label: "Löschen (ins Archiv)" }; return drawSelBar(); }
  const go = e.target.closest("[data-sb-go]");
  if (go) {
    go.disabled = true; go.textContent = "Ändere …";
    try {
      const r = await api("/api/bulk", { method: "POST", body: { ids: [...SEL.ids], change: SEL.pending.change, confirmed: true } });
      selClear(); S.home = null; S.searchIndex = null;
      toast(r.reply, { undo: serverUndo(r.undo), undoLabel: r.reply.replace(/\.$/, "") });
      reloadView();
    } catch (x) { toast(x.message); go.disabled = false; go.textContent = "Anwenden"; }
  }
});
