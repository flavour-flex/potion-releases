// PO-TION Oberfläche · 09-clicks.js
// Klassische Skripte im gemeinsamen globalen Bereich, Reihenfolge laut ui/js (Dateiname). Start in 99-boot.js.
"use strict";
// ---------- Klicks ----------
document.addEventListener("click", async (e) => {
  const open = e.target.closest("[data-open]");
  if (open) { location.hash = "#/t/" + encodeURIComponent(open.dataset.open); return; }
  const q = e.target.closest("[data-quick]");
  if (q) return quick(q.dataset.quick);
  const u = e.target.closest("[data-undo]");
  if (u) {
    u.disabled = true;
    try {
      await api("/api/undo", { method: "POST", body: JSON.parse(u.dataset.undo) });
      UNDO.stack = UNDO.stack.filter((x) => x.fn.key !== u.dataset.undo);
      u.closest(".msg-actions").remove();
      if (S.view === "project" || S.view === "detail") { toast("Rückgängig gemacht"); reloadView(); }
      else { pushMsg({ role: "assistant", text: "Rückgängig gemacht." }); refreshLists(); }
    }
    catch (ex) { u.disabled = false; toast(ex.message); }
    return;
  }
  if (e.target.closest("[data-act=kbd-chat]")) return focusChat();
  if (e.target.closest("[data-act=kbd-search]")) return openSearch();
  if (e.target.classList?.contains("sp")) return closeSearch();
  const spa = e.target.closest("[data-sp-ask]");
  if (spa) { closeSearch(true); const c = $("#cmd"); if (c) { c.value = spa.dataset.spAsk; focusChat(); } else location.hash = "#/"; return; }
  const spm = e.target.closest("[data-sp-ms]");
  if (spm) { const [, ms] = spm.dataset.spMs.split("|"); closeSearch(true); location.hash = "#/m/" + encodeURIComponent(ms); return; }
  if (e.target.closest(".sp-item")) closeSearch(true);
  const ro = e.target.closest("[data-reopen]");
  if (ro) {
    ro.disabled = true;
    try { const r = await api("/api/archive/reopen", { method: "POST", body: { id: ro.dataset.reopen, archived: ro.dataset.archived === "1" } }); toast(`${r.identifier} ist wieder offen`); S.archive.items = S.archive.items.filter((x) => x.id !== ro.dataset.reopen); drawArchive(); }
    catch (x) { ro.disabled = false; toast(x.message); }
    return;
  }
  const prs = e.target.closest("[data-prestore]");
  if (prs) {
    prs.disabled = true;
    try { await api("/api/archive/project-restore", { method: "POST", body: { id: prs.dataset.prestore } }); toast("Projekt ist zurück"); loadArchive(); }
    catch (x) { prs.disabled = false; toast(x.message); }
    return;
  }
  if (e.target.closest("[data-act=ar-more]")) return loadArchive(true);
  if (e.target.closest("[data-act=upd-open]")) { location.hash = "#/einstellungen/app"; return; }
  if (e.target.closest("[data-act=upd-check]")) {
    const box = $("#upd-box"); box.innerHTML = `<span class="muted">Sehe nach …</span>`;
    try { const u = await api("/api/update/check?force=1"); S.status.update = u; box.innerHTML = updBox(u, S.status.version); } catch (x) { box.innerHTML = `<span class="err">${esc(x.message)}</span>`; }
    return;
  }
  if (e.target.closest("[data-act=upd-install]")) {
    const box = $("#upd-box");
    box.innerHTML = workBox();
    startWorkPoll();
    try { const r = await api("/api/update/install", { method: "POST" }); box.querySelector(".work-label").textContent = `Version ${r.version} wird installiert, PO-TION startet gleich neu …`; }
    catch (x) { stopWorkPoll(); box.innerHTML = `<span class="err">${esc(x.message)}</span><button type="button" class="btn small" data-act="upd-check">Erneut prüfen</button>`; }
    return;
  }
  if (e.target.closest("[data-act=q-refresh]")) return loadQuota(true);
  const qc = e.target.closest("[data-act=q-clean]");
  if (qc) {
    if (!qc.dataset.sure) { qc.dataset.sure = "1"; qc.classList.add("primary"); qc.innerHTML = `Wirklich ${qc.dataset.n} archivieren? Sie bleiben im Archiv sichtbar.`; setTimeout(() => { if (qc.isConnected && qc.dataset.sure) { delete qc.dataset.sure; qc.classList.remove("primary"); loadQuota(); } }, 6000); return; }
    qc.disabled = true; qc.textContent = "Archiviere …";
    try { const r = await api("/api/linear-cleanup", { method: "POST" }); toast(`${r.archived} Aufgaben archiviert`); loadQuota(true); }
    catch (x) { toast(x.message); qc.disabled = false; }
    return;
  }
  const ea = e.target.closest("[data-act=ext-all]");
  if (ea) { ea.closest(".ai-body, .dock-reply")?.querySelector(".ext-list")?.classList.remove("clipped"); ea.remove(); return; }
  if (e.target.closest("[data-act=hist-all]")) { const h = e.target.closest(".hist"); h.querySelector(".hist-list")?.classList.remove("clipped"); e.target.closest("[data-act=hist-all]").remove(); return; }
  const sm = e.target.closest("[data-setup-mode]");
  if (sm) {
    S.setupMode = sm.dataset.setupMode;
    document.querySelectorAll(".ds-opt").forEach((x) => x.classList.toggle("on", x === sm));
    $("#grp-linear")?.classList.toggle("hide-local", S.setupMode !== "linear");
    return;
  }
  const ds = e.target.closest("[data-ds]");
  if (ds) {
    const box = $("#ds-actions");
    const k = ds.dataset.ds;
    const lc = S.status?.backend?.localCounts;
    if (k === "to-local") box.innerHTML = `<div class="ds-choice">
        <button type="button" class="ds-opt on" data-ds="local-import"><b>Alles aus Linear übernehmen</b><span>Offene, erledigte und archivierte Aufgaben, Projekte, Meilensteine und Notizen. Verlauf, Dateien und Jira-Verknüpfungen bleiben erhalten. In Linear wird nichts gelöscht.</span></button>
        ${lc ? `<button type="button" class="ds-opt" data-ds="local-keep"><b>Vorhandene lokale Daten nutzen</b><span>${lc.issues} Aufgaben, ${lc.projects} Projekte von früher.</span></button>` : `<button type="button" class="ds-opt" data-ds="local-empty"><b>Leer starten</b><span>Ohne deine bisherigen Aufgaben.</span></button>`}
        <button type="button" class="linkbtn" data-act="ds-reset">Abbrechen</button></div>`;
    else if (k === "pull") box.innerHTML = `<div class="ds-choice">
        <button type="button" class="ds-opt on" data-ds="pull-merge"><b>Ergänzen</b><span>Holt alles aus Linear, was hier noch fehlt (Aufgaben, Projekte, Meilensteine). Deine lokalen Änderungen bleiben unangetastet.</span></button>
        <button type="button" class="ds-opt" data-ds="pull-replace"><b>Komplett ersetzen</b><span>Lokale Daten werden durch den Stand aus Linear ersetzt. Vorher wird automatisch eine Sicherung angelegt.</span></button>
        <button type="button" class="linkbtn" data-act="ds-reset">Abbrechen</button></div>`;
    else if (k === "pull-merge") dsRun({ mode: "pull", replace: false }, "Holt fehlende Daten aus Linear");
    else if (k === "pull-replace") dsRun({ mode: "pull", replace: true }, "Übernimmt alles aus Linear");
    else if (k === "to-linear") box.innerHTML = `<div class="ds-choice">
        <button type="button" class="ds-opt on" data-ds="linear-export"><b>Lokale Daten nach Linear übertragen</b><span>Legt alle offenen und erledigten Aufgaben und Projekte neu in Linear an. Die IDs ändern sich dabei (neue CHR-Nummern).</span></button>
        <button type="button" class="ds-opt" data-ds="linear-only"><b>Nur umschalten</b><span>Linear wieder als Quelle nutzen. Die lokalen Daten bleiben unverändert auf dem Mac liegen.</span></button>
        <button type="button" class="linkbtn" data-act="ds-reset">Abbrechen</button></div>`;
    else if (k === "local-import") dsRun({ mode: "local", import: true, userName: $("#f-name")?.value }, "Übernimmt alles aus Linear");
    else if (k === "local-keep" || k === "local-empty") dsRun({ mode: "local", import: false, userName: $("#f-name")?.value }, "Stellt um");
    else if (k === "linear-export") dsRun({ mode: "linear", export: true }, "Überträgt nach Linear");
    else if (k === "linear-only") dsRun({ mode: "linear", export: false }, "Stellt um");
    return;
  }
  if (e.target.closest("[data-act=ds-reset]")) { renderSetup(true); return; }
  const tlb = e.target.closest("[data-timeline]");
  if (tlb) return openTimeline(tlb.dataset.timeline || null);
  const tln = e.target.closest("[data-tl-focus]");
  if (tln) return focusTimeline(tln.dataset.tlFocus);
  if (e.target.closest("[data-act=tl-close]") || e.target.classList?.contains("tl")) return closeTimeline();
  const sc = e.target.closest("[data-scroll]");
  if (sc) { e.preventDefault(); document.getElementById(sc.dataset.scroll)?.scrollIntoView({ behavior: "smooth", block: "start" }); return; }
  const ms = e.target.closest("[data-model]");
  if (ms) {
    if (ms.classList.contains("on")) return;
    try {
      await api("/api/model", { method: "POST", body: { size: ms.dataset.model } });
      toast(ms.dataset.model === "8b" ? "Wechsle auf Genau (8B) …" : "Wechsle auf Schnell (4B) …");
      await loadStatus();
    } catch (x) { toast(x.message); }
    return;
  }
  const dop = e.target.closest("[data-draft-open]");
  if (dop) { const m = S.home?.chat.find((x) => x.draft?.id === dop.dataset.draftOpen); if (m) openDraftInDock(m); return; }
  const dt = e.target.closest("[data-dtype]");
  if (dt) {
    const di = dt.closest(".di");
    di.dataset.type = dt.dataset.dtype;
    di.querySelectorAll(".seg-b").forEach((b) => b.classList.toggle("on", b === dt));
    di.querySelector(".di-hint")?.remove();
    return;
  }
  const jn = e.target.closest("[data-jira-new]");
  if (jn) return jiraImport(jn, jn.dataset.jiraNew, null);
  const jas = e.target.closest("[data-jira-assign]");
  if (jas) {
    const id = jas.closest(".jp-item").querySelector(".jp-sel").value;
    if (!id) return toast("Bitte erst eine Aufgabe wählen");
    return jiraImport(jas, jas.dataset.jiraAssign, id);
  }
  if (!e.target.closest("#jira-pop") && !e.target.closest(".jira-btn") && $("#jira-pop") && !$("#jira-pop").hidden) $("#jira-pop").hidden = true;
  const tg = e.target.closest("[data-toggle]");
  if (tg) { patch({ toggle: Number(tg.dataset.toggle) }, true); return; }
  const rm = e.target.closest("[data-rm]");
  if (rm) { e.preventDefault(); patch({ removeItem: Number(rm.dataset.rm) }, true); return; }
  const pf = e.target.closest("[data-pfile]");
  if (pf) { const [identifier, ...n] = pf.dataset.pfile.split("|"); return api("/api/files/open", { method: "POST", body: { identifier, name: n.join("|") } }).catch((x) => toast(x.message)); }
  const fo = e.target.closest("[data-file]");
  if (fo) return api("/api/files/open", { method: "POST", body: { identifier: S.detail.identifier, name: fo.dataset.file } }).catch((x) => toast(x.message));
  const fr = e.target.closest("[data-reveal]");
  if (fr) return api("/api/files/open", { method: "POST", body: { identifier: S.detail.identifier, name: fr.dataset.reveal, reveal: true } }).catch((x) => toast(x.message));
  const act = e.target.closest("[data-act]")?.dataset.act;
  const sy = e.target.closest("[data-say]");
  if (sy) return send(sy.dataset.say);
  const fl = e.target.closest("[data-fill]");
  if (fl) { const c = $("#cmd"); if (c) { c.value = fl.dataset.fill; c.focus(); S.draft = c.value; } return; }
  const pr = e.target.closest("[data-preveal]");
  if (pr) { const [identifier, ...n] = pr.dataset.preveal.split("|"); return api("/api/files/open", { method: "POST", body: { identifier, name: n.join("|"), reveal: true } }).catch((x) => toast(x.message)); }
  const ja = e.target.closest("[data-jira-apply]");
  if (ja) { ja.disabled = true; patch({ state: ja.dataset.jiraApply }, true).then(() => toast("Status übernommen")).catch(() => (ja.disabled = false)); return; }
  const pj = e.target.closest("[data-project]");
  if (pj) { location.hash = "#/p/" + encodeURIComponent(pj.dataset.project); return; }
  const nd = e.target.closest("[data-nudge]");
  if (nd) return nudge(nd);
  if (act === "back") { if (history.length > 1) history.back(); else location.hash = "#/"; return; }
  if (act === "dock-close") { S.dockReply = null; const r = $("#dock-reply"); if (r) r.hidden = true; return; }
  if (act === "jira-inbox") { const p = $("#jira-pop"); if (p && !p.hidden) p.hidden = true; else openJiraInbox(); return; }
  if (act === "jira-close") { $("#jira-pop").hidden = true; return; }
  if (act === "jira-refresh") { openJiraInbox(true); return; }
  if (act === "draft-discard") {
    const f = e.target.closest("form.draft");
    const id = f.dataset.draft;
    api("/api/draft/commit", { method: "POST", body: { draftId: id, discard: true } }).catch(() => {});
    const m = S.home?.chat.find((x) => x.draft?.id === id);
    if (m) m.draftDone = "Verworfen";
    markDraft(id, "Verworfen.");
    S.dockReply = null;
    $("#dock-reply").hidden = true;
    return;
  }
  if (act === "draft-drop") {
    const di = e.target.closest(".di");
    const f = di.closest("form.draft");
    di.remove();
    const n = f.querySelectorAll(".di").length;
    f.querySelector("[type=submit]").textContent = n > 1 ? "Alle anlegen" : "Anlegen";
    return;
  }
  if (act === "intro") { openIntro(true); return; }
  if (act === "toggle-next") { S.showAllNext = !S.showAllNext; renderHome(); return; }
  if (act === "new-project") { const c = $("#cmd"); if (c) { c.value = "Leg ein Projekt an: "; c.focus(); } return; }
  if (act === "settings") location.hash = "#/einstellungen";
  else if (act === "reload") route();
  else if (act === "triage") triage();
  else if (act === "llm-retry") { await api("/api/llm/retry", { method: "POST" }).catch(() => {}); await loadStatus(); }
  else if (act === "tri-apply") applyTriage(e.target.closest("button"));
  else if (act === "pick") {
    try { const r = await api("/api/pick-folder", { method: "POST" }); if (r.path) { $("#f-dir").value = r.path; $("#f-dir").dispatchEvent(new Event("change", { bubbles: true })); } } catch (x) { toast(x.message); }
  } else if (act === "quit") {
    await api("/api/quit", { method: "POST" }).catch(() => {});
    app.innerHTML = `<div class="setup"><div class="setup-card"><h1>PO-TION ist beendet.</h1><p class="lead">Du kannst dieses Fenster schließen. Zum Starten einfach wieder PO-TION öffnen.</p></div></div>`;
  }
});

document.addEventListener("keydown", (e) => {

  if (e.key === "Escape" && S.view === "detail" && !["TEXTAREA", "INPUT", "SELECT"].includes(document.activeElement?.tagName)) location.hash = "#/";
  if (e.key === "Escape" && !drop.hidden && !dropBusy) drop.hidden = true;
});

window.addEventListener("beforeunload", () => {
  const pe = S.projEditor;
  if (pe && pe.draft !== undefined && pe.draft !== pe.saved)
    fetch("/api/projects/" + encodeURIComponent(pe.id), { method: "PATCH", keepalive: true, headers: { "x-crxs": "1", "Content-Type": "application/json" }, body: JSON.stringify({ notes: pe.draft }) });
  const ed = S.editor;
  if (ed && ed.draft !== undefined && ed.draft !== ed.saved)
    fetch("/api/issues/" + encodeURIComponent(ed.id), { method: "PATCH", keepalive: true, headers: { "x-crxs": "1", "Content-Type": "application/json" }, body: JSON.stringify({ notes: ed.draft }) });
});
