// PO-TION Oberfläche · 23-intro.js
// Klassische Skripte im gemeinsamen globalen Bereich, Reihenfolge laut ui/js (Dateiname). Start in 99-boot.js.
"use strict";
// ================= Einführung für neue Nutzer =================
const CAP_KEY = () => (S.status?.capture?.label || "⌘⇧2");
function introSteps() {
  const k = (x) => `<kbd>${x}</kbd>`;
  return [
    { icon: FLASK(46), title: "Willkommen bei PO-TION", text: `Dein Arbeitsplatz für Aufgaben, Projekte und Termine. Die KI läuft lokal auf deinem Mac. Was du schreibst, verlässt ihn nur Richtung Linear und Jira, wenn du sie verbindest.`, demo: `<div class="in-demo ind-chat"><span class="in-bubble">Leg eine Aufgabe an: Release-Notes prüfen bis Freitag 14 Uhr</span><span class="in-arrow">→</span><span class="in-card"><b>Release-Notes prüfen</b><small>Fällig Fr 14:00 · Projekt erkannt</small></span></div>` },
    { icon: I.spark, title: "Einfach schreiben", text: `Unten ist der Chat (${k(MOD + "K")}). Leg Aufgaben an, frag „Was ist bis Montag fällig?“ oder „Fasse die Kommentare zusammen“. Vorschläge prüfst du, bevor etwas angelegt wird. Unter jeder Antwort steht, worauf sie sich stützt.`, demo: `<div class="in-demo ind-chips"><span>Was hängt?</span><span>Plan meinen Tag</span><span>Überfällig?</span><span>Was ist bis Montag fällig?</span></div>` },
    { icon: I.search, title: "Finden und handeln per Tastatur", text: `${k(MOD + "J")} sucht in Aufgaben, Projekten, Kommentaren, Hilfe, Jira und Confluence. ${k(MOD + ".")} zeigt alle Aktionen für das, was gerade offen ist, z. B. Status, Fälligkeit oder Umwandeln. ${k(MOD + "Z")} macht die letzte Änderung rückgängig.`, demo: `<div class="in-demo ind-keys">${k(MOD + "J")}<span>Suchen</span>${k(MOD + ".")}<span>Aktionen</span>${k(MOD + "K")}<span>Chat</span>${k(MOD + "Z")}<span>Rückgängig</span></div>` },
    { icon: I.proj, title: "Projekte, Meilensteine, Aufgaben", text: `Projekte haben Meilensteine, Meilensteine haben Aufgaben, Aufgaben haben Checklisten. Falsch angelegt? Über ${k("⋯")} wandelst du alles ineinander um. Im Zeitstrahl ziehst du Aufgaben zwischen Meilensteine. In Listen wählst du mit dem Kästchen links oder ${k("⇧")} mehrere Aufgaben auf einmal aus.`, demo: `<div class="in-demo ind-tree"><span>${I.proj}Projekt</span><span>${I.flag}Meilenstein</span><span>${I.task}Aufgabe</span><span>☐ Checkliste</span></div>` },
    { icon: I.cal, title: "Dein Tag", text: `„Heute“ zeigt Termine und Fristen, „Plan meinen Tag“ verteilt Aufgaben in deine freie Zeit. Fristen können eine Uhrzeit haben, PO-TION erinnert dich vorher. Termine ohne Titel benennst du im Kalender per Doppelklick.`, demo: `<div class="in-demo ind-day"><span class="d1">09:00 Jour fixe</span><span class="d2">10:00 Fokus: Löschkonzept</span><span class="d3">14:00 Frist Release-Notes</span></div>` },
    { icon: I.clip || I.task, title: "Screenshots und Dateien", text: `Mit ${k(CAP_KEY())} machst du überall am Mac einen Screenshot und legst ihn direkt an eine Aufgabe, die KI fasst den Inhalt zusammen. Dateien ziehst du einfach ins Fenster. PDF, PowerPoint, Word, Excel und Mails kann die KI lesen.`, demo: `<div class="in-demo ind-drop"><span>📎 Angebot.pdf</span><span class="in-arrow">→</span><span>CHR-142</span></div>` },
    { icon: I.help, title: "Verbinden, was du brauchst", text: `Unter Einstellungen → Schnittstellen richtest du Linear, Jira, Confluence und Kalender ein. Jira ändert PO-TION nie von selbst, nur nach deinem Klick. Fragen beantwortet die Hilfe, die Einführung findest du dort jederzeit wieder.`, demo: `<div class="in-demo ind-cx"><span>Linear</span><span>Jira</span><span>Confluence</span><span>Kalender</span></div>`, last: true },
  ];
}
function openIntro(manual) {
  if ($(".onb")) return;
  const steps = introSteps();
  let k = 0;
  document.body.insertAdjacentHTML("beforeend", `<div class="onb" role="dialog" aria-modal="true" aria-label="Einführung"><div class="in-card-box"><button class="tu-x in-x" data-in="close" aria-label="Einführung schließen">${I.x}</button><div class="in-body"></div><div class="in-foot"><div class="in-dots"></div><div class="in-btns"></div></div></div></div>`);
  const box = $(".onb");
  const draw = () => {
    const st = steps[k];
    box.querySelector(".in-body").innerHTML = `<div class="in-ico">${st.icon}</div><h2>${esc(st.title)}</h2><p>${st.text}</p>${st.demo || ""}`;
    box.querySelector(".in-dots").innerHTML = steps.map((_, j) => `<button class="in-dot${j === k ? " on" : ""}" data-in-go="${j}" aria-label="Schritt ${j + 1}"></button>`).join("");
    box.querySelector(".in-btns").innerHTML = `${k > 0 ? `<button class="btn small" data-in="prev">Zurück</button>` : `<button class="linkbtn" data-in="close">Überspringen</button>`}${st.last ? `<button class="btn small" data-in="cx">Schnittstellen öffnen</button><button class="btn small primary" data-in="close">Los geht's</button>` : `<button class="btn small primary" data-in="next">Weiter</button>`}`;
    box.querySelector(".in-body").classList.remove("anim"); void box.offsetWidth; box.querySelector(".in-body").classList.add("anim");
  };
  const close = () => { box.classList.add("out"); setTimeout(() => box.remove(), 220); if (!manual || !S.status?.introSeen) { api("/api/settings/patch", { method: "POST", body: { introSeen: true } }).catch(() => {}); if (S.status) S.status.introSeen = true; } };
  box.addEventListener("click", (e) => {
    const b = e.target.closest("[data-in]");
    const g = e.target.closest("[data-in-go]");
    if (g) { k = Number(g.dataset.inGo); draw(); return; }
    if (!b) { if (e.target === box) close(); return; }
    const a = b.dataset.in;
    if (a === "next") { k = Math.min(steps.length - 1, k + 1); draw(); }
    if (a === "prev") { k = Math.max(0, k - 1); draw(); }
    if (a === "close") close();
    if (a === "cx") { close(); location.hash = "#/einstellungen/verbindungen"; }
  });
  box.addEventListener("keydown", (e) => {
    if (e.key === "ArrowRight") { k = Math.min(steps.length - 1, k + 1); draw(); }
    if (e.key === "ArrowLeft") { k = Math.max(0, k - 1); draw(); }
    if (e.key === "Escape") { e.stopPropagation(); close(); }
  });
  draw();
  requestAnimationFrame(() => { box.classList.add("in"); box.querySelector("[data-in=next]")?.focus(); });
}
