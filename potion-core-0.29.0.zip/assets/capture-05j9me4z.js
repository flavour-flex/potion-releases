// PO-TION: kleines Fenster nach einem Screenshot (⌘⇧2). Ziel wählen, Name, KI-Zusammenfassung.
(() => {
  const $ = (s) => document.querySelector(s);
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const token = new URLSearchParams(location.search).get("token") || "";
  const IC = {
    task: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M8.5 12.5l2.5 2.5 4.5-5"/></svg>`,
    proj: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/></svg>`,
    plus: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>`,
    search: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.6-3.6"/></svg>`,
    spark: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5z"/></svg>`,
    flask: `<svg width="18" height="18" viewBox="0 0 32 32" fill="none"><path d="M12 4h8M13 4v8L6.5 24.5A2.5 2.5 0 0 0 8.7 28h14.6a2.5 2.5 0 0 0 2.2-3.5L19 12V4" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M9.5 20h13l2.4 4.8a1 1 0 0 1-.9 1.4H8a1 1 0 0 1-.9-1.4z" fill="var(--accent)" opacity=".85"/></svg>`,
  };
  async function api(path, body) {
    const r = await fetch(path, body === undefined ? { headers: { "x-crxs": "1" } } : { method: "POST", headers: { "x-crxs": "1", "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || "Fehler " + r.status);
    return d;
  }
  const close = () => setTimeout(() => window.close(), 30);

  const S = { items: [], recent: [], projects: [], sel: 0, list: [], summarize: true, modelReady: true, busy: false };

  function render() {
    $("#cap").innerHTML = `
      <header class="cap-head">${IC.flask}<b>Screenshot ablegen</b><span class="cap-hint"><kbd>esc</kbd> verwerfen</span></header>
      <figure class="cap-shot"><img src="/api/capture/img/${encodeURIComponent(token)}" alt="Vorschau der Aufnahme"></figure>
      <label class="cap-name"><span>Name</span><input id="cap-name" autocomplete="off" spellcheck="false"></label>
      <div class="cap-where">
        <label class="cap-q">${IC.search}<input id="cap-q" placeholder="Aufgabe oder Projekt suchen, oder neue Aufgabe eintippen …" autocomplete="off" spellcheck="false"></label>
        <div class="cap-list" id="cap-list" role="listbox"></div>
      </div>
      <label class="cap-ai"><input type="checkbox" id="cap-ai"><span class="cap-sw" aria-hidden="true"></span><span class="cap-ai-t">${IC.spark}<span><b>Text auslesen und in den Notizen zusammenfassen</b><small id="cap-ai-sub">Erkennt den Text auf dem Mac (Apple Vision), das lokale Modell fasst zusammen.</small></span></span></label>
      <footer class="cap-foot"><span class="cap-err" id="cap-err" role="alert"></span><button class="btn" id="cap-cancel">Verwerfen</button><button class="btn primary" id="cap-ok" disabled>Ablegen <kbd>↵</kbd></button></footer>`;
  }

  function score(it, words) {
    const t = (it.title + " " + it.id).toLowerCase(), sub = (it.sub || "").toLowerCase();
    let sc = 0;
    for (const w of words) {
      if (it.id.toLowerCase() === w) sc += 100;
      else if (t.split(/[^a-z0-9äöüß-]+/).some((x) => x.startsWith(w))) sc += 20;
      else if (t.includes(w)) sc += 10;
      else if (sub.includes(w)) sc += 4;
      else return 0;
    }
    return sc + (it.t === "project" ? 5 : 0);
  }
  function draw() {
    const q = $("#cap-q").value.trim();
    const words = q.toLowerCase().split(/\s+/).filter(Boolean);
    let list;
    if (!words.length) list = [...S.recent.map((x) => ({ ...x, grp: "Zuletzt" })), ...S.projects.map((x) => ({ ...x, grp: "Projekte" }))];
    else {
      list = S.items.map((it) => ({ it, sc: score(it, words) })).filter((x) => x.sc > 0).sort((a, b) => b.sc - a.sc).slice(0, 7).map((x) => ({ ...x.it, grp: "Treffer" }));
      if (!/^[a-z]{2,6}-\d+$/i.test(q)) list.push({ t: "new", id: "", title: q, sub: "Neue Aufgabe anlegen", grp: "Neu" });
    }
    S.list = list;
    S.sel = Math.min(S.sel, Math.max(0, list.length - 1));
    let last = "";
    $("#cap-list").innerHTML = list.length ? list.map((it, k) => {
      const head = it.grp !== last ? `<div class="cap-grp">${esc(it.grp)}</div>` : "";
      last = it.grp;
      const ico = it.t === "project" ? IC.proj : it.t === "new" ? IC.plus : IC.task;
      return `${head}<button class="cap-item t-${it.t}${k === S.sel ? " sel" : ""}" data-k="${k}" role="option" aria-selected="${k === S.sel}"><span class="cap-ico">${ico}</span><span class="cap-main"><span class="cap-title">${it.t === "task" ? `<span class="idf">${esc(it.id)}</span>` : ""}${it.t === "new" ? `„${esc(it.title)}“` : esc(it.title)}</span><span class="cap-sub">${esc(it.sub || "")}</span></span></button>`;
    }).join("") : `<p class="cap-empty">Noch keine Aufgaben. Tipp einen Titel ein, dann lege ich eine neue an.</p>`;
    $("#cap-ok").disabled = !list.length || S.busy;
    $("#cap-list .sel")?.scrollIntoView({ block: "nearest" });
  }

  async function commit() {
    const it = S.list[S.sel];
    if (!it || S.busy) return;
    S.busy = true;
    $("#cap-ok").disabled = true;
    $("#cap-err").textContent = "";
    $("#cap").classList.add("saving");
    const body = { token, name: $("#cap-name").value.trim(), summarize: $("#cap-ai").checked };
    if (it.t === "task") body.identifier = it.id;
    else if (it.t === "project") body.projectId = it.id;
    else body.newTaskTitle = it.title;
    try {
      const r = await api("/api/capture/commit", body);
      $("#cap").innerHTML = `<div class="cap-done"><span class="cap-check"><svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></span>
        <b>Abgelegt</b><span>${esc(r.target.label)}</span>${r.summarizing ? `<small>${IC.spark} Text wird ausgelesen und zusammengefasst. Das Ergebnis steht gleich in den Notizen.</small>` : ""}</div>`;
      setTimeout(close, r.summarizing ? 1800 : 1100);
    } catch (e) {
      S.busy = false;
      $("#cap").classList.remove("saving");
      $("#cap-err").textContent = e.message;
      $("#cap-ok").disabled = false;
    }
  }
  async function discard() {
    try { await api("/api/capture/discard", { token }); } catch {}
    close();
  }

  async function start() {
    render();
    const name = $("#cap-name"), q = $("#cap-q"), ai = $("#cap-ai");
    q.focus();
    const [cfg, tg, idx] = await Promise.all([
      api("/api/capture/config").catch(() => ({ summarize: true })),
      api("/api/capture/targets").catch(() => ({ recent: [], projects: [], modelReady: true })),
      api("/api/search-index").catch(() => ({ items: [] })),
    ]);
    const now = new Date();
    name.value = `Screenshot ${String(now.getHours()).padStart(2, "0")}.${String(now.getMinutes()).padStart(2, "0")} Uhr`;
    ai.checked = cfg.summarize !== false;
    if (!tg.modelReady) $("#cap-ai-sub").textContent = "Das Sprachmodell startet noch. Die Zusammenfassung kommt, sobald es bereit ist.";
    S.recent = tg.recent || [];
    S.projects = tg.projects || [];
    S.items = (idx.items || []).filter((x) => !x.done && (x.t === "task" || x.t === "project"));
    if (!S.recent.length && !S.projects.length) S.projects = S.items.filter((x) => x.t === "project").slice(0, 4);
    draw();
    q.addEventListener("input", () => { S.sel = 0; draw(); });
    $("#cap-list").addEventListener("click", (e) => { const b = e.target.closest(".cap-item"); if (b) { S.sel = Number(b.dataset.k); draw(); commit(); } });
    $("#cap-ok").addEventListener("click", commit);
    $("#cap-cancel").addEventListener("click", discard);
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") { e.preventDefault(); discard(); }
      else if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        if (document.activeElement === name) return;
        e.preventDefault();
        S.sel = Math.max(0, Math.min(S.list.length - 1, S.sel + (e.key === "ArrowDown" ? 1 : -1)));
        draw();
      } else if (e.key === "Enter" && !e.isComposing) { e.preventDefault(); commit(); }
    });
  }
  start().catch((e) => { $("#cap").innerHTML = `<p class="cap-empty">${esc(e.message)}</p>`; });
})();
