// PO-TION Oberfläche · 22-palette.js
// Klassische Skripte im gemeinsamen globalen Bereich, Reihenfolge laut ui/js (Dateiname). Start in 99-boot.js.
"use strict";
// ================= Befehlspalette (⌘. oder ">" in der Suche) =================
const SP_ACTS = { list: [] };
function paletteScopeLabel() {
  if (S.view === "detail" && S.detail) return S.detail.identifier;
  if (S.view === "project" && S.project) return S.project.name;
  if (S.view === "milestone" && S.ms) return S.ms.name;
  return "";
}
function paletteActions() {
  const A = [];
  const add = (label, run, o = {}) => A.push({ label, run, ...o });
  const KL = { planned: "Geplant", doing: "In Arbeit", vendor: "Beim Dienstleister", waiting: "Wartet auf", review: "Abnahme", done: "Erledigt", later: "Später", inbox: "Eingang" };
  if (S.view === "detail" && S.detail) {
    const d = S.detail;
    for (const [k, l] of Object.entries(KL)) if (k !== d.kind) add(`Status: ${l}`, () => patch({ state: k }, true), { ctx: true, icon: I.task, keys: "status" });
    [[1, "Dringend"], [2, "Hoch"], [3, "Mittel"], [4, "Niedrig"]].forEach(([k, l]) => { if (k !== d.priority) add(`Priorität: ${l}`, () => patch({ priority: k }, true), { ctx: true, icon: I.flag, keys: "prio" }); });
    [["today", "heute"], ["tomorrow", "morgen"], ["friday", "Freitag"], ["nextweek", "nächsten Montag"]].forEach(([k, l]) => add(`Fällig ${l}`, () => patch({ due: dueFrom(k) }, true), { ctx: true, icon: I.cal, keys: "fällig datum frist" }));
    if (d.due) add("Fälligkeit entfernen", () => patch({ due: null, dueTime: null }, true), { ctx: true, icon: I.cal, keys: "fällig datum frist" });
    add("Kommentar schreiben", () => { const t = $("#cmts .cm-compose .cm-input"); t?.scrollIntoView({ block: "center", behavior: "smooth" }); t?.focus(); }, { ctx: true, icon: I.edit || I.spark });
    add("Kommentare zusammenfassen", () => $("[data-cm-sum]")?.click(), { ctx: true, icon: I.spark, keys: "ki" });
    add("Umwandeln in Projekt", () => runTransform({ op: "task-to-project", ident: d.identifier }), { ctx: true, icon: I.swap });
    if (d.projectId) add("Umwandeln in Meilenstein", () => runTransform({ op: "task-to-milestone", ident: d.identifier }), { ctx: true, icon: I.swap });
    add("Umwandeln in Checklisten-Punkt …", () => { const b = document.querySelector('[data-more="task"]'); if (b) { openMore("task", b, d.identifier); $('[data-cm="to-check"]')?.click(); } }, { ctx: true, icon: I.swap });
    add(`${d.identifier} löschen`, () => runTransform({ op: "delete-task", ident: d.identifier }, "home"), { ctx: true, icon: I.trash, danger: true });
  }
  if (S.view === "project" && S.project) {
    const p = S.project;
    add("Neue Aufgabe im Projekt", () => fillChat("Neue Aufgabe: "), { ctx: true, icon: I.task });
    add("Neuer Meilenstein", () => fillChat("Neuer Meilenstein: "), { ctx: true, icon: I.flag });
    add("Zeitstrahl öffnen", () => openTimeline(null), { ctx: true, icon: I.flag });
    add("Kommentar schreiben", () => { const t = $("#cmts .cm-compose .cm-input"); t?.scrollIntoView({ block: "center", behavior: "smooth" }); t?.focus(); }, { ctx: true, icon: I.spark });
    add("Projekt in Aufgabe umwandeln", () => runTransform({ op: "project-to-task", projectId: p.id }), { ctx: true, icon: I.swap, danger: true });
    add(`Projekt „${p.name}“ löschen …`, () => { const b = document.querySelector('[data-more="project"]'); if (b) { openMore("project", b, p.id); $('[data-cm="del-project"]')?.click(); } }, { ctx: true, icon: I.trash });
  }
  if (S.view === "milestone" && S.ms) {
    const m = S.ms;
    add("Neue Aufgabe im Meilenstein", () => fillChat("Neue Aufgabe: "), { ctx: true, icon: I.task });
    add("Im Zeitstrahl zeigen", () => { S.pendingTimeline = m.id; location.hash = "#/p/" + encodeURIComponent(m.project.id); }, { ctx: true, icon: I.flag });
    add("Kommentar schreiben", () => { const t = $("#cmts .cm-compose .cm-input"); t?.scrollIntoView({ block: "center", behavior: "smooth" }); t?.focus(); }, { ctx: true, icon: I.spark });
    add("Meilenstein in Aufgabe umwandeln", () => runTransform({ op: "milestone-to-task", milestoneId: m.id }), { ctx: true, icon: I.swap });
    add(`Meilenstein „${m.name}“ löschen`, () => runTransform({ op: "delete-milestone", milestoneId: m.id }, "toProject"), { ctx: true, icon: I.trash, danger: true });
  }
  add("Neue Aufgabe", () => fillChat("Neue Aufgabe: "), { icon: I.task, keys: "anlegen erstellen" });
  add("Plan meinen Tag", () => { location.hash = "#/"; setTimeout(() => document.querySelector('[data-quick="plan"]')?.click(), 250); }, { icon: I.cal });
  add("Kalender öffnen", () => (location.hash = "#/kalender"), { icon: I.cal });
  add("Startseite", () => (location.hash = "#/"), { icon: I.task, keys: "home" });
  add("Archiv öffnen", () => (location.hash = "#/archiv"), { icon: I.archive });
  add("Einstellungen", () => (location.hash = "#/einstellungen"), { icon: I.help, keys: "settings" });
  add("Schnittstellen verwalten", () => (location.hash = "#/einstellungen/verbindungen"), { icon: I.help, keys: "jira linear kalender verbindung" });
  add("Hilfe & FAQ", () => (location.hash = "#/hilfe"), { icon: I.help });
  add("Einführung ansehen", () => openIntro(true), { icon: I.spark, keys: "tour onboarding" });
  if (UNDO.stack.length) add(`Rückgängig: ${UNDO.stack[UNDO.stack.length - 1].label}`, () => runUndo(UNDO.stack[UNDO.stack.length - 1]), { icon: I.swap, sub: "⌘Z", keys: "undo" });
  return A;
}
function fillChat(text) {
  const c = $("#cmd");
  if (c) { c.value = text; c.focus(); c.setSelectionRange(text.length, text.length); c.dispatchEvent(new Event("input")); }
}
document.addEventListener("click", (e) => {
  const b = e.target.closest("[data-sp-act]");
  if (!b) return;
  e.preventDefault(); e.stopPropagation();
  const a = SP_ACTS.list[Number(b.dataset.spAct)];
  if (!a) return;
  if (a.danger && !b.dataset.sure) { b.dataset.sure = "1"; b.querySelector(".sp-t").textContent = a.label + " – wirklich? ↵ nochmal"; b.classList.add("sure"); return; }
  closeSearch(true);
  setTimeout(() => a.run(), 30);
}, true);
