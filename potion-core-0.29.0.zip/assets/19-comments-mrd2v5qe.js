// PO-TION Oberfläche · 19-comments.js
// Klassische Skripte im gemeinsamen globalen Bereich, Reihenfolge laut ui/js (Dateiname). Start in 99-boot.js.
"use strict";
// ================= Kommentare =================
function srcBadge(c) {
  if (c.source === "jira") return c.url ? `<a class="cm-src jira" href="${esc(c.url)}" target="_blank" rel="noopener">Jira ${esc(c.key || "")}</a>` : `<span class="cm-src jira">Jira ${esc(c.key || "")}</span>`;
  if (c.source === "linear") return `<span class="cm-src">Linear</span>`;
  return `<span class="cm-src potion">PO-TION</span>`;
}
function fmtComment(text) {
  const inline = (x) => esc(x)
    .replace(/\*\*([^*]+)\*\*/g, "<b>$1</b>")
    .replace(/\[([^\]]+)\]\((https?:[^)\s]+)\)/g, (m0, a, h) => `<a href="${h}" target="_blank" rel="noopener">${a}</a>`)
    .replace(/(^|[\s(])(https?:\/\/[^\s<)]+)/g, (m0, pre, h) => `${pre}<a href="${h}" target="_blank" rel="noopener">${h.length > 60 ? h.slice(0, 57) + "…" : h}</a>`);
  const out = []; let list = null;
  for (const l of String(text || "").replace(/\r/g, "").split("\n")) {
    const li = /^\s*[-*•]\s+(.*)$/.exec(l);
    if (li) { if (!list) { list = []; out.push(list); } list.push(inline(li[1])); continue; }
    list = null;
    out.push(l.trim() ? `<p>${inline(l)}</p>` : "");
  }
  return out.map((x) => Array.isArray(x) ? `<ul>${x.map((y) => `<li>${y}</li>`).join("")}</ul>` : x).join("");
}
const CMT = { target: null, data: null, draft: {} };
async function loadComments(target, fresh) {
  const box = $("#cmts");
  if (!box || box.dataset.target !== target) return;
  if (!CMT.data || CMT.target !== target) box.innerHTML = `<div class="sec-head" style="padding:0"><h2>Kommentare</h2><span>werden geladen …</span></div>`;
  try {
    const d = await api("/api/comments?target=" + encodeURIComponent(target) + (fresh ? "&fresh=1" : ""));
    if ($("#cmts")?.dataset.target !== target) return;
    CMT.target = target; CMT.data = d;
    drawComments();
  } catch (e) { box.innerHTML = `<div class="sec-head" style="padding:0"><h2>Kommentare</h2></div><p class="err">${esc(e.message)}</p>`; }
}
function drawComments() {
  const box = $("#cmts"), d = CMT.data;
  if (!box || !d) return;
  const keep = box.querySelector(".cm-compose .cm-input")?.value ?? CMT.draft[d.target] ?? "";
  const n = d.comments.length;
  const where = d.storage === "linear" ? "in Linear" : "in PO-TION";
  const isTask = d.target.startsWith("i:");
  const s = d.summary;
  const summary = s ? `<div class="cm-sum">
      <div class="cm-sum-h">${I.spark}<b>Zusammenfassung</b><span class="muted">Stand ${esc(fmtWhen(s.at))} · ${s.count} ${s.count === 1 ? "Kommentar" : "Kommentare"}${n > s.count ? ` · <span class="hot">${n - s.count} neu seitdem</span>` : ""}</span><button class="tu-x" data-cm-sum-x aria-label="Zusammenfassung ausblenden">${I.x}</button></div>
      <p>${esc(s.kurz)}</p>
      ${s.offen.length ? `<div class="cm-sum-l"><small>Offen</small><ul>${s.offen.map((x, k) => `<li><span>${esc(x)}</span>${isTask ? `<button class="linkbtn" data-cm-tocheck="${k}" title="Als Checklisten-Punkt übernehmen">+ Checkliste</button>` : ""}</li>`).join("")}</ul></div>` : ""}
      ${s.entscheidungen.length ? `<div class="cm-sum-l"><small>Entschieden</small><ul>${s.entscheidungen.map((x) => `<li><span>${esc(x)}</span></li>`).join("")}</ul></div>` : ""}
    </div>` : "";
  const item = (c) => `<article class="cm-item src-${c.source}${c.mine ? " mine" : ""}" data-cm-id="${esc(c.id)}">
      <span class="cm-av" aria-hidden="true">${esc((c.who || "?").trim().slice(0, 1).toUpperCase())}</span>
      <div class="cm-main">
        <div class="cm-head"><b>${esc(c.who || "Unbekannt")}</b>${srcBadge(c)}${(c.alsoJira || []).map((j) => `<a class="cm-src jira" href="${esc(j.url)}" target="_blank" rel="noopener" title="Auch in Jira gepostet">+ Jira ${esc(j.key)}</a>`).join("")}<time title="${esc(new Date(c.at).toLocaleString("de-DE"))}">${esc(fmtWhen(c.at))}</time>${c.editedAt ? `<span class="muted">bearbeitet</span>` : ""}
          ${c.editable ? `<span class="cm-acts"><button class="linkbtn" data-cm-edit>Bearbeiten</button><button class="linkbtn danger" data-cm-del>Löschen</button></span>` : ""}</div>
        <div class="cm-body">${fmtComment(c.body)}</div>
      </div>
    </article>`;
  const jira = isTask && d.jiraKeys.length ? (d.jiraWrite
    ? `<div class="cm-jira"><span class="muted">Auch in Jira posten:</span>${d.jiraKeys.map((k) => `<label class="cm-jk"><input type="checkbox" data-cm-jira="${esc(k)}"><span>${esc(k)}</span></label>`).join("")}</div>`
    : `<span class="muted cm-jira">Jira-Kommentare: nur lesen</span>`) : "";
  box.innerHTML = `<div class="sec-head" style="padding:0"><h2>Kommentare</h2><span class="cm-meta">${n ? `${n} im Verlauf · ` : ""}gespeichert ${where}${d.jiraKeys.length ? ` + Jira ${d.jiraKeys.map(esc).join(", ")}` : ""}</span>${n ? `<button class="btn small cm-sum-btn" data-cm-sum>${I.spark}${s ? "Neu zusammenfassen" : "Zusammenfassen"}</button>` : ""}</div>
    ${d.jiraError ? `<p class="hot" style="font-size:12.5px;margin:0">${esc(d.jiraError)}</p>` : ""}
    ${summary}
    ${n ? "" : `<p class="muted cm-empty">Kommentare erscheinen im Verlauf darunter. Die KI kann sie später auswerten, z. B. „Fasse die Kommentare zusammen“.</p>`}
    <div class="cm-compose">
      <textarea class="cm-input" rows="2" placeholder="Kommentar schreiben … (⌘↵ senden)" aria-label="Kommentar schreiben">${esc(keep)}</textarea>
      <div class="cm-row">${jira}<button class="btn small primary" data-cm-send>Kommentieren</button></div>
    </div>`;
  const ta = box.querySelector(".cm-compose .cm-input");
  const grow = () => { ta.style.height = "auto"; ta.style.height = Math.min(320, ta.scrollHeight + 2) + "px"; };
  ta.addEventListener("input", () => { CMT.draft[d.target] = ta.value; grow(); });
  ta.addEventListener("keydown", (e) => { if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) { e.preventDefault(); e.stopPropagation(); sendComment(); } });
  grow();
  syncJiraLabel();
}
function syncJiraLabel() {
  const box = $("#cmts"); if (!box) return;
  const keys = [...box.querySelectorAll("[data-cm-jira]:checked")].map((x) => x.dataset.cmJira);
  const b = box.querySelector("[data-cm-send]");
  if (b) b.textContent = keys.length ? `Kommentieren + in Jira ${keys.join(", ")} posten` : "Kommentieren";
}
async function sendComment() {
  const box = $("#cmts"), d = CMT.data;
  if (!box || !d) return;
  const ta = box.querySelector(".cm-compose .cm-input"), body = ta.value.trim();
  if (!body) { ta.focus(); return; }
  const jira = [...box.querySelectorAll("[data-cm-jira]:checked")].map((x) => x.dataset.cmJira);
  const btn = box.querySelector("[data-cm-send]"); btn.disabled = true; btn.textContent = "Sende …";
  try {
    const r = await api("/api/comments", { method: "POST", body: { target: d.target, body, jira, confirmedJira: jira.length > 0 } });
    CMT.draft[d.target] = ""; ta.value = "";
    CMT.data = r.thread; drawComments();
    if (r.errors?.length) toast(r.errors.join(" "));
    else toast(r.posted?.length ? `Kommentar gespeichert und in Jira ${r.posted.join(", ")} gepostet.` : "Kommentar gespeichert.");
    refreshHistory();
  } catch (x) { toast(x.message); btn.disabled = false; syncJiraLabel(); }
}
function refreshHistory() {
  if (S.view === "detail" && S.detail) loadIssueHistory(S.detail.identifier);
  else if (S.view === "project" && S.project) api("/api/projects/" + encodeURIComponent(S.project.id)).then((p) => { S.project = p; const h = document.querySelector(".hist:not(#hist)"); if (h) h.innerHTML = renderHistory(p.history || [], "Projekt"); }).catch(() => {});
  else if (S.view === "milestone" && S.ms) api("/api/milestones/" + encodeURIComponent(S.ms.id)).then((m) => { S.ms = m; const h = $("#ms-hist"); if (h) h.innerHTML = renderHistory(m.history || [], "Meilenstein"); }).catch(() => {});
}
document.addEventListener("change", (e) => { if (e.target.closest?.("[data-cm-jira]")) syncJiraLabel(); });
document.addEventListener("click", async (e) => {
  if (e.target.closest("[data-cm-send]")) { e.preventDefault(); return sendComment(); }
  const sb = e.target.closest("[data-cm-sum]");
  if (sb) {
    sb.disabled = true; sb.innerHTML = `${I.spark}Fasse zusammen …`;
    try { const r = await api("/api/comments/summarize", { method: "POST", body: { target: CMT.data.target } }); CMT.data.summary = r.summary; drawComments(); }
    catch (x) { toast(x.message); drawComments(); }
    return;
  }
  if (e.target.closest("[data-cm-sum-x]")) { CMT.data.summary = null; drawComments(); return; }
  const tc = e.target.closest("[data-cm-tocheck]");
  if (tc && S.detail) {
    const txt = CMT.data.summary.offen[Number(tc.dataset.cmTocheck)];
    tc.disabled = true;
    try { await patch({ addItem: txt }, true); toast("Als Checklisten-Punkt übernommen."); } catch (x) { toast(x.message); tc.disabled = false; }
    return;
  }
  const hf = e.target.closest("[data-hist-f]");
  if (hf) {
    const sec = hf.closest(".hist"), f = hf.dataset.histF;
    sec.querySelectorAll("[data-hist-f]").forEach((b) => b.classList.toggle("on", b === hf));
    sec.querySelector(".hist-list")?.classList.toggle("clipped", f === "all" && sec.querySelectorAll(".hist-item").length > 14);
    sec.querySelectorAll(".hist-item").forEach((li) => { li.hidden = f === "cmt" ? !li.classList.contains("is-cmt") : f === "chg" ? li.classList.contains("is-cmt") : false; });
    sec.querySelectorAll(".hist-day").forEach((g) => { g.hidden = ![...g.querySelectorAll(".hist-item")].some((li) => !li.hidden); });
    if (f !== "all") sec.querySelector(".hist-list")?.classList.remove("clipped");
    const all = sec.querySelector(".hist-all"); if (all) all.hidden = f !== "all";
    return;
  }
  const it = e.target.closest(".cm-item");
  if (!it || !CMT.data) return;
  const id = it.dataset.cmId, c = CMT.data.comments.find((x) => x.id === id);
  if (!id || !c) return;
  if (e.target.closest("[data-cm-edit]")) {
    it.querySelector(".cm-body").innerHTML = `<textarea class="cm-input cm-edit" rows="3">${esc(c.body)}</textarea><div class="cm-row"><button class="linkbtn" data-cm-cancel>Abbrechen</button><button class="btn small primary" data-cm-save>Speichern</button></div>`;
    const ta = it.querySelector(".cm-edit"); ta.focus(); ta.style.height = Math.min(320, ta.scrollHeight + 2) + "px";
    ta.addEventListener("keydown", (ev) => { if (ev.key === "Enter" && (ev.metaKey || ev.ctrlKey)) { ev.preventDefault(); ev.stopPropagation(); it.querySelector("[data-cm-save]").click(); } if (ev.key === "Escape") { ev.stopPropagation(); refreshHistory(); } });
    return;
  }
  if (e.target.closest("[data-cm-cancel]")) return refreshHistory();
  const sv = e.target.closest("[data-cm-save]");
  if (sv) { sv.disabled = true; try { const r = await api("/api/comments/edit", { method: "POST", body: { target: CMT.data.target, id, body: it.querySelector(".cm-edit").value } }); CMT.data = r.thread; drawComments(); refreshHistory(); } catch (x) { toast(x.message); sv.disabled = false; } return; }
  const del = e.target.closest("[data-cm-del]");
  if (del) {
    if (!del.dataset.sure) { del.dataset.sure = "1"; del.textContent = "Wirklich löschen?"; setTimeout(() => { if (del.isConnected) { delete del.dataset.sure; del.textContent = "Löschen"; } }, 4000); return; }
    try {
      const target = CMT.data.target;
      const r = await api("/api/comments/delete", { method: "POST", body: { target, id } });
      CMT.data = r.thread; drawComments(); refreshHistory();
      toast("Kommentar gelöscht.", { undo: () => api("/api/comments/restore", { method: "POST", body: { target, comment: r.deleted } }), undoLabel: "Kommentar löschen" });
    } catch (x) { toast(x.message); }
  }
});
