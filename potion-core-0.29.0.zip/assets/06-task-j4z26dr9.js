// PO-TION Oberfläche · 06-task.js
// Klassische Skripte im gemeinsamen globalen Bereich, Reihenfolge laut ui/js (Dateiname). Start in 99-boot.js.
"use strict";
// ---------- Detail ----------
async function openDetail(id) {
  S.view = "detail";
  app.innerHTML = topbar() + `<main class="detail"><p class="muted">Lade ${esc(id)}…</p></main>`;
  try {
    S.detail = await api("/api/issues/" + encodeURIComponent(id));
    S.loadedAt = Date.now();
  } catch (e) {
    app.innerHTML = topbar() + `<main class="detail"><div class="hint">${esc(e.message)}</div></main>`;
    return;
  }
  renderDetail();
}

const STATE_OPTS = [["inbox", "Eingang"], ["later", "Später"], ["planned", "Geplant"], ["doing", "In Arbeit"], ["vendor", "Beim Dienstleister"], ["waiting", "Wartet auf"], ["review", "Abnahme"], ["done", "Erledigt"], ["canceled", "Verworfen"]];
const EST_OPTS = [0, 15, 30, 45, 60, 90, 120, 180, 240, 360, 480];
const estLabel = (m) => (!m ? "–" : m < 60 ? `${m} min` : `${String(m / 60).replace(".", ",")} h`);

function stateKey(d) {
  return d.kind || "planned";
}

function jiraBadges(list) {
  return (list || []).map((j) => `<span class="jira-badge ${j.category === "done" ? "ok" : ""}" title="Jira">${esc(j.key)}${j.status ? " · " + esc(j.status) : ""}</span>`).join("");
}
const KIND_TAG = { doing: "In Arbeit", vendor: "Beim Dienstleister", review: "Abnahme", inbox: "Eingang", later: "Später" };

function fmtWhen(iso) {
  if (!iso) return "";
  const d = new Date(iso), now = new Date();
  const days = Math.floor((now - d) / 86400000);
  const hm = d.toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" });
  if (days < 1 && d.getDate() === now.getDate()) return "heute " + hm;
  if (days < 2) return "gestern " + hm;
  return d.toLocaleDateString("de-DE", { day: "2-digit", month: "2-digit" });
}

function renderFileTiles(files, folder, emptyText) {
  const ext = (n) => (n.split(".").pop() || "").toUpperCase().slice(0, 4);
  const badge = (n) => { const e = ext(n); return e === "PDF" ? "b-pdf" : ["XLSX", "XLS", "CSV"].includes(e) ? "b-xls" : "b-oth"; };
  const kb = (s) => (!s ? "" : s > 1e6 ? (s / 1e6).toFixed(1).replace(".", ",") + " MB" : Math.max(1, Math.round(s / 1e3)) + " KB");
  if (!files.length) return `<div class="file-drop">${I.clip}<span>${esc(emptyText)}</span></div>`;
  return `<section class="files-top">
    <div class="sec-head" style="padding:0"><h2>Dateien</h2>${folder ? `<span class="mono" style="font-size:11.5px">${esc(folder)}</span>` : ""}</div>
    <div class="file-grid">${files.map((f) => `<div class="file-tile" title="${esc(f.name)}">
      ${IMG_RE.test(f.name) ? `<img class="ft-thumb" src="/f/${encodeURIComponent(f.identifier)}/${encodeURIComponent(f.name)}" alt="" loading="lazy">` : `<span class="badge ${badge(f.name)}">${esc(ext(f.name))}</span>`}
      <span class="ft-main"><b>${esc(f.name)}</b><span>${esc([String(f.identifier || "").startsWith("p:") ? "Projekt" : f.identifier, kb(f.size), f.exists === false ? "fehlt am Ablageort" : ""].filter(Boolean).join(" · "))}</span></span>
      <span class="ft-act">${READABLE_RE.test(f.name) ? `<button class="icon-btn" data-say="Fasse die Datei „${esc(f.name)}“ zusammen und schreib es in die Notizen" aria-label="Zusammenfassen" title="Zusammenfassen">${I.spark}</button>` : ""}<button class="icon-btn" data-pfile="${esc(f.identifier)}|${esc(f.name)}" aria-label="Öffnen">${I.out}</button><button class="icon-btn" data-preveal="${esc(f.identifier)}|${esc(f.name)}" aria-label="Im Finder zeigen">${I.folder}</button></span>
    </div>`).join("")}</div>
  </section>`;
}

function renderJiraSection(d) {
  if (!d.jiraConfigured) return "";
  const cards = (d.jira || []).map((j) => j.missing
    ? `<div class="jira-card"><b>${esc(j.key)}</b><span class="muted">nicht gefunden oder kein Zugriff</span></div>`
    : `<div class="jira-card">
        <div class="split"><a href="${esc(j.url)}" target="_blank" rel="noopener" class="jira-key">${esc(j.key)} ${I.out}</a><span class="jira-badge ${j.category === "done" ? "ok" : ""}">${esc(j.status)}</span></div>
        <span class="jira-sum">${esc(j.summary)}</span>
        <span class="muted" style="font-size:12px">${j.assignee ? esc(j.assignee) + " · " : "niemand zugewiesen · "}geändert ${esc(fmtWhen(j.updated))}</span>
        ${d.jiraWrite ? `<div class="jw-row" data-jw="${esc(j.key)}"><button class="btn small" data-jw-status="${esc(j.key)}">${I.swap}Status ändern</button><button class="btn small" data-jw-assign="${esc(j.key)}">${I.person}Bearbeiter</button></div>` : ""}
        ${j.suggestion ? `<div class="jira-sync"><span class="muted">${esc(j.suggestion.reason)}. Aufgabe anpassen?</span><button class="btn small" data-jira-apply="${esc(j.suggestion.kind)}">Auf „${esc(j.suggestion.label)}“ setzen</button></div>` : ""}
        ${j.commentCount ? `<span class="muted" style="font-size:12px">${j.commentCount} ${j.commentCount === 1 ? "Kommentar" : "Kommentare"} im Verlauf</span>` : ""}
      </div>`).join("");
  return `<div style="display:flex;flex-direction:column;gap:10px">
    <div class="sec-head"><h2>Jira</h2>${d.jiraError ? `<span class="hot">${esc(d.jiraError)}</span>` : ""}</div>
    ${cards}
    <div class="add-item" style="border:1px dashed var(--line-3);border-radius:12px"><label for="jira-key" class="sr">Jira-Ticket verknüpfen</label><input id="jira-key" placeholder="Jira-Ticket verknüpfen, z. B. SF-444"></div>
  </div>`;
}

function renderDetail() {
  const d = S.detail;
  setViewTheme("task");
  const left = `<button class="back" data-act="back">${I.back}Zurück</button><span class="kind-badge task">${I.task}Aufgabe</span>${d.projectId ? `<a class="crumb" href="#/p/${esc(d.projectId)}">${I.proj}${esc(d.project)}</a>` : `<span class="muted crumb">Ohne Projekt</span>`}<span class="idf">${esc(d.identifier)}</span>`;
  const right = d.url ? `<a href="${esc(d.url)}" target="_blank" rel="noopener" style="display:inline-flex;align-items:center;gap:6px;font-size:13px;text-decoration:none">In Linear öffnen ${I.out}</a>` : `<span class="local-tag" title="Liegt nur auf diesem Mac">${I.lock}lokal</span>`;
  const done = d.items.filter((x) => x.done).length;
  const next = d.items.find((x) => !x.done);
  const ext = (n) => (n.split(".").pop() || "").toUpperCase().slice(0, 4);
  const badge = (n) => { const e = ext(n); return e === "PDF" ? "b-pdf" : ["XLSX", "XLS", "CSV"].includes(e) ? "b-xls" : "b-oth"; };
  const kb = (s) => (s > 1e6 ? (s / 1e6).toFixed(1).replace(".", ",") + " MB" : Math.max(1, Math.round(s / 1e3)) + " KB");
  app.innerHTML = `<header class="top"><div class="brand" style="gap:14px"><a class="brand-link mini" href="#/" aria-label="PO-TION Startseite">${FLASK(34)}</a>${left}</div>${hdrSearch()}<div class="top-right"><span id="model-pill">${modelPill()}</span>${right}${jiraBtn()}</div></header>
  <main class="detail">
    <div class="d-main">
      <div class="task-head" data-kind="${esc(d.kind || "open")}">
        <span class="th-ring" aria-hidden="true"></span>
        <label for="d-title" class="sr">Titel</label>
        <textarea id="d-title" class="d-title" rows="1">${esc(d.title)}</textarea>
        <div class="tags">
          ${d.dueLabel ? `<span class="due ${d.urgency}">${esc(d.dueLabel)}</span>` : ""}
          <span class="tag">${esc(d.state)}</span>
          ${d.estimateLabel ? `<span class="tag">${esc(d.estimateLabel)}</span>` : ""}
          ${d.priority ? `<span class="tag">${esc(d.priorityLabel)}</span>` : ""}
          <button class="tag tag-more" data-more="task" aria-label="Umwandeln oder löschen" title="Umwandeln oder löschen">${I.more}</button>
        </div>
      </div>
      ${renderFileTiles(d.files.map((f) => ({ ...f, identifier: d.identifier })), d.folder, "Dateien hierher ziehen, sie landen bei " + d.identifier)}
      ${next ? `<div class="hint">${I.spark}<span>Nächster Schritt: <b style="font-weight:500">${esc(next.text)}</b></span></div>` : ""}
      <section style="display:flex;flex-direction:column;gap:12px">
        <div class="sec-head" style="padding:0"><h2>Checkliste</h2>${d.items.length ? `<span class="prog"><span class="bar" style="width:90px;height:5px"><span style="width:${Math.round((done / d.items.length) * 100)}%"></span></span>${done} von ${d.items.length}</span>` : ""}</div>
        <div class="panel">
          ${d.items.map((it, i) => `<label class="check"><input type="checkbox" data-toggle="${i}" ${it.done ? "checked" : ""}><span class="box">${it.done ? I.check("#0E0A14", 12) : ""}</span><span class="txt">${esc(it.text)}</span><button class="rm mk" data-ck2task="${i}" aria-label="Als eigene Aufgabe" title="Als eigene Aufgabe">${I.swap}</button><button class="rm" data-rm="${i}" aria-label="Punkt entfernen">${I.x}</button></label>`).join("")}
          <div class="add-item">${I.plus}<label for="add-item" class="sr">Punkt hinzufügen</label><input id="add-item" placeholder="Punkt hinzufügen und Enter"></div>
        </div>
      </section>
      <section style="display:flex;flex-direction:column;gap:12px">
        <div class="job-slot" id="job-slot"></div>
        <div class="sec-head" style="padding:0"><h2>Notizen</h2><span id="notes-state"></span></div>
        <div id="notes-host" class="notes-editor"></div>
      </section>
      <section class="cmts" id="cmts" data-target="i:${esc(d.identifier)}"></section>
      <section class="hist" id="hist"><div class="sec-head" style="padding:0"><h2>Verlauf</h2><span>wird geladen …</span></div></section>
    </div>
    <aside class="d-side">
      <div class="panel props">
        <div class="prop"><label for="p-state">Status</label><select id="p-state">${STATE_OPTS.map(([k, l]) => `<option value="${k}" ${stateKey(d) === k ? "selected" : ""}>${l}</option>`).join("")}</select></div>
        <div class="prop"><label for="p-prio">Priorität</label><select id="p-prio">${[[1, "Dringend"], [2, "Hoch"], [3, "Mittel"], [0, "Ohne"]].map(([k, l]) => `<option value="${k}" ${d.priority === k ? "selected" : ""}>${l}</option>`).join("")}</select></div>
        <div class="prop"><label for="p-due">Fällig</label><span class="dt-pair"><input id="p-due" type="date" value="${esc(d.due || "")}"><input id="p-time" type="time" step="300" value="${esc(d.dueTime || "")}" aria-label="Uhrzeit der Fälligkeit (optional)" title="Uhrzeit (optional)"${d.due ? "" : ' placeholder="--:--"'}></span></div>
        <div class="prop"><label for="p-est">Schätzung</label><select id="p-est">${EST_OPTS.map((m) => `<option value="${m}" ${(d.estimateMin || 0) === m ? "selected" : ""}>${estLabel(m)}</option>`).join("")}</select></div>
        <div class="prop"><label for="p-proj">Projekt</label><select id="p-proj"><option value="">Ohne</option>${d.projects.map((p) => `<option ${d.project === p ? "selected" : ""}>${esc(p)}</option>`).join("")}</select></div>
        ${d.project && d.milestones.length ? `<div class="prop"><label for="p-ms">Meilenstein</label><select id="p-ms"><option value="">Ohne</option>${d.milestones.map((x) => `<option ${d.milestone === x ? "selected" : ""}>${esc(x)}</option>`).join("")}</select></div>` : ""}
      </div>
      <div style="display:flex;flex-direction:column;gap:10px">
        ${renderJiraSection(d)}

      </div>
    </aside>
  </main>`;

  const title = $("#d-title");
  const fit = () => { title.style.height = "auto"; title.style.height = title.scrollHeight + "px"; };
  fit();
  title.addEventListener("input", fit);
  title.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); title.blur(); } });
  title.addEventListener("change", () => patch({ title: title.value }));
  $("#add-item").addEventListener("keydown", (e) => {
    if (e.key === "Enter" && e.target.value.trim()) patch({ addItem: e.target.value.trim() }, true);
  });
  mountNotes(d);
  renderDock();
  loadIssueHistory(d.identifier);
  loadComments("i:" + d.identifier);
  watchJobs();
  $("#p-state").addEventListener("change", (e) => patch({ state: e.target.value }, true));
  $("#p-prio").addEventListener("change", (e) => patch({ priority: Number(e.target.value) }, true));
  $("#p-due").addEventListener("change", (e) => patch(e.target.value ? { due: e.target.value, dueTime: $("#p-time").value || null } : { due: null }, true));
  $("#p-time").addEventListener("change", (e) => {
    // Uhrzeit ohne Datum: heute, oder morgen, wenn die Uhrzeit heute schon vorbei ist
    let due = $("#p-due").value;
    if (!due && e.target.value) {
      const [h, m] = e.target.value.split(":").map(Number), at = new Date();
      at.setHours(h, m, 0, 0);
      if (at < new Date()) at.setDate(at.getDate() + 1);
      due = `${at.getFullYear()}-${String(at.getMonth() + 1).padStart(2, "0")}-${String(at.getDate()).padStart(2, "0")}`;
    }
    patch(due ? { due, dueTime: e.target.value || null } : { dueTime: null }, true);
  });
  $("#p-est").addEventListener("change", (e) => patch({ estimateMin: Number(e.target.value) }, true));
  $("#p-proj").addEventListener("change", (e) => patch({ project: e.target.value || null }, true));
  $("#p-ms")?.addEventListener("change", (e) => patch({ milestone: e.target.value || null }, true));
  $("#jira-key")?.addEventListener("keydown", async (e) => {
    if (e.key !== "Enter" || !e.target.value.trim()) return;
    e.target.disabled = true;
    try {
      const r = await api("/api/jira/link", { method: "POST", body: { identifier: S.detail.identifier, key: e.target.value.trim() } });
      toast(r.message);
      S.detail = r.detail;
      renderDetail();
    } catch (x) {
      toast(x.message);
      e.target.disabled = false;
    }
  });
}
