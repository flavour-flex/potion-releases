// PO-TION Oberfläche · 11-calendar.js
// Klassische Skripte im gemeinsamen globalen Bereich, Reihenfolge laut ui/js (Dateiname). Start in 99-boot.js.
"use strict";
// ================= Kalenderansicht (#/kalender) =================
const CALV = { view: "week", anchor: null, data: null, layers: null };
const CAL_LAYERS = [["ics", "Outlook/ICS"], ["apple", "Apple Kalender"], ["tasks", "Fälligkeiten"], ["ms", "Meilensteine & Projekte"], ["plan", "Vorschläge"]];
const pad2 = (n) => String(n).padStart(2, "0");
const ymdL = (d) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
const addD = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const monday = (d) => { const x = new Date(d.getFullYear(), d.getMonth(), d.getDate()); return addD(x, -((x.getDay() + 6) % 7)); };
const hmL = (ms) => { const d = new Date(ms); return `${pad2(d.getHours())}:${pad2(d.getMinutes())}`; };
const WDS = ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"];
const MONTHS = ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"];
function calLayers() {
  if (CALV.layers) return CALV.layers;
  let l = {};
  try { l = JSON.parse(localStorage.getItem("potion-cal-layers") || "{}"); } catch {}
  CALV.layers = Object.fromEntries(CAL_LAYERS.map(([k]) => [k, l[k] !== false]));
  try { const v = localStorage.getItem("potion-cal-view"); if (v === "month" || v === "week") CALV.view = v; } catch {}
  return CALV.layers;
}
function calRange() {
  const a = CALV.anchor || new Date();
  if (CALV.view === "month") { const first = new Date(a.getFullYear(), a.getMonth(), 1); const start = monday(first); return { start, end: addD(start, 42), first }; }
  const start = monday(a);
  return { start, end: addD(start, 7) };
}
async function renderCalendar() {
  S.view = "calendar";
  setViewTheme("home");
  renderDock();
  calLayers();
  if (!CALV.anchor) CALV.anchor = new Date();
  const { start, end, first } = calRange();
  const label = CALV.view === "month"
    ? `${MONTHS[first.getMonth()]} ${first.getFullYear()}`
    : `${start.getDate()}.${start.getMonth() !== addD(end, -1).getMonth() ? " " + MONTHS[start.getMonth()].slice(0, 3) + "." : ""} – ${addD(end, -1).getDate()}. ${MONTHS[addD(end, -1).getMonth()]} ${addD(end, -1).getFullYear()}`;
  const kw = isoWeek(start);
  if (!$(".calv")) app.innerHTML = topbar() + `<main class="calv"><div class="calv-load muted">Lade Kalender …</div></main>`;
  let d;
  try { d = await api(`/api/calendar?from=${ymdL(start)}&to=${ymdL(end)}`); } catch (e) { $(".calv").innerHTML = `<div class="hint">${esc(e.message)}</div>`; return; }
  if (S.view !== "calendar") return;
  CALV.data = d;
  const L2 = CALV.layers;
  const noSrc = !d.sources.ics && !d.sources.apple;
  $(".calv").outerHTML = `<main class="calv">
    <header class="calv-head">
      <div class="calv-title"><h1>${esc(label)}</h1>${CALV.view === "week" ? `<span class="calv-kw">KW ${kw}</span>` : ""}</div>
      <div class="calv-nav">
        <button class="icon-btn sm" data-cal="prev" aria-label="Zurück">‹</button>
        <button class="btn small" data-cal="today">Heute</button>
        <button class="icon-btn sm" data-cal="next" aria-label="Weiter">›</button>
        <div class="seg calv-seg" role="tablist"><button class="seg-b${CALV.view === "week" ? " on" : ""}" data-cal="week">Woche</button><button class="seg-b${CALV.view === "month" ? " on" : ""}" data-cal="month">Monat</button></div>
      </div>
    </header>
    <div class="calv-legend">${CAL_LAYERS.filter(([k]) => (k === "ics" ? d.sources.ics : k === "apple" ? d.sources.apple : true)).map(([k, t]) => `<button class="calv-chip l-${k}${L2[k] ? " on" : ""}" data-cal-layer="${k}"><i></i>${t}</button>`).join("")}
      ${noSrc ? `<a class="calv-connect" href="#/einstellungen/verbindungen">${I.cal}Kalender verbinden</a>` : ""}
      ${d.sources.icsError || d.sources.appleError ? `<span class="calv-err">${esc(d.sources.icsError || d.sources.appleError)}</span>` : ""}</div>
    ${CALV.view === "month" ? calMonth(d, start, first) : calWeek(d, start)}
  </main>`;
  if (CALV.view === "week") {
    const body = $(".wk-body");
    const h = CALV.hours;
    // auf "jetzt" bzw. den Arbeitsbeginn scrollen
    const now = new Date();
    const target = now >= start && now < end ? (now.getHours() - h.from - 1.5) : (d.work.start - h.from - 0.5);
    if (body) body.scrollTop = Math.max(0, target * CALV.hourPx);
    clearInterval(CALV.tick);
    CALV.tick = setInterval(() => { if (S.view !== "calendar") return clearInterval(CALV.tick); placeNow(); }, 60000);
    placeNow();
  }
}
function isoWeek(d) {
  const t = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  const day = t.getUTCDay() || 7;
  t.setUTCDate(t.getUTCDate() + 4 - day);
  const y0 = new Date(Date.UTC(t.getUTCFullYear(), 0, 1));
  return Math.ceil(((t - y0) / 86400000 + 1) / 7);
}
/** Alles, was an einem Tag angezeigt wird */
function calItems(d, day) {
  const L2 = CALV.layers;
  const ds = ymdL(day), s0 = day.getTime(), s1 = addD(day, 1).getTime();
  const evs = d.events.filter((e) => L2[e.source] && e.start < s1 && e.end > s0);
  const meta = (e) => ({ name: evName(e), linked: !!e.link, sugg: !e.link && !!e.suggestion, proj: e.link?.milestone || e.link?.project || e.link?.identifier || null, notes: e.hasNotes, generic: e.generic });
  const timed = evs.filter((e) => !e.allDay).map((e) => ({ kind: "ev", src: e.source, free: e.free, title: e.title, cal: e.calendar, start: Math.max(e.start, s0), end: Math.min(e.end, s1), s: e.start, e: e.end, id: e.id, ...meta(e) }));
  const allday = evs.filter((e) => e.allDay).map((e) => ({ kind: "ev", src: e.source, free: e.free, title: e.title, cal: e.calendar, s: e.start, e: e.end, id: e.id, allDay: true, ...meta(e) }));
  const tasks = L2.tasks ? d.tasks.filter((t) => t.date === ds) : [];
  const tTimed = tasks.filter((t) => t.time), tDay = tasks.filter((t) => !t.time);
  const ms = L2.ms ? d.milestones.filter((m) => m.date === ds) : [];
  const pr = L2.ms ? d.projects.filter((p) => p.date === ds) : [];
  const plan = L2.plan && ds === ymdL(new Date()) ? d.plan : [];
  return { timed, allday, tTimed, tDay, ms, pr, plan };
}
function taskChip(t, compact) {
  return `<button class="cal-it it-task${t.overdue ? " late" : ""}${t.priority === 1 ? " hot" : ""}" data-open="${esc(t.identifier)}" title="${esc(t.identifier + " " + t.title + (t.time ? " · fällig " + t.time : ""))}">${I.task}<span>${t.time && compact ? `<b>${esc(t.time)}</b> ` : ""}${esc(t.identifier)} ${esc(t.title)}</span></button>`;
}
const msChip = (m) => `<button class="cal-it it-ms" data-cal-ms="${esc(m.projectId)}|${esc(m.id)}" title="${esc("Meilenstein: " + m.name + " · " + m.project)}">${I.flag}<span>${esc(m.name)}<small> · ${esc(m.project)}</small></span></button>`;
const prChip = (p) => `<a class="cal-it it-pr" href="#/p/${esc(p.id)}" title="${esc("Projekt-Zieltermin: " + p.name)}">${I.proj}<span>Ziel: ${esc(p.name)}</span></a>`;
const evChip = (e, compact) => `<button class="cal-it it-ev s-${e.src}${e.free ? " free" : ""}${e.linked ? " linked" : ""}${e.sugg ? " sugg" : ""}${e.generic && !e.linked && !e.sugg ? " generic" : ""}" data-cal-ev="${esc(e.id)}" title="Doppelklick: benennen, verknüpfen, Notizen">${compact && e.s ? `<b>${esc(e.allDay ? "" : hmL(e.s))}</b> ` : ""}<span>${esc(e.name || e.title || "Belegt")}${e.notes ? " ✎" : ""}</span></button>`;

function calWeek(d, start) {
  const days = [...Array(7)].map((_, i) => addD(start, i));
  const per = days.map((day) => calItems(d, day));
  // Stundenbereich: Arbeitszeit, erweitert um frühe/späte Einträge
  let hFrom = Math.max(0, d.work.start - 1), hTo = Math.min(24, d.work.end + 1);
  for (const p of per) {
    for (const e of [...p.timed, ...p.plan]) { const a = new Date(e.start), b = new Date(e.end); hFrom = Math.min(hFrom, a.getHours()); hTo = Math.max(hTo, b.getHours() + (b.getMinutes() ? 1 : 0)); }
    for (const t of p.tTimed) { const h = +t.time.slice(0, 2); hFrom = Math.min(hFrom, h); hTo = Math.max(hTo, h + 1); }
  }
  hTo = Math.max(hTo, hFrom + 6);
  const PX = 52;
  CALV.hours = { from: hFrom, to: hTo }; CALV.hourPx = PX; CALV.weekStart = start.getTime();
  const todayS = ymdL(new Date());
  const head = days.map((day) => `<div class="wk-dh${ymdL(day) === todayS ? " today" : ""}${d.work.days.includes(day.getDay()) ? "" : " off"}"><span>${WDS[day.getDay()]}</span><b>${day.getDate()}</b></div>`).join("");
  const allday = per.map((p, i) => `<div class="wk-ad${ymdL(days[i]) === todayS ? " today" : ""}">${p.pr.map(prChip).join("")}${p.ms.map(msChip).join("")}${p.tDay.map((t) => taskChip(t)).join("")}${p.allday.map((e) => evChip(e)).join("")}</div>`).join("");
  const y = (ms, day) => ((ms - day.getTime()) / 3600000 - hFrom) * PX;
  const cols = per.map((p, i) => {
    const day = days[i];
    const blocks = [...p.timed.map((e) => ({ ...e, t: "ev" })), ...p.plan.map((x) => ({ ...x, t: "plan" }))].sort((a, b) => a.start - b.start || b.end - a.end);
    layoutCols(blocks);
    const work = d.work.days.includes(day.getDay()) ? `<div class="wk-work" style="top:${(d.work.start - hFrom) * PX}px;height:${(d.work.end - d.work.start) * PX}px"></div>` : "";
    const evHtml = blocks.map((b) => {
      const top = Math.max(0, y(b.start, day)), h = Math.max(18, y(b.end, day) - top);
      const style = `top:${top}px;height:${h}px;left:calc(${(b.col / b.cols) * 100}% + 2px);width:calc(${100 / b.cols}% - 4px)`;
      if (b.t === "plan") return `<button class="wk-ev wk-plan" style="${style}" data-open="${esc(b.identifier)}" title="Vorschlag aus „Plan meinen Tag“"><b>${esc(b.title)}</b><span>${hmL(b.start)}–${hmL(b.end)} · Vorschlag${b.deadline ? " · Frist " + esc(b.deadline) : ""}</span></button>`;
      return `<button class="wk-ev s-${b.src}${b.free ? " free" : ""}${h < 34 ? " tight" : ""}${b.linked ? " linked" : ""}${b.sugg ? " sugg" : ""}${b.generic && !b.linked && !b.sugg ? " generic" : ""}" style="${style}" data-cal-ev="${esc(b.id)}" title="Doppelklick: benennen, verknüpfen, Notizen"><b>${esc(b.name || b.title || "Belegt")}${b.notes ? ' <i class="wk-n">✎</i>' : ""}</b><span>${hmL(b.s)}–${hmL(b.e)}${b.proj ? " · " + esc(b.proj) : b.sugg ? " · Vorschlag" : ""}</span></button>`;
    }).join("");
    const dl = p.tTimed.map((t) => { const [hh, mm] = t.time.split(":").map(Number); const top = (hh + mm / 60 - hFrom) * PX; return `<button class="wk-dl${t.overdue ? " late" : ""}" style="top:${top}px" data-open="${esc(t.identifier)}" title="${esc("Frist " + t.time + ": " + t.identifier + " " + t.title)}"><i></i><span>${esc(t.time)} ${esc(t.identifier)} ${esc(t.title)}</span></button>`; }).join("");
    return `<div class="wk-col${ymdL(day) === todayS ? " today" : ""}" data-day="${day.getTime()}">${work}${evHtml}${dl}</div>`;
  }).join("");
  const hours = [...Array(hTo - hFrom)].map((_, k) => `<div class="wk-h" style="top:${k * PX}px"><span>${pad2(hFrom + k)}:00</span></div>`).join("");
  return `<div class="wk" style="--hpx:${PX}px">
    <div class="wk-top"><div class="wk-g"></div>${head}</div>
    <div class="wk-adrow"><div class="wk-g wk-gl">Ganztägig</div>${allday}</div>
    <div class="wk-body"><div class="wk-grid" style="height:${(hTo - hFrom) * PX}px"><div class="wk-g wk-hours">${hours}</div><div class="wk-cols">${[...Array(hTo - hFrom)].map((_, k) => `<div class="wk-line" style="top:${k * PX}px"></div>`).join("")}${cols}<div class="wk-now" hidden><i></i></div></div></div></div>
  </div>`;
}
/** Überlappende Blöcke nebeneinander legen */
function layoutCols(blocks) {
  let group = [], groupEnd = -1;
  const flush = () => { const n = Math.max(1, ...group.map((b) => b.col + 1)); group.forEach((b) => (b.cols = n)); group = []; };
  for (const b of blocks) {
    if (b.start >= groupEnd && group.length) flush();
    const used = new Set(group.filter((g) => g.end > b.start).map((g) => g.col));
    let c = 0; while (used.has(c)) c++;
    b.col = c; group.push(b); groupEnd = Math.max(groupEnd, b.end);
  }
  if (group.length) flush();
}
function placeNow() {
  const el = $(".wk-now");
  if (!el || !CALV.hours) return;
  const now = Date.now(), ws = CALV.weekStart;
  const di = Math.floor((now - ws) / 86400000);
  if (di < 0 || di > 6) { el.hidden = true; return; }
  const day = new Date(ws); day.setDate(day.getDate() + di);
  const top = ((now - day.getTime()) / 3600000 - CALV.hours.from) * CALV.hourPx;
  el.hidden = top < 0 || top > (CALV.hours.to - CALV.hours.from) * CALV.hourPx;
  el.style.top = top + "px";
  el.style.left = `calc(${(di / 7) * 100}%)`;
  el.style.width = `calc(${100 / 7}%)`;
}
function calMonth(d, start, first) {
  const todayS = ymdL(new Date());
  const cells = [...Array(42)].map((_, i) => {
    const day = addD(start, i);
    const p = calItems(d, day);
    const items = [...p.pr.map(prChip), ...p.ms.map(msChip), ...p.tDay.map((t) => taskChip(t, true)), ...p.tTimed.sort((a, b) => a.time.localeCompare(b.time)).map((t) => taskChip(t, true)), ...p.allday.map((e) => evChip(e, true)), ...p.timed.map((e) => evChip(e, true))];
    const show = items.slice(0, 4), more = items.length - show.length;
    return `<div class="mo-cell${day.getMonth() !== first.getMonth() ? " out" : ""}${ymdL(day) === todayS ? " today" : ""}${d.work.days.includes(day.getDay()) ? "" : " off"}">
      <button class="mo-d" data-cal-day="${day.getTime()}" title="Woche öffnen">${day.getDate()}</button>
      <div class="mo-items">${show.join("")}${more > 0 ? `<button class="mo-more" data-cal-day="${day.getTime()}">+${more} weitere</button>` : ""}</div></div>`;
  }).join("");
  return `<div class="mo"><div class="mo-head">${["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"].map((x) => `<span>${x}</span>`).join("")}</div><div class="mo-grid">${cells}</div></div>`;
}
function calPop(e, el) {
  document.querySelector(".calv-pop")?.remove();
  const r = el.getBoundingClientRect();
  const when = e.allDay ? new Date(e.start).toLocaleDateString("de-DE", { weekday: "long", day: "numeric", month: "long" }) + " · ganztägig" : `${new Date(e.start).toLocaleDateString("de-DE", { weekday: "short", day: "numeric", month: "short" })} · ${hmL(e.start)}–${hmL(e.end)}`;
  document.body.insertAdjacentHTML("beforeend", `<div class="calv-pop s-${e.source}" role="dialog"><b>${esc(e.link?.title || (!e.generic ? e.title : "") || e.title || "Belegt")}</b><span>${esc(when)}</span><span class="muted">${esc(e.calendar)}${e.free ? " · als frei markiert" : ""}</span>
    ${e.link ? `<span class="calv-pop-link">${esc(evName(e))}${e.link.project ? " · " + esc(e.link.project) : ""}${e.link.identifier ? " · " + esc(e.link.identifier) : ""}</span>` : e.suggestion ? `<span class="calv-pop-link sugg">Vorschlag: ${esc(e.suggestion.title || "")}${e.suggestion.project ? " · " + esc(e.suggestion.project) : ""}</span>` : ""}
    <div class="calv-pop-act"><button class="btn small primary" data-cal-meet="${esc(e.id)}">${e.link ? "Öffnen: Notizen & Vorbereitung" : e.generic ? "Benennen & verknüpfen" : "Verknüpfen & Notizen"}</button><button class="btn small" data-cal-new="${esc(e.id)}">+ Aufgabe dazu</button></div></div>`);
  const pop = $(".calv-pop");
  const x = Math.min(window.innerWidth - pop.offsetWidth - 12, Math.max(12, r.left));
  const y2 = r.bottom + 8 + pop.offsetHeight > window.innerHeight ? r.top - pop.offsetHeight - 8 : r.bottom + 8;
  pop.style.left = x + "px"; pop.style.top = Math.max(12, y2) + "px";
}
document.addEventListener("click", async (e) => {
  if (!e.target.closest(".calv-pop") && !e.target.closest("[data-cal-ev]")) document.querySelector(".calv-pop")?.remove();
  const b = e.target.closest("[data-cal]");
  if (b && S.view === "calendar") {
    const k = b.dataset.cal, a = CALV.anchor || new Date();
    if (k === "today") CALV.anchor = new Date();
    else if (k === "prev" || k === "next") { const s2 = k === "next" ? 1 : -1; CALV.anchor = CALV.view === "month" ? new Date(a.getFullYear(), a.getMonth() + s2, 1) : addD(a, 7 * s2); }
    else if (k === "week" || k === "month") { CALV.view = k; try { localStorage.setItem("potion-cal-view", k); } catch {} }
    return renderCalendar();
  }
  const ly = e.target.closest("[data-cal-layer]");
  if (ly) { const k = ly.dataset.calLayer; CALV.layers[k] = !CALV.layers[k]; try { localStorage.setItem("potion-cal-layers", JSON.stringify(CALV.layers)); } catch {} return renderCalendar(); }
  const dd = e.target.closest("[data-cal-day]");
  if (dd) { CALV.anchor = new Date(Number(dd.dataset.calDay)); CALV.view = "week"; return renderCalendar(); }
  const ev = e.target.closest("[data-cal-ev]");
  if (ev && CALV.data) { const x = CALV.data.events.find((z) => z.id === ev.dataset.calEv); if (x) calPop(x, ev); return; }
  const msb = e.target.closest("[data-cal-ms]");
  if (msb) { const [, mid] = msb.dataset.calMs.split("|"); location.hash = "#/m/" + encodeURIComponent(mid); return; }
  const nw = e.target.closest("[data-cal-new]");
  if (nw) {
    const ev = CALV.data?.events.find((z) => z.id === nw.dataset.calNew);
    if (!ev) return;
    const box = nw.closest(".calv-pop, .mt-sec");
    box.querySelector(".qt-form")?.remove();
    box.insertAdjacentHTML("beforeend", quickTaskForm(ev));
    box.querySelector(".qt-form input[name=title]")?.select();
    // kleines Fenster nach oben schieben, wenn es unten aus dem Bild ragt
    if (box.classList.contains("calv-pop")) { const r = box.getBoundingClientRect(); if (r.bottom > window.innerHeight - 12) box.style.top = Math.max(12, window.innerHeight - r.height - 12) + "px"; }
    return;
  }
  const qs = e.target.closest("[data-qt-save]");
  if (qs) {
    const f = qs.closest(".qt-form");
    const v = (n) => f.querySelector(`[name=${n}]`)?.value || "";
    if (!v("title").trim()) return;
    qs.disabled = true;
    try {
      const r = await api("/api/draft/commit", { method: "POST", body: { scoped: true, items: [{ type: "task", title: v("title").trim(), notes: f.dataset.note || "", due: v("due") || null, dueTime: v("due") ? v("time") || null : null, priority: 3, estimateMin: null, checklist: [], project: v("project") || null, milestone: null, decision: false, status: "planned", goal: "", milestones: [] }] } });
      f.innerHTML = `<span class="qt-msg">✓ ${esc(r.reply)}</span>`;
      S.home = null;
      if (S.view === "calendar" && !$(".mt-sheet")) setTimeout(() => renderCalendar(), 900);
    } catch (x) { qs.disabled = false; f.querySelector(".qt-err")?.remove(); f.insertAdjacentHTML("beforeend", `<span class="qt-msg err qt-err">${esc(x.message)}</span>`); }
    return;
  }
});
document.addEventListener("keydown", (e) => {
  const ae = document.activeElement;
  if (S.view !== "calendar" || ["INPUT", "TEXTAREA", "SELECT"].includes(ae?.tagName) || ae?.isContentEditable || ae?.closest?.(".cx-sheet, .calv-pop") || e.metaKey || e.ctrlKey || e.altKey) return;
  const map = { ArrowLeft: "prev", ArrowRight: "next", t: "today", w: "week", m: "month" };
  const k = map[e.key];
  if (k) { e.preventDefault(); document.querySelector(`[data-cal="${k}"]`)?.click(); }
  if (e.key === "Escape") document.querySelector(".calv-pop")?.remove();
});

// ---------- Termin-Fenster: benennen, verknüpfen, Notizen, Zusammenfassung ----------
const evRef = (e) => ({ source: e.source, uid: e.uid, start: e.start, end: e.end, title: e.title, calendar: e.calendar, rec: !!e.rec });
const evName = (e) => e.link?.title || (!e.generic ? e.title : "") || (e.suggestion?.title ? e.suggestion.title + "?" : "") || e.title || "Belegt";
async function openMeeting(id) {
  const e = CALV.data?.events.find((x) => x.id === id);
  if (!e) return;
  document.querySelector(".calv-pop")?.remove();
  closeConnector(true);
  const others = (CALV.data.events || []).filter((x) => x.id !== id).map(evRef);
  document.body.insertAdjacentHTML("beforeend", `<div class="cx-sheet mt-sheet" role="dialog" aria-modal="true"><div class="cx-panel"><div class="cx-body"><p class="muted">Lade …</p></div></div></div>`);
  const sh = $(".mt-sheet");
  sh.dataset.ev = id;
  requestAnimationFrame(() => sh.classList.add("in"));
  sh.addEventListener("click", (x) => { if (x.target === sh) closeMeeting(); });
  let d;
  try { d = await api("/api/meeting", { method: "POST", body: { event: evRef(e), others } }); } catch (x) { sh.querySelector(".cx-body").innerHTML = `<p class="err">${esc(x.message)}</p>`; return; }
  MEET.ed = null; MEET.notes = undefined; MEET.saved = d.notes; MEET.ask = null;
  MEET.e = e; MEET.d = d; MEET.others = others; MEET.pick = d.link ? (d.link.identifier ? { identifier: d.link.identifier, label: d.link.identifier + (d.task ? " " + d.task.title : "") } : d.link.milestoneId ? { milestoneId: d.link.milestoneId, label: `${d.link.milestone || "Meilenstein"} · ${d.link.project || ""}` } : d.link.projectId ? { projectId: d.link.projectId, label: d.link.project } : null) : null;
  drawMeeting();
}
const MEET = { e: null, d: null, pick: null, others: [], ask: null };
async function closeMeeting() {
  const sh = $(".mt-sheet"); if (!sh) return;
  await meetAutoSaveTitle().catch(() => {});
  await MEET.flush?.().catch?.(() => {});
  try { MEET.ed?.handle?.destroy(); } catch {}
  MEET.ed = null; MEET.flush = null;
  sh.classList.remove("in"); setTimeout(() => sh.remove(), 220);
  if (S.view === "calendar") renderCalendar();
}
function drawMeeting() {
  const sh = $(".mt-sheet"); if (!sh) return;
  const { e, d } = MEET;
  // Getippten Namen beim Neuzeichnen behalten
  const typed = $("#mt-title");
  const titleNow = typed ? typed.value : null;
  const when = e.allDay ? new Date(e.start).toLocaleDateString("de-DE", { weekday: "long", day: "numeric", month: "long" }) : `${new Date(e.start).toLocaleDateString("de-DE", { weekday: "long", day: "numeric", month: "long" })} · ${hmL(e.start)}–${hmL(e.end)}`;
  const scopeTxt = d.link ? { single: "nur dieser Termin", series: "alle Termine dieser Serie", pattern: "immer " + d.recurring.patternText }[d.link.scope] : "";
  const sug = d.suggestion;
  const ask = MEET.ask;
  const sum = d.summary;
  sh.querySelector(".cx-panel").innerHTML = `
    <header class="cx-head mt-head"><span class="cx-mono big mt-ico s-${e.source}">${I.cal}</span><div><input class="mt-title" id="mt-title" placeholder="${esc(e.generic ? "Wie heißt der Termin?" : e.title)}" value="${esc(titleNow ?? d.link?.title ?? "")}" aria-label="Name des Termins"><span class="muted">${esc(when)} · ${esc(e.calendar)}${e.generic && e.title ? ` · im Kalender „${esc(e.title)}“` : ""}</span></div><button class="dock-close" data-act="mt-close" aria-label="Schließen">${I.x}</button></header>
    <div class="cx-body">
      ${sug ? `<div class="mt-ask"><b>Vorschlag: „${esc(sug.title || "ohne Name")}“${sug.project ? ` · ${esc(sug.project)}` : ""}${sug.identifier ? ` · ${esc(sug.identifier)}` : ""}</b><span>${esc(sug.reason)}. Stimmt das?</span>
        <div class="mt-ask-b"><button class="btn small primary" data-mt="sug-yes">Ja, für diesen Termin</button>${d.recurring.series ? `<button class="btn small" data-mt="sug-series">Ja, für die ganze Serie</button>` : d.recurring.pattern ? `<button class="btn small" data-mt="sug-pattern">Ja, immer ${esc(d.recurring.patternText)}</button>` : ""}<button class="btn small ghost" data-mt="sug-no">Nein</button></div></div>` : ""}
      ${ask ? `<div class="mt-ask"><b>${esc(ask.text)}</b><span>Ich übernehme das nur, wenn du es bestätigst.</span><div class="mt-ask-b"><button class="btn small primary" data-mt="ask-yes">Ja, für alle</button><button class="btn small ghost" data-mt="ask-no">Nur dieser Termin</button></div></div>` : ""}
      <section class="mt-sec"><h3>Zuordnung</h3>
        <div class="mt-pick">${MEET.pick ? `<span class="mt-chip">${MEET.pick.identifier ? I.task : MEET.pick.milestoneId ? I.flag : I.proj}<span>${esc(MEET.pick.label || "")}</span><button data-mt="unpick" aria-label="Entfernen">${I.x}</button></span>` : `<label class="cap-q mt-q">${I.search}<input id="mt-q" placeholder="Projekt oder Aufgabe suchen …" autocomplete="off"></label><div class="mt-res" id="mt-res"></div>`}</div>
        <div class="mt-row"><button class="btn small primary" data-mt="save">Speichern</button>${d.link ? `<span class="muted">Gilt für ${esc(scopeTxt)}</span><button class="linkbtn" data-mt="unlink">Zuordnung entfernen</button>` : `<span class="muted">Name und Zuordnung gelten nur in PO-TION.</span>`}</div>
      </section>
      ${d.task || d.prep.length || d.previous || d.milestone || d.followups?.length ? `<section class="mt-sec"><h3>Vorbereitung</h3>
        ${d.milestone ? `<button class="mt-ms" data-cal-ms="${esc(d.milestone.projectId)}|${esc(d.milestone.id)}">${I.flag}<span><b>${esc(d.milestone.name)}</b><small>${d.milestone.date ? (d.milestone.days === 0 ? "heute" : d.milestone.days < 0 ? `seit ${-d.milestone.days} ${-d.milestone.days === 1 ? "Tag" : "Tagen"} überfällig` : `in ${d.milestone.days} ${d.milestone.days === 1 ? "Tag" : "Tagen"}`) + " · " + esc(d.milestone.date.split("-").reverse().join(".")) : "ohne Datum"} · ${d.milestone.open} offen, ${d.milestone.done} erledigt</small></span><i>Zeitstrahl →</i></button>` : ""}
        ${d.followups?.length ? `<div class="mt-follow"><b>Offen aus dem letzten Termin${d.followupsFrom ? ` · ${esc(new Date(d.followupsFrom).toLocaleDateString("de-DE", { day: "2-digit", month: "2-digit" }))}` : ""}<span class="muted"> ${d.followups.filter((x) => x.done).length} von ${d.followups.length} erledigt</span></b>${d.followups.map((x) => `<button class="mt-fu${x.done ? " done" : ""}" data-open="${esc(x.identifier || x.parent || "")}"><span class="mt-fu-i">${x.done ? I.check("currentColor", 11) : ""}</span><span>${esc(x.text)}</span><small>${x.kind === "task" ? esc(x.identifier) : "Checkliste " + esc(x.parent)}</small></button>`).join("")}</div>` : ""}
        ${d.task ? `<button class="mt-task" data-open="${esc(d.task.identifier)}"><span class="idf">${esc(d.task.identifier)}</span><b>${esc(d.task.title)}</b>${d.task.dueLabel ? `<span class="muted">· ${esc(d.task.dueLabel)}</span>` : ""}</button>${d.task.open.length ? `<ul class="mt-list">${d.task.open.map((x) => `<li>${esc(x)}</li>`).join("")}</ul>` : ""}` : ""}
        ${d.prep.length ? `<div class="mt-prep">${d.prep.map((t) => `<button class="mt-task" data-open="${esc(t.identifier)}"><span class="idf">${esc(t.identifier)}</span><b>${esc(t.title)}</b>${t.why ? `<span class="mt-why${/hängt|überfällig/.test(t.why) ? " hot" : ""}">${esc(t.why)}</span>` : ""}</button>`).join("")}</div>` : ""}
        ${d.previous ? `<details class="mt-prev"><summary>Notizen vom letzten Termin · ${esc(new Date(d.previous.start).toLocaleDateString("de-DE", { day: "2-digit", month: "2-digit" }))}</summary><div>${esc(d.previous.text).replace(/\n/g, "<br>")}</div></details>` : ""}
      </section>` : ""}
      <section class="mt-sec"><h3>Aufgabe zu diesem Termin</h3><div class="mt-row"><button class="btn small" data-cal-new="${esc(e.id)}">+ Aufgabe dazu</button><span class="muted">z. B. Vorbereitung bis Terminbeginn</span></div></section>
      <section class="mt-sec"><h3>Notizen <span class="muted" id="mt-state"></span></h3>
        <div class="mt-editor" id="mt-notes-host"></div>
        <div class="mt-row"><button class="btn" data-mt="sum" ${(MEET.notes ?? d.notes).trim().length < 20 ? "disabled" : ""}>${I.spark}${sum ? "Neu zusammenfassen" : "Zusammenfassen & Aufgaben ableiten"}</button>${!d.modelReady ? `<span class="muted">Modell startet noch</span>` : ""}</div>
      </section>
      <div id="mt-sum">${sum ? meetSummaryHtml(sum) : ""}</div>
    </div>`;
  const q = $("#mt-q");
  if (q) {
    if (!S.searchIndex) api("/api/search-index").then((r) => { S.searchIndex = { at: Date.now(), items: r.items }; }).catch(() => {});
    q.addEventListener("input", () => {
      const words = q.value.toLowerCase().trim().split(/\s+/).filter(Boolean);
      const box = $("#mt-res");
      if (!words.length || !S.searchIndex) { box.innerHTML = ""; return; }
      const hits = S.searchIndex.items.filter((it) => !it.done && (it.t === "task" || it.t === "project" || it.t === "milestone")).map((it) => ({ it, sc: scoreItem(it, words) })).filter((x) => x.sc > 0).sort((a, b) => b.sc - a.sc).slice(0, 7);
      const raw = q.value.trim();
      box.innerHTML = hits.map(({ it }) => `<button class="mt-hit" data-mt-pick="${esc(it.t)}|${esc(it.t === "milestone" ? it.ms : it.id)}|${esc(it.t === "task" ? it.id + " " + it.title : it.t === "milestone" ? it.title + " · " + (it.sub || "").split(" · ")[0] : it.title)}">${it.t === "task" ? I.task : it.t === "milestone" ? I.flag : I.proj}<span>${it.t === "task" ? `<span class="idf">${esc(it.id)}</span> ` : ""}${esc(it.title)}${it.t === "milestone" ? `<small> · Meilenstein · ${esc(it.sub || "")}</small>` : ""}</span></button>`).join("")
        + `<div class="mt-new"><button class="mt-hit new" data-mt-create="task">${I.plus}<span>Neue Aufgabe „${esc(raw)}“ anlegen</span></button><button class="mt-hit new" data-mt-create="project">${I.plus}<span>Neues Projekt „${esc(raw)}“ anlegen</span></button></div>`;
    });
  }
  mountMeetNotes();
  // Name speichert sich selbst: beim Verlassen des Feldes oder mit Enter
  const ti = $("#mt-title");
  ti.addEventListener("keydown", (x) => { if (x.key === "Enter") { x.preventDefault(); ti.blur(); } });
  ti.addEventListener("change", () => meetAutoSaveTitle());
}
function mountMeetNotes() {
  const host = $("#mt-notes-host");
  if (!host) return;
  if (MEET.ed?.el) { host.replaceWith(MEET.ed.el); return; }
  MEET.notes = MEET.d.notes || "";
  const ed = { el: host, handle: null };
  MEET.ed = ed;
  let t;
  const onChange = (md) => {
    MEET.notes = md;
    clearTimeout(t); const st = $("#mt-state"); if (st) st.textContent = "…";
    const btn = $(".mt-sheet [data-mt=sum]"); if (btn) btn.disabled = md.trim().length < 20;
    t = setTimeout(() => saveMeetNotes(), 700);
  };
  MEET.flush = () => { clearTimeout(t); return saveMeetNotes(); };
  if (window.crxsEditor) window.crxsEditor.mount(host, MEET.notes, onChange).then((h) => (ed.handle = h)).catch(() => mountPlainNotes(host, MEET.notes, onChange));
  else mountPlainNotes(host, MEET.notes, onChange);
}
async function saveMeetNotes() {
  if (!MEET.e || MEET.notes === undefined || MEET.notes === MEET.saved) return;
  const v = MEET.notes;
  await api("/api/meeting/notes", { method: "POST", body: { event: evRef(MEET.e), text: v } }).catch(() => {});
  MEET.saved = v; if (MEET.d) MEET.d.notes = v;
  const st = $("#mt-state"); if (st) st.textContent = "gespeichert";
}
async function meetAutoSaveTitle() {
  const ti = $("#mt-title");
  if (!ti || !MEET.d) return;
  const v = ti.value.trim();
  if (v === (MEET.d.link?.title || "")) return;
  if (!v && !MEET.pick && !MEET.d.link) return;
  try {
    await meetSave(MEET.d.link && MEET.d.link.scope !== "single" ? MEET.d.link.scope : "single");
    if (!MEET.d.link || MEET.d.link.scope === "single") meetAskRecurring();
    toast("Name gespeichert");
    drawMeeting();
  } catch (x) { toast(x.message); }
}
function meetAskRecurring() {
  const r = MEET.d.recurring;
  MEET.ask = MEET.d.link?.scope !== "single" ? null
    : r.series ? { scope: "series", text: `Das ist ein wiederkehrender Termin${r.seriesCount ? ` (${r.seriesCount} weitere gefunden)` : ""}. Für alle Termine dieser Serie übernehmen?` }
    : r.pattern ? { scope: "pattern", text: `${r.pattern} ${r.pattern === 1 ? "weiterer Termin" : "weitere Termine"} ${r.patternText} gefunden. Für alle übernehmen?` } : null;
}
function meetSummaryHtml(s) {
  const list = (t, xs) => (xs?.length ? `<div class="mt-sumsec"><b>${t}</b><ul>${xs.map((x) => `<li>${esc(x)}</li>`).join("")}</ul></div>` : "");
  return `<section class="mt-sec mt-sum"><h3>${I.spark}Zusammenfassung <span class="muted">${esc(new Date(s.at).toLocaleString("de-DE", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }))}</span></h3>
    <p>${esc(s.kurz)}</p>${list("Kernpunkte", s.points)}${list("Entscheidungen", s.decisions)}${list("Offene Fragen", s.questions)}
    ${s.todos?.length ? (() => {
      const parent = MEET.d?.link?.identifier;
      const where = parent ? `Standard: Checkliste von ${parent}` : MEET.d?.link?.milestone ? `als Aufgaben im Meilenstein „${MEET.d.link.milestone}“` : MEET.d?.link?.project ? `als Aufgaben im Projekt „${MEET.d.link.project}“` : "als Aufgaben ohne Projekt";
      return `<div class="mt-sumsec"><b>Aufgaben daraus <span class="muted">· ${esc(where)}</span></b><div class="mt-todos">${s.todos.map((x, k) => `<div class="mt-todo"><label class="cx-chk"><input type="checkbox" data-todo="${k}" checked><span class="cx-box-i"></span><span>${esc(x.title)}${x.due ? `<small>fällig ${esc(x.due.split("-").reverse().join("."))}${x.dueTime ? " " + esc(x.dueTime) : ""}</small>` : ""}</span></label>${parent ? `<div class="seg mt-mode" data-mode-for="${k}"><button class="seg-b on" data-mode="check" title="Als Punkt in die Checkliste von ${esc(parent)}">Checkliste</button><button class="seg-b" data-mode="task" title="Als eigene Aufgabe im selben Projekt">Aufgabe</button></div>` : ""}</div>`).join("")}</div>
      <div class="mt-row"><button class="btn small primary" data-mt="todos">Ausgewählte übernehmen</button><span class="muted" id="mt-todo-msg"></span></div></div>`;
    })() : ""}
  </section>`;
}
async function meetSave(scope) {
  const title = $("#mt-title")?.value.trim() || "";
  const body = { event: evRef(MEET.e), scope, title, identifier: MEET.pick?.identifier || null, milestoneId: MEET.pick?.milestoneId || null, projectId: MEET.pick?.identifier || MEET.pick?.milestoneId ? null : MEET.pick?.projectId || null };
  const d = await api("/api/meeting/link", { method: "POST", body });
  MEET.d = { ...d, notes: MEET.notes ?? d.notes };
  const ti = $("#mt-title"); if (ti) ti.value = d.link?.title || title;
  return d;
}
/** Kleines Formular: Aufgabe zu einem Termin, vorausgefüllt mit Name, Termin-Beginn und verknüpftem Projekt */
function quickTaskForm(ev) {
  const name = (MEET.e?.id === ev.id ? ($("#mt-title")?.value.trim() || MEET.d?.link?.title) : null) || evName(ev);
  const named = (MEET.e?.id === ev.id && ($("#mt-title")?.value.trim() || MEET.d?.link?.title)) || ev.link?.title || (!ev.generic ? ev.title : "");
  const nice = named && named !== "Belegt" ? named : "Termin";
  void name;
  const d = new Date(ev.start);
  const proj = (MEET.e?.id === ev.id ? MEET.d?.link?.project : null) || ev.link?.project || "";
  const projects = [...new Set((S.searchIndex?.items || []).filter((x) => x.t === "project").map((x) => x.title).concat(proj ? [proj] : []))];
  return `<div class="qt-form" data-note="${esc(`Zum Termin „${nice}“ am ${d.toLocaleDateString("de-DE")} ${hmL(ev.start)}`)}">
    <input class="in" name="title" value="${esc(nice + " vorbereiten")}" aria-label="Titel der Aufgabe">
    <div class="qt-row"><input class="in" type="date" name="due" value="${esc(ymdL(d))}" aria-label="Fällig am"><input class="in" type="time" name="time" value="${ev.allDay ? "" : esc(hmL(ev.start))}" aria-label="Uhrzeit"></div>
    <select class="in" name="project" aria-label="Projekt"><option value="">Ohne Projekt</option>${projects.map((p2) => `<option ${p2 === proj ? "selected" : ""}>${esc(p2)}</option>`).join("")}</select>
    <div class="mt-row"><button class="btn small primary" data-qt-save>Anlegen</button><span class="muted">Fällig zu Terminbeginn, änderbar</span></div>
  </div>`;
}
document.addEventListener("dblclick", (e) => {
  const ev = e.target.closest("[data-cal-ev]");
  if (ev && S.view === "calendar") { e.preventDefault(); openMeeting(ev.dataset.calEv); }
});
document.addEventListener("click", async (e) => {
  const om = e.target.closest("[data-cal-meet]");
  if (om) return openMeeting(om.dataset.calMeet);
  if (e.target.closest("[data-act=mt-close]")) return closeMeeting();
  const mc = e.target.closest("[data-mt-create]");
  if (mc && MEET.e) {
    const name = $("#mt-q")?.value.trim();
    if (!name) return;
    mc.disabled = true;
    try {
      const kind = mc.dataset.mtCreate;
      const note = `Angelegt aus dem Termin „${$("#mt-title")?.value.trim() || evName(MEET.e)}“ am ${new Date(MEET.e.start).toLocaleDateString("de-DE")}`;
      const item = kind === "task"
        ? { type: "task", title: name, notes: note, due: null, dueTime: null, priority: 3, estimateMin: null, checklist: [], project: null, milestone: null, decision: false, status: "planned", goal: "", milestones: [] }
        : { type: "project", title: name, notes: "", due: null, priority: 3, estimateMin: null, checklist: [], project: null, milestone: null, decision: false, status: "planned", goal: note, milestones: [] };
      const r = await api("/api/draft/commit", { method: "POST", body: { scoped: true, items: [item] } });
      if (kind === "task" && r.cards?.[0]) MEET.pick = { identifier: r.cards[0].identifier, label: r.cards[0].identifier + " " + r.cards[0].title };
      else if (r.projectCard) MEET.pick = { projectId: r.projectCard.id, label: r.projectCard.name };
      S.searchIndex = null; S.home = null;
      api("/api/search-index").then((x) => { S.searchIndex = { at: Date.now(), items: x.items }; }).catch(() => {});
      // gleich verknüpfen, damit nichts verloren geht
      await meetSave(MEET.d.link && MEET.d.link.scope !== "single" ? MEET.d.link.scope : "single");
      if (!MEET.d.link || MEET.d.link.scope === "single") meetAskRecurring();
      toast(r.reply);
      drawMeeting();
    } catch (x) { toast(x.message); mc.disabled = false; }
    return;
  }
  const pk = e.target.closest("[data-mt-pick]");
  if (pk) {
    const [t, id, ...rest] = pk.dataset.mtPick.split("|");
    MEET.pick = t === "task" ? { identifier: id, label: rest.join("|") } : t === "milestone" ? { milestoneId: id, label: rest.join("|") } : { projectId: id, label: rest.join("|") };
    try { await meetSave(MEET.d.link && MEET.d.link.scope !== "single" ? MEET.d.link.scope : "single"); if (!MEET.d.link || MEET.d.link.scope === "single") meetAskRecurring(); } catch (x) { toast(x.message); }
    return drawMeeting();
  }
  const md = e.target.closest("[data-mode]");
  if (md && md.closest(".mt-mode")) { md.closest(".mt-mode").querySelectorAll(".seg-b").forEach((x) => x.classList.toggle("on", x === md)); return; }
  const b = e.target.closest("[data-mt]");
  if (!b || !MEET.e) return;
  const k = b.dataset.mt;
  try {
    if (k === "unpick") { MEET.pick = null; return drawMeeting(); }
    if (k === "save") {
      if (!$("#mt-title").value.trim() && !MEET.pick) { toast("Gib dem Termin einen Namen oder verknüpf ihn"); return; }
      await meetSave(MEET.d.link && MEET.d.link.scope !== "single" ? MEET.d.link.scope : "single");
      // Wiederkehrend erkannt: immer nachfragen, nie automatisch übernehmen
      meetAskRecurring();
      toast("Gespeichert");
      return drawMeeting();
    }
    if (k === "ask-yes") { const sc = MEET.ask.scope; MEET.ask = null; await meetSave(sc); toast(sc === "series" ? "Gilt jetzt für die ganze Serie" : "Gilt jetzt für alle passenden Termine"); return drawMeeting(); }
    if (k === "ask-no") { MEET.ask = null; return drawMeeting(); }
    if (k === "unlink") { MEET.d = { ...(await api("/api/meeting/unlink", { method: "POST", body: { event: evRef(MEET.e) } })), notes: MEET.notes ?? MEET.d.notes }; MEET.pick = null; const ti = $("#mt-title"); if (ti) ti.value = ""; return drawMeeting(); }
    if (k === "sug-yes" || k === "sug-series" || k === "sug-pattern") {
      const s2 = MEET.d.suggestion;
      MEET.pick = s2.identifier ? { identifier: s2.identifier, label: s2.identifier } : s2.projectId ? { projectId: s2.projectId, label: s2.project } : null;
      const ti = $("#mt-title"); if (ti) ti.value = s2.title || "";
      await meetSave(k === "sug-series" ? "series" : k === "sug-pattern" ? "pattern" : "single");
      return drawMeeting();
    }
    if (k === "sug-no") { await api("/api/meeting/dismiss", { method: "POST", body: { event: evRef(MEET.e), from: MEET.d.suggestion.from } }); MEET.d.suggestion = null; return drawMeeting(); }
    if (k === "sum") {
      b.disabled = true; b.innerHTML = `${I.spark}Fasst zusammen …`;
      await MEET.flush?.();
      const r = await api("/api/meeting/summarize", { method: "POST", body: { event: evRef(MEET.e) } });
      MEET.d.summary = { ...r, at: r.at || new Date().toISOString() };
      return drawMeeting();
    }
    if (k === "todos") {
      const s2 = MEET.d.summary;
      const items = [...document.querySelectorAll("[data-todo]:checked")].map((x) => {
        const i = Number(x.dataset.todo);
        const mode = document.querySelector(`[data-mode-for="${i}"] .seg-b.on`)?.dataset.mode || "task";
        return { ...s2.todos[i], mode };
      });
      if (!items.length) return;
      b.disabled = true;
      const r = await api("/api/meeting/apply", { method: "POST", body: { event: evRef(MEET.e), items } });
      $("#mt-todo-msg").textContent = r.reply;
      S.home = null;
      return;
    }
  } catch (x) { toast(x.message); b.disabled = false; if (b.dataset.mt === "sum") b.innerHTML = `${I.spark}Zusammenfassen & Aufgaben ableiten`; }
});
document.addEventListener("keydown", (e) => { if (e.key === "Escape" && $(".mt-sheet")) { e.stopPropagation(); closeMeeting(); } }, true);
