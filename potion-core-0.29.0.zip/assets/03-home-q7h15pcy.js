// PO-TION Oberfläche · 03-home.js
// Klassische Skripte im gemeinsamen globalen Bereich, Reihenfolge laut ui/js (Dateiname). Start in 99-boot.js.
"use strict";
// ---------- Start ----------
async function renderHome() {
  S.view = "home";
  setViewTheme("home");
  if (!S.home) app.innerHTML = topbar() + `<main class="wrap"><p class="muted">Lade…</p></main>`;
  try {
    S.home = await api("/api/home");
  } catch (e) {
    app.innerHTML = topbar() + `<main class="wrap"><div class="hint">${esc(e.message)}</div><div><button class="btn" data-act="reload">Erneut versuchen</button></div></main>`;
    return;
  }
  const h = S.home;
  const calPill = `<a class="pill pill-link" href="#/kalender" title="Kalender öffnen">${I.cal}${esc(h.calendar.headline || "Kalender")}</a>`;
  const openCount = h.next.length;
  const intro = !S.introDone;
  S.introDone = true;
  if (S.status && !S.status.introSeen && !S.introShown) { S.introShown = true; setTimeout(() => openIntro(), 900); }
  if (intro) { document.body.classList.add("intro-run"); setTimeout(() => document.body.classList.remove("intro-run"), 1400); }
  app.innerHTML = topbar(calPill) + `<main class="home${intro ? " intro" : ""}">
    <section class="home-top">
      <div class="home-hello"><h1 class="hello">${esc(h.greeting)}, ${esc(h.name)}.</h1>
        <span class="muted">${openCount ? `${openCount} als Nächstes` : "nichts offen"}${h.waitingCount ? ` · ${h.waitingCount} ${h.waitingCount === 1 ? "hängt" : "hängen"}` : ""}${h.reviewCount ? ` · ${h.reviewCount} in Abnahme` : ""}</span></div>
      <section id="proj-strip">${renderProjects(h.projects)}</section>
      <section class="grid">
        <div class="col-main">
          <div class="sec-head"><h2>Als Nächstes</h2><span>${h.next.length > 1 ? `${h.next.length} · ` : ""}nach Dringlichkeit</span></div>
          <div class="panel next-panel">${renderNext(h.next)}</div>
        </div>
        <aside class="col-side">
          <div class="sec-head"><h2>Heute</h2><a class="sec-link" href="#/kalender">${esc(h.today.label)} · Kalender öffnen →</a></div>
          <div class="panel day">${renderDay(h)}</div>
        </aside>
      </section>
    </section>
    <div class="home-split" role="separator" aria-orientation="horizontal" aria-label="Höhe von Liste und Chat" title="Ziehen, um Liste und Chat zu verteilen · Doppelklick: zurück auf 3 Aufgaben"><span></span></div>
    <section class="home-chat">
      <div class="thread fade" id="thread">${h.chat.length ? h.chat.map(renderMsg).join("") : `<div class="thread-empty">Schreib unten einfach los: Aufgaben, Fragen, Projekte. Oder zieh eine Datei ins Fenster.</div>`}</div>
    </section>
  </main>`;
  renderDock();
  sizeHomeGrid();
  scrollThread();
  const lastMsg = h.chat[h.chat.length - 1];
  if (!S.dockReply && lastMsg?.draft && !lastMsg.draftDone) openDraftInDock(lastMsg);
}

function renderNext(list) {
  if (!list.length) return `<div class="empty">Nichts offen. Schreib unten einfach los.</div>`;
  return list.map(renderRow).join("");
}

function renderProjects(list) {
  if (!list || !list.length) return "";
  return `<div class="sec-head" style="margin-bottom:10px"><h2>Projekte</h2><span>nach nächstem Meilenstein</span></div>
  <div class="proj-grid">${list.map((p) => `<button class="proj-card" data-project="${esc(p.id)}">
    <span class="pc-head"><b>${esc(p.name)}</b><span class="pc-badge ${p.stuck ? "hot" : ""}">${p.stuck ? `${p.stuck} ${p.stuck === 1 ? "hängt" : "hängen"}` : p.open ? `${p.open} offen` : "ruhig"}</span></span>
    <span class="bar wide"><span style="width:${p.pct}%"></span></span>
    <span class="pc-ms"><span>${esc(p.milestone)}</span><span class="${p.soon ? "hot" : ""}">${esc(p.when)}</span></span>
    <span class="pc-next"><small>Als Nächstes</small><span>${esc(p.next || "nichts offen")}</span></span>
  </button>`).join("")}</div>`;
}

function renderRow(t) {
  const prog = t.check.total ? `<span class="prog"><span class="bar"><span style="width:${Math.round((t.check.done / t.check.total) * 100)}%"></span></span>${t.check.done}/${t.check.total}</span>` : "";
  return `<button class="row" data-open="${esc(t.identifier)}"><span class="sel-box" data-sel="${esc(t.identifier)}" role="checkbox" aria-checked="false" aria-label="${esc(t.identifier)} auswählen" title="Auswählen (⇧ für Bereich)"></span>
    <span class="prio-dot u-${t.urgency}"></span>
    <span class="row-main">
      <span class="tc-title"><span class="idf">${esc(t.identifier)}</span><b>${esc(t.title)}</b></span>
      <span class="row-meta">${t.project ? `<span>${esc(t.project)}</span>` : ""}${t.estimateLabel ? `<span>${esc(t.estimateLabel)}</span>` : ""}${prog}${KIND_TAG[t.kind] ? `<span class="kind-tag k-${t.kind}">${KIND_TAG[t.kind]}</span>` : ""}${jiraBadges(t.jira)}</span>
    </span>
    ${t.dueLabel ? `<span class="due ${t.urgency}">${esc(t.dueLabel)}</span>` : `<span class="due later">${esc(t.priorityLabel)}</span>`}
  </button>`;
}

function renderDay(h) {
  if (!h.calendar.configured) {
    const focus = h.today.slots.filter((s) => s.kind === "focus" || s.kind === "deadline");
    return `<div class="cal-hint">Kein Kalender verbunden. Mit einem ICS-Link aus Outlook plane ich Fokusblöcke in deine freie Zeit. <a href="#/einstellungen/verbindungen" data-cx-open="ics">Kalender verbinden</a></div>` + focus.map(renderSlot).join("");
  }
  if (!h.today.workday) return `<div class="cal-hint">Heute ist kein Arbeitstag, daher keine Planung. Unter „Plan meinen Tag“ siehst du trotzdem das Wichtigste.</div>`;
  if (h.calendar.error) return `<div class="cal-hint">Kalender nicht erreichbar: ${esc(h.calendar.error)}</div>`;
  if (!h.today.slots.length) return `<div class="cal-hint">Für heute ist die Arbeitszeit vorbei.</div>`;
  return h.today.slots.map(renderSlot).join("");
}

function renderSlot(s) {
  const inner = `<b>${esc(s.label)}</b><span>${esc(s.meta)}</span>`;
  const box = (s.kind === "focus" || s.kind === "deadline") && s.identifier
    ? `<button class="slot-box slot-${s.kind}${s.warn ? " slot-warn" : ""}${s.deadline ? " slot-dl" : ""}" data-open="${esc(s.identifier)}">${s.deadline && s.kind === "focus" ? `<i class="slot-flag">${I.flag}${esc(s.deadline)}</i>` : ""}${inner}</button>`
    : `<div class="slot-box slot-${s.kind}">${inner}</div>`;
  return `<div class="slot"><span class="slot-time">${esc(s.time)}</span>${box}</div>`;
}

function renderCard(t) {
  const bits = [t.dueLabel ? `<span class="${t.urgency === "urgent" ? "hot" : ""}">${t.overdue ? "Überfällig " + esc(t.dueLabel.replace(/^Seit/, "seit")) : "Fällig " + esc(t.dueLabel)}</span>` : "", t.estimateLabel ? `<span>${esc(t.estimateLabel)}</span>` : "", t.check?.total ? `<span>Checkliste ${t.check.done}/${t.check.total}</span>` : "", t.priority ? `<span class="${t.priority <= 2 ? "hot" : ""}">${esc(t.priorityLabel)}</span>` : "", t.project ? `<span>${esc(t.project)}</span>` : "", KIND_TAG[t.kind] ? `<span>${KIND_TAG[t.kind]}</span>` : "", jiraBadges(t.jira)].join("");
  return `<button class="task-card" data-open="${esc(t.identifier)}">
    <span class="tc-main"><span class="tc-title"><span class="idf">${esc(t.identifier)}</span><b>${esc(t.title)}</b></span><span class="tc-meta">${bits}</span></span>
    <span class="muted" style="font-size:13px">${t.state === "Done" || t.stateType === "completed" ? "Erledigt" : "Öffnen"}</span>
  </button>`;
}

/** Zeile „Gestützt auf …“ unter KI-Antworten */
function basisLine(b) {
  if (!b || !b.length) return "";
  const noAi = b.some((x) => /ohne KI/.test(x));
  return `<p class="ai-basis${noAi ? " no-ai" : ""}" title="${noAi ? "Diese Antwort kommt aus einer festen Auswertung deiner Daten, nicht vom Sprachmodell." : "Darauf hat sich das lokale Sprachmodell gestützt."}"><span>${noAi ? "Feste Auswertung" : "Gestützt auf"}</span>${b.filter((x) => !/ohne KI/.test(x)).map((x) => `<em>${esc(x)}</em>`).join("")}</p>`;
}
function renderMsg(m, idx, arr) {
  if (m.role === "user") return `<div class="msg-user">${esc(m.text)}</div>`;
  const isLast = arr ? idx === arr.length - 1 : true;
  const undo = m.undo && isLast ? `<div class="msg-actions"><button class="btn small" data-undo='${esc(JSON.stringify(m.undo))}'>Rückgängig</button></div>` : "";
  const pc = m.projectCard
    ? `<button class="task-card" data-project="${esc(m.projectCard.id)}"><span class="tc-main"><span class="tc-title"><b>${esc(m.projectCard.name)}</b></span><span class="tc-meta">${m.projectCard.milestones.map((x) => `<span>${esc(x.name)}${x.date ? " · " + esc(x.date.split("-").reverse().slice(0, 2).join(".")) + "." : ""}</span>`).join("")}${m.projectCard.tasks ? `<span>${m.projectCard.tasks} ${m.projectCard.tasks === 1 ? "Aufgabe" : "Aufgaben"}</span>` : ""}</span></span><span class="muted" style="font-size:13px">Projekt öffnen</span></button>`
    : "";
  const dr = m.draft ? (m.draftDone ? `<p class="muted draft-done">${m.draftDone === "Verworfen" ? "Verworfen." : "✓ Übernommen"}</p>` : `<p class="draft-done" data-draft-mark="${esc(m.draft.id)}"><button class="linkbtn" data-draft-open="${esc(m.draft.id)}">Vorschlag unten bearbeiten</button></p>`) : "";
  const lk = m.links?.length || m.searchMore?.length ? renderLinks(m.links || [], m.searchMore || []) : "";
  const acts = m.actions?.length && isLast ? `<div class="msg-actions">${m.actions.map((a) => `<button class="chip chip-ai" data-say="${esc(a.say)}">${I.spark}${esc(a.label)}</button>`).join("")}</div>` : "";
  return `<div class="msg-ai"><div class="ai-mark">${I.spark}</div><div class="ai-body"><p>${esc(m.text)}</p>${basisLine(m.basis)}${lk}${dr}${acts}${pc}${(m.cards || []).map(renderCard).join("")}${m.extra || ""}${undo}</div></div>`;
}

// ---------- Vorschlags-Maske (KI fragt nach, du bestätigst) ----------
S.drafts = {};
const TYPE_LABEL = { task: "Aufgabe", milestone: "Meilenstein", project: "Projekt" };
const isoToDe = (d) => (d ? d.split("-").reverse().join(".") : "");
function msOptions(draft, projectName, selected) {
  const p = draft.projects.find((x) => x.name === projectName);
  const ms = p ? p.milestones : [];
  return `<option value="">Kein Meilenstein</option>` + ms.map((m) => `<option ${m === selected ? "selected" : ""}>${esc(m)}</option>`).join("");
}
function renderDraft(draft) {
  S.drafts[draft.id] = draft;
  const items = draft.items.map((it, i) => {
    const recommended = it.projectHint?.startsWith("Empfohlen") && it.project ? it.project : null;
    const projOpts = `<option value="">Ohne Projekt</option>` + draft.projects.map((p) => `<option value="${esc(p.name)}" ${p.name === it.project ? "selected" : ""}>${esc(p.name)}${p.name === recommended ? " · empfohlen" : ""}</option>`).join("");
    const seg = ["task", "milestone", "project"].map((t) => `<button type="button" class="seg-b${it.type === t ? " on" : ""}" data-dtype="${t}">${TYPE_LABEL[t]}</button>`).join("");
    return `<div class="di" data-i="${i}" data-type="${esc(it.type)}">
      <div class="di-head"><div class="seg">${seg}</div>${draft.items.length > 1 ? `<button type="button" class="di-x" data-act="draft-drop" aria-label="Diesen Vorschlag entfernen">${I.x}</button>` : ""}</div>
      ${it.kindHint ? `<p class="di-hint">${esc(it.kindHint)}</p>` : ""}
      <label class="df wide"><span>Titel</span><input name="title" value="${esc(it.title)}" autocomplete="off"></label>
      <div class="df-row">
        <label class="df f-task f-milestone"><span>Projekt</span><select name="project">${projOpts}</select>${it.projectHint ? `<small class="df-hint">${esc(it.projectHint)}</small>` : !it.project && draft.projects.length ? `<small class="df-hint">Gehört es zu einem Projekt?</small>` : ""}</label>
        <label class="df f-task"><span>Meilenstein</span><select name="milestone">${msOptions(draft, it.project, it.milestone)}</select></label>
        <label class="df"><span class="f-task">Fällig</span><span class="f-milestone">Datum</span><span class="f-project">Zieldatum</span><span class="dt-pair"><input type="date" name="due" value="${esc(it.due || "")}"><input type="time" name="dueTime" class="f-task" value="${esc(it.dueTime || "")}" step="300" aria-label="Uhrzeit (optional)" title="Uhrzeit (optional)"></span></label>
      </div>
      <div class="df-row f-task">
        <label class="df"><span>Priorität</span><select name="priority">${[[1, "Dringend"], [2, "Hoch"], [3, "Normal"]].map(([v, l]) => `<option value="${v}" ${it.priority === v ? "selected" : ""}>${l}</option>`).join("")}</select></label>
        <label class="df"><span>Status</span><select name="status">${[["planned", "Geplant"], ["inbox", "Eingang"], ["later", "Später"]].map(([v, l]) => `<option value="${v}" ${it.status === v ? "selected" : ""}>${l}</option>`).join("")}</select></label>
        <label class="df small"><span>Aufwand (Min.)</span><input type="number" min="0" step="15" name="estimateMin" value="${it.estimateMin ?? ""}"></label>
      </div>
      <label class="df wide f-task"><span>Checkliste <em>eine Zeile pro Punkt</em></span><textarea name="checklist" rows="${Math.max(2, Math.min(6, it.checklist.length + 1))}">${esc(it.checklist.join("\n"))}</textarea></label>
      <label class="df wide f-project"><span>Ziel</span><textarea name="goal" rows="2">${esc(it.goal)}</textarea></label>
      <label class="df wide f-project"><span>Meilensteine <em>eine Zeile je Meilenstein, optional mit Datum: „Abnahme 27.10.“</em></span><textarea name="milestones" rows="3">${esc(it.milestones.map((m) => m.name + (m.date ? " " + isoToDe(m.date) : "")).join("\n"))}</textarea></label>
    </div>`;
  }).join("");
  return `<form class="draft" data-draft="${esc(draft.id)}">${items}
    <div class="draft-actions"><button class="btn primary small" type="submit">${draft.items.length > 1 ? "Alle anlegen" : "Anlegen"}</button><button class="btn small ghost" type="button" data-act="draft-discard">Verwerfen</button><span class="muted" style="font-size:12px">Enter = anlegen</span></div>
  </form>`;
}
function parseMsLine(line) {
  const m = line.match(/^(.*?)[\s,–-]*(\d{1,2})\.(\d{1,2})\.?(\d{2,4})?\s*$/);
  if (!m) return { name: line.trim(), date: null };
  const now = new Date();
  let y = m[4] ? Number(m[4].length === 2 ? "20" + m[4] : m[4]) : now.getFullYear();
  const mo = Number(m[3]), d = Number(m[2]);
  if (!m[4] && new Date(y, mo - 1, d) < new Date(now.getFullYear(), now.getMonth(), now.getDate())) y++;
  return { name: m[1].trim() || line.trim(), date: `${y}-${String(mo).padStart(2, "0")}-${String(d).padStart(2, "0")}` };
}
function collectDraft(form) {
  const draft = S.drafts[form.dataset.draft];
  return [...form.querySelectorAll(".di")].map((el) => {
    const base = draft.items[Number(el.dataset.i)];
    const v = (n) => el.querySelector(`[name="${n}"]`)?.value ?? "";
    const lines = (n) => v(n).split("\n").map((x) => x.replace(/^[-*•]\s*/, "").trim()).filter(Boolean);
    return {
      ...base,
      type: el.dataset.type,
      title: v("title").trim(),
      project: v("project") || null,
      milestone: v("milestone") || null,
      due: v("due") || null,
      dueTime: (v("due") && el.dataset.type === "task" && v("dueTime")) || null,
      priority: Number(v("priority")) || 3,
      status: v("status") || "planned",
      estimateMin: Number(v("estimateMin")) || null,
      checklist: lines("checklist"),
      goal: v("goal"),
      milestones: lines("milestones").map(parseMsLine),
    };
  });
}
function draftResultHtml(r) {
  return `<p>${esc(r.reply)}</p>${r.projectCard ? renderMsg({ role: "assistant", text: "", projectCard: r.projectCard }).replace(/^.*?<p><\/p>/s, "").replace(/<\/div><\/div>$/, "") : ""}${(r.cards || []).map(renderCard).join("")}${r.undo ? `<div class="msg-actions"><button class="btn small" data-undo='${esc(JSON.stringify(r.undo))}'>Rückgängig</button></div>` : ""}`;
}
function markDraft(id, text) {
  const el = document.querySelector(`[data-draft-mark="${CSS.escape(id)}"]`);
  if (el) { el.classList.add("muted"); el.textContent = text; }
}
function openDraftInDock(msg) {
  dockReply(`<p>${esc(msg.text)}</p>${renderDraft(msg.draft)}`);
  setTimeout(() => $("#dock-reply input[name=title]")?.focus(), 30);
}
async function submitDraft(form) {
  const items = collectDraft(form);
  const bad = items.find((x) => !x.title);
  if (bad) return toast("Titel fehlt");
  const noProj = items.find((x) => x.type === "milestone" && !x.project);
  if (noProj) return toast("Für einen Meilenstein bitte ein Projekt wählen");
  const id = form.dataset.draft;
  const onHome = S.view === "home";
  form.querySelectorAll("button,input,select,textarea").forEach((x) => (x.disabled = true));
  try {
    const r = await api("/api/draft/commit", { method: "POST", body: { draftId: id, items, scoped: !onHome } });
    if (onHome) {
      const m = S.home.chat.find((x) => x.draft?.id === id);
      if (m) m.draftDone = r.reply;
      markDraft(id, "✓ Übernommen");
      S.dockReply = null;
      $("#dock-reply").hidden = true;
      pushMsg({ role: "assistant", text: r.reply, basis: r.basis, cards: r.cards, projectCard: r.projectCard, undo: r.undo });
      if (r.undo) pushUndo(chatUndoLabel(r.reply), Object.assign(serverUndo(r.undo), { key: JSON.stringify(r.undo) }));
      refreshLists();
    } else {
      dockReply(draftResultHtml(r));
      reloadView();
    }
  } catch (e) {
    form.querySelectorAll("button,input,select,textarea").forEach((x) => (x.disabled = false));
    toast(e.message);
  }
}
document.addEventListener("submit", (e) => {
  const f = e.target.closest("form.draft");
  if (f) { e.preventDefault(); submitDraft(f); }
});
document.addEventListener("change", (e) => {
  const sel = e.target.closest("form.draft select[name=project]");
  if (!sel) return;
  const form = sel.closest("form.draft");
  const ms = sel.closest(".di").querySelector("select[name=milestone]");
  if (ms) ms.innerHTML = msOptions(S.drafts[form.dataset.draft], sel.value, null);
});
document.addEventListener("keydown", (e) => {
  if (e.key !== "Enter" || e.shiftKey || e.isComposing) return;
  const f = e.target.closest?.("form.draft");
  if (!f || e.target.tagName === "TEXTAREA" && !(e.metaKey || e.ctrlKey)) return;
  e.preventDefault();
  submitDraft(f);
});
