// PO-TION Oberfläche · 12-transform.js
// Klassische Skripte im gemeinsamen globalen Bereich, Reihenfolge laut ui/js (Dateiname). Start in 99-boot.js.
"use strict";
// ================= Umwandeln & Löschen (⋯-Menü) =================
I.person = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"/></svg>`;
I.more = `<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><circle cx="5" cy="12" r="1.8"/><circle cx="12" cy="12" r="1.8"/><circle cx="19" cy="12" r="1.8"/></svg>`;
I.swap = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 7h11l-3-3M17 17H6l3 3"/></svg>`;
I.trash = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg>`;
function closeMore() { document.querySelector(".ctx-menu")?.remove(); }
function placeMenu(menu, anchor) {
  const r = anchor.getBoundingClientRect();
  const w = menu.offsetWidth, h = menu.offsetHeight;
  menu.style.left = Math.max(12, r.left + w + 12 <= window.innerWidth ? r.left : r.right - w) + "px";
  menu.style.top = (r.bottom + 6 + h > window.innerHeight ? Math.max(12, r.top - h - 6) : r.bottom + 6) + "px";
}
function openMore(kind, anchor, ref) {
  closeMore();
  const it = (act, label, sub, opt = {}) => `<button class="cm-it${opt.danger ? " danger" : ""}" data-cm="${act}" ${opt.disabled ? "disabled" : ""}>${opt.icon || I.swap}<span><b>${label}</b>${sub ? `<small>${sub}</small>` : ""}</span></button>`;
  let html = "";
  if (kind === "task") {
    const d = S.detail;
    html = `<div class="cm-h">Umwandeln</div>
      ${it("to-check", "In Checklisten-Punkt …", "einer anderen Aufgabe, Notizen wandern mit")}
      ${it("to-project", "In Projekt", "Checklisten-Punkte werden Aufgaben")}
      ${it("to-ms", "In Meilenstein", d.projectId ? `in „${esc(d.project)}“, Fälligkeit wird Zieldatum` : "geht nur, wenn die Aufgabe in einem Projekt ist", { disabled: !d.projectId })}
      <div class="cm-sep"></div>${it("del-task", "Löschen", "landet im Archiv, rückgängig möglich", { danger: true, icon: I.trash })}`;
  } else if (kind === "project") {
    html = `<div class="cm-h">Umwandeln</div>
      ${it("p-to-task", "In Aufgabe", "offene Aufgaben werden Checklisten-Punkte")}
      <div class="cm-sep"></div>${it("del-project", "Löschen …", "landet im Archiv, rückgängig möglich", { danger: true, icon: I.trash })}`;
  } else if (kind === "ms") {
    html = `<div class="cm-h">Meilenstein</div>
      ${it("ms-to-task", "In Aufgabe umwandeln", "Zieldatum wird Fälligkeit, Aufgaben bleiben im Projekt")}
      <div class="cm-sep"></div>${it("del-ms", "Löschen", "Aufgaben bleiben im Projekt, rückgängig möglich", { danger: true, icon: I.trash })}`;
  }
  document.body.insertAdjacentHTML("beforeend", `<div class="ctx-menu" role="menu" data-kind="${kind}" data-ref="${esc(ref || "")}">${html}</div>`);
  placeMenu($(".ctx-menu"), anchor);
  MORE.anchor = anchor;
}
const MORE = { anchor: null };
async function runTransform(body, after) {
  closeMore();
  let r;
  try { r = await api("/api/transform", { method: "POST", body }); } catch (x) { toast(x.message); return; }
  S.home = null; S.searchIndex = null;
  toastUndo(r.reply, r.undo, after, after === "stay" && r.open ? { href: "#/t/" + encodeURIComponent(r.open), label: "Öffnen" } : null);
  if (after === "home") location.hash = "#/";
  else if (after === "project" && S.project) openProject(S.project.id);
  else if (after === "stay" && S.detail) openDetail(S.detail.identifier);
  else if (after === "toProject" && S.ms) location.hash = "#/p/" + encodeURIComponent(S.ms.project.id);
  else if (r.open?.startsWith("p:")) location.hash = "#/p/" + encodeURIComponent(r.open.slice(2));
  else if (r.open) location.hash = "#/t/" + encodeURIComponent(r.open);
  else if (S.view === "detail" && S.detail) openDetail(S.detail.identifier);
}
function toastUndo(msg, undo, after, link) { toast(msg, { undo: undo ? serverUndo(undo) : null, link }); }
document.addEventListener("click", async (e) => {
  const mb = e.target.closest("[data-more]");
  if (mb) { e.preventDefault(); e.stopPropagation(); const k = mb.dataset.more; if ($(".ctx-menu") && MORE.anchor === mb) return closeMore(); return openMore(k, mb, k === "ms" ? mb.dataset.msId : k === "project" ? S.project?.id : S.detail?.identifier); }
  const ck = e.target.closest("[data-ck2task]");
  if (ck && S.detail) { e.preventDefault(); e.stopPropagation(); return runTransform({ op: "checklist-to-task", ident: S.detail.identifier, index: Number(ck.dataset.ck2task) }, "stay"); }
  const cm = e.target.closest("[data-cm]");
  if (cm) {
    e.stopPropagation();
    const menu = cm.closest(".ctx-menu"), ref = menu.dataset.ref, a = cm.dataset.cm;
    const confirm2 = (label) => { if (cm.dataset.sure) return true; cm.dataset.sure = "1"; cm.querySelector("b").textContent = label; return false; };
    if (a === "to-project") return runTransform({ op: "task-to-project", ident: ref });
    if (a === "to-ms") return runTransform({ op: "task-to-milestone", ident: ref });
    if (a === "del-task") { if (!confirm2("Wirklich löschen?")) return; return runTransform({ op: "delete-task", ident: ref }, "home"); }
    if (a === "p-to-task") { if (!confirm2("Wirklich umwandeln?")) return; return runTransform({ op: "project-to-task", projectId: ref }); }
    if (a === "ms-to-task") return runTransform({ op: "milestone-to-task", milestoneId: ref });
    if (a === "del-ms") { if (!confirm2("Wirklich löschen?")) return; return runTransform({ op: "delete-milestone", milestoneId: ref }, S.view === "milestone" ? "toProject" : "project"); }
    if (a === "del-project") {
      const n = (S.project?.timeline?.milestones || []).reduce((s2, m) => s2 + m.tasks.filter((t) => t.kind !== "done" && t.kind !== "canceled").length, 0) + (S.project?.timeline?.loose || []).filter((t) => t.kind !== "done" && t.kind !== "canceled").length;
      menu.innerHTML = `<div class="cm-h">Projekt löschen</div>${n ? `<p class="cm-p">Das Projekt hat ${n} offene ${n === 1 ? "Aufgabe" : "Aufgaben"}.</p>` : ""}
        <button class="cm-it danger" data-cm="del-p-all">${I.trash}<span><b>${n ? "Samt offenen Aufgaben löschen" : "Projekt löschen"}</b><small>alles ins Archiv</small></span></button>
        ${n ? `<button class="cm-it" data-cm="del-p-only">${I.trash}<span><b>Nur das Projekt</b><small>Aufgaben bleiben, ohne aktives Projekt</small></span></button>` : ""}
        <button class="cm-it" data-cm="cancel"><span><b>Abbrechen</b></span></button>`;
      placeMenu(menu, MORE.anchor);
      return;
    }
    if (a === "del-p-all") return runTransform({ op: "delete-project", projectId: ref, withTasks: true }, "home");
    if (a === "del-p-only") return runTransform({ op: "delete-project", projectId: ref, withTasks: false }, "home");
    if (a === "cancel") return closeMore();
    if (a === "to-check") {
      if (!S.searchIndex) S.searchIndex = { at: Date.now(), items: (await api("/api/search-index").catch(() => ({ items: [] }))).items };
      menu.innerHTML = `<div class="cm-h">In die Checkliste von …</div><label class="cap-q cm-q">${I.search}<input id="cm-q" placeholder="Aufgabe suchen …" autocomplete="off"></label><div class="cm-res" id="cm-res"></div>`;
      placeMenu(menu, MORE.anchor);
      const q = $("#cm-q"); q.focus();
      const draw = () => {
        const words = q.value.toLowerCase().trim().split(/\s+/).filter(Boolean);
        const pool = S.searchIndex.items.filter((x) => x.t === "task" && !x.done && x.id !== ref);
        const hits = (words.length ? pool.map((x) => ({ x, sc: scoreItem(x, words) })).filter((y) => y.sc > 0).sort((p1, p2) => p2.sc - p1.sc).map((y) => y.x) : pool.filter((x) => S.detail?.project && x.sub?.startsWith(S.detail.project))).slice(0, 7);
        $("#cm-res").innerHTML = hits.map((x) => `<button class="cm-it" data-cm-parent="${esc(x.id)}">${I.task}<span><b><span class="idf">${esc(x.id)}</span> ${esc(x.title)}</b><small>${esc(x.sub || "")}</small></span></button>`).join("") || `<p class="cm-p">Tipp den Namen oder die ID der Aufgabe.</p>`;
      };
      q.addEventListener("input", draw); draw();
      return;
    }
  }
  const cp = e.target.closest("[data-cm-parent]");
  if (cp) return runTransform({ op: "task-to-checklist", ident: cp.closest(".ctx-menu").dataset.ref, parent: cp.dataset.cmParent });
  if (!e.target.closest(".ctx-menu")) closeMore();
}, true);
document.addEventListener("keydown", (e) => { if (e.key === "Escape" && $(".ctx-menu")) { e.stopPropagation(); closeMore(); } }, true);
