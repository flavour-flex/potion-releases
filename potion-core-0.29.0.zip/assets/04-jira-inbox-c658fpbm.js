// PO-TION Oberfläche · 04-jira-inbox.js
// Klassische Skripte im gemeinsamen globalen Bereich, Reihenfolge laut ui/js (Dateiname). Start in 99-boot.js.
"use strict";
// ---------- Jira-Eingang (nur auf Klick) ----------
async function openJiraInbox(force = false) {
  let pop = $("#jira-pop");
  if (!pop) {
    document.body.insertAdjacentHTML("beforeend", `<div id="jira-pop" class="jira-pop" role="dialog" aria-label="Jira-Eingang"></div>`);
    pop = $("#jira-pop");
  }
  pop.hidden = false;
  pop.innerHTML = `<div class="jp-head"><b>Jira · mir zugewiesen</b><span class="muted">noch keiner Aufgabe zugeordnet</span><button class="dock-close" data-act="jira-close" aria-label="Schließen">${I.x}</button></div><div class="jp-body"><div class="thinking"><i></i><i></i><i></i></div></div>`;
  try {
    const r = await api("/api/jira/assigned" + (force ? "?force=1" : ""));
    S.jiraInbox = r;
    if (S.home) S.home.jiraUnlinked = r.items.length;
    updateJiraBtn();
    const body = pop.querySelector(".jp-body");
    if (!r.configured) { body.innerHTML = `<p class="muted">Jira ist noch nicht verbunden. <a href="#/einstellungen/verbindungen" data-cx-open="jira">Jetzt verbinden</a></p>`; return; }
    if (!r.items.length) { body.innerHTML = `<p class="muted">Alles zugeordnet. Kein offenes Ticket ohne Aufgabe.</p><button class="linkbtn" data-act="jira-refresh">Neu laden</button>`; return; }
    const taskOpts = (sel) => `<option value="">Aufgabe wählen…</option>` + r.tasks.map((t) => `<option value="${esc(t.identifier)}" ${t.identifier === sel ? "selected" : ""}>${esc(t.identifier)} · ${esc(t.title.slice(0, 60))}</option>`).join("");
    body.innerHTML = r.items.map((j) => `<div class="jp-item" data-key="${esc(j.key)}">
      <div class="jp-top"><a href="${esc(j.url)}" target="_blank" rel="noopener" class="jira-b">${esc(j.key)}</a><span class="jp-status">${esc(j.status)}</span></div>
      <div class="jp-title">${esc(j.summary)}</div>
      ${j.suggest ? `<div class="jp-sug">Passt vielleicht zu <b>${esc(j.suggest.identifier)}</b> ${esc(j.suggest.title)}</div>` : ""}
      <div class="jp-actions">
        <button class="btn small primary" data-jira-new="${esc(j.key)}">Neue Aufgabe</button>
        <select class="jp-sel" aria-label="Vorhandene Aufgabe">${taskOpts(j.suggest?.identifier)}</select>
        <button class="btn small" data-jira-assign="${esc(j.key)}">Zuordnen</button>
      </div>
    </div>`).join("") + `<button class="linkbtn" data-act="jira-refresh" style="margin-top:6px">Neu laden</button>`;
  } catch (e) {
    pop.querySelector(".jp-body").innerHTML = `<p class="err">${esc(e.message)}</p>`;
  }
}
function updateJiraBtn() {
  document.querySelectorAll(".jira-btn").forEach((b) => (b.outerHTML = jiraBtn()));
}
async function jiraImport(btn, key, identifier) {
  btn.disabled = true;
  try {
    const r = await api("/api/jira/import", { method: "POST", body: { key, identifier: identifier || undefined } });
    const item = btn.closest(".jp-item");
    item.innerHTML = `<div class="jp-done">✓ ${esc(r.message)} <button class="linkbtn" data-open="${esc(r.identifier)}">öffnen</button></div>`;
    if (S.home) S.home.jiraUnlinked = Math.max(0, (S.home.jiraUnlinked || 1) - 1);
    updateJiraBtn();
    if (S.view === "home") refreshLists(); else if (S.view !== "settings") reloadView();
  } catch (e) { btn.disabled = false; toast(e.message); }
}

function scrollThread() {
  const th = $("#thread");
  if (th) th.scrollTop = th.scrollHeight;
}

function pushMsg(m) {
  S.home.chat.push(m);
  const th = $("#thread");
  if (!th) return;
  th.querySelector(".thread-empty")?.remove();
  th.querySelectorAll("[data-undo]").forEach((b) => b.closest(".msg-actions")?.remove());
  th.insertAdjacentHTML("beforeend", renderMsg(m));
  th.lastElementChild?.classList.add("enter");
  scrollThread();
}

function thinking(on) {
  const th = $("#thread");
  if (!th) return;
  $("#think")?.remove();
  if (on) {
    th.insertAdjacentHTML("beforeend", `<div class="msg-ai" id="think"><div class="ai-mark">${I.spark}</div>${workBox()}</div>`);
    scrollThread();
  }
}

// Live-Anzeige, was die KI gerade tut (Schritt, Fortschritt, Zeit, geschriebene Token)
function workBox() {
  return `<div class="work" aria-live="polite"><div class="work-top"><div class="thinking"><i></i><i></i><i></i></div><span class="work-label">Denkt nach</span><span class="work-time"></span></div><div class="work-detail"></div><span class="work-bar" hidden><i></i></span></div>`;
}
function startWorkPoll() {
  stopWorkPoll();
  const tick = async () => {
    let a;
    try { a = await api("/api/progress"); } catch { return; }
    document.querySelectorAll(".work").forEach((w) => {
      if (!a.active) return;
      w.querySelector(".work-label").textContent = a.label || "Denkt nach";
      const det = [a.detail, a.tokens ? `${a.tokens} Token geschrieben` : ""].filter(Boolean).join(" · ");
      w.querySelector(".work-detail").textContent = det;
      w.querySelector(".work-time").textContent = a.elapsed >= 3 ? `${a.elapsed} s` : "";
      const bar = w.querySelector(".work-bar");
      if (a.total > 1) { bar.hidden = false; bar.firstElementChild.style.width = Math.round(((a.step - 0.5) / a.total) * 100) + "%"; }
      else bar.hidden = true;
    });
    S.workT = setTimeout(tick, 600);
  };
  S.workT = setTimeout(tick, 400);
}
function stopWorkPoll() { clearTimeout(S.workT); }

function dockContext() {
  if (S.view === "detail" && S.detail) return { issueId: S.detail.identifier, projectId: S.detail.projectId || null };
  if (S.view === "project" && S.project) return { projectId: S.project.id };
  if (S.view === "milestone" && S.ms) return { projectId: S.ms.project.id, milestoneId: S.ms.id };
  return {};
}

async function send(textArg) {
  const ta = $("#cmd");
  const text = (textArg ?? ta?.value ?? "").trim();
  if (!text) return;
  if (S.busy) { toast("Moment, ich arbeite noch an der letzten Anfrage"); return; }
  S.busy = true;
  const startHash = location.hash;
  if (ta && textArg === undefined) { ta.value = ""; ta.style.height = "auto"; }
  S.draft = "";
  const ctx = dockContext();
  const onHome = S.view === "home";
  if (onHome) { pushMsg({ role: "user", text }); thinking(true); }
  else dockReply(workBox());
  startWorkPoll();
  try {
    const r = await api("/api/chat", { method: "POST", body: { text, ...ctx } });
    if (location.hash !== startHash) {
      // Seite inzwischen gewechselt: Ergebnis kurz melden statt in fremde Ansicht zu schreiben
      toast("Fertig: " + r.reply.split("\n")[0].slice(0, 140));
      if (r.refresh) reloadView();
    } else if (onHome) {
      thinking(false);
      const msg = { role: "assistant", text: r.reply, cards: r.cards, projectCard: r.projectCard, undo: r.undo, draft: r.draft, actions: r.actions, links: r.links, searchMore: r.searchMore, basis: r.basis };
      if (r.undo) pushUndo(chatUndoLabel(r.reply), Object.assign(serverUndo(r.undo), { key: JSON.stringify(r.undo) }));
      pushMsg(msg);
      if (r.draft) openDraftInDock(msg);
      if (r.refresh) refreshLists();
    } else {
      const cards = (r.cards || []).filter((c) => !(S.view === "detail" && S.detail && c.identifier === S.detail.identifier));
      dockReply(`<p>${esc(r.reply)}</p>${basisLine(r.basis)}${r.links?.length || r.searchMore?.length ? renderLinks(r.links || [], r.searchMore || []) : ""}${r.draft ? renderDraft(r.draft) : ""}${r.actions?.length ? `<div class="msg-actions">${r.actions.map((a) => `<button class="chip chip-ai" data-say="${esc(a.say)}">${I.spark}${esc(a.label)}</button>`).join("")}</div>` : ""}${cards.map(renderCard).join("")}${r.undo ? `<div class="msg-actions"><button class="btn small" data-undo='${esc(JSON.stringify(r.undo))}'>Rückgängig</button></div>` : ""}`);
      if (r.refresh) reloadView();
    }
  } catch (e) {
    if (location.hash !== startHash) toast("Fehler: " + e.message);
    else if (onHome) { thinking(false); pushMsg({ role: "assistant", text: "Fehler: " + e.message }); }
    else dockReply(`<p class="err">${esc(e.message)}</p>`);
  } finally {
    S.busy = false;
    stopWorkPoll();
    $("#cmd")?.focus();
  }
}

function reloadView() {
  if (S.view === "detail" && S.detail) openDetail(S.detail.identifier);
  else if (S.view === "project" && S.project) openProject(S.project.id);
  else if (S.view === "milestone" && S.ms) openMilestone(S.ms.id);
  else if (S.view === "home") refreshLists();
}
