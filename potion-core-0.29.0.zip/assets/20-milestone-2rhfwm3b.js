// PO-TION Oberfläche · 20-milestone.js
// Klassische Skripte im gemeinsamen globalen Bereich, Reihenfolge laut ui/js (Dateiname). Start in 99-boot.js.
"use strict";
// ================= Meilenstein-Seite =================
async function openMilestone(id) {
  S.view = "milestone";
  if (!S.ms || S.ms.id !== id) app.innerHTML = topbar() + `<main class="wrap"><p class="muted">Lade Meilenstein…</p></main>`;
  try { S.ms = await api("/api/milestones/" + encodeURIComponent(id)); }
  catch (e) { app.innerHTML = topbar() + `<main class="wrap"><div class="hint">${esc(e.message)}</div></main>`; return; }
  renderMilestone();
}
function renderMilestone() {
  const m = S.ms;
  setViewTheme("project");
  const tagClass = { reached: "ok", soon: "hot", late: "hot", planned: "muted" };
  const idx = m.others.findIndex((x) => x.id === m.id);
  const prev = m.others[idx - 1], next = m.others[idx + 1];
  app.innerHTML = `<header class="top"><div class="brand" style="gap:14px"><a class="brand-link mini" href="#/" aria-label="PO-TION Startseite">${FLASK(34)}</a>
      <button class="back" data-act="back">${I.back}Zurück</button>
      <span class="kind-badge ms-badge">${I.flag}Meilenstein</span><a class="crumb" href="#/p/${esc(m.project.id)}">${I.proj}${esc(m.project.name)}</a></div>
      ${hdrSearch()}<div class="top-right"><span id="model-pill">${modelPill()}</span>${jiraBtn()}</div></header>
  <main class="wrap project ms-page">
    <section class="p-head p-hero">
      <div class="p-title">
        <div class="p-glyph" aria-hidden="true">${I.flag}</div>
        <label for="ms-name" class="sr">Name</label><input id="ms-name" class="ms-name" value="${esc(m.name)}" autocomplete="off">
        <div class="tags p-tags">
          <label class="tag ms-date" title="Zieldatum">${I.cal}<input type="date" id="ms-date" value="${esc(m.targetDate || "")}" aria-label="Zieldatum"></label>
          ${m.tag ? `<span class="tag ${tagClass[m.state] === "hot" ? "due soon" : ""}">${esc(m.tag)}</span>` : ""}
          <span class="tag">${m.done}/${m.total} erledigt</span>
          <button class="tag tag-more" data-more="ms" data-ms-id="${esc(m.id)}" aria-label="Umwandeln oder löschen" title="Umwandeln oder löschen">${I.more}</button>
        </div>
      </div>
      <div class="p-stats">
        <div class="stat"><small>Fortschritt</small><b>${m.done} / ${m.total}</b><span class="bar wide"><span style="width:${m.pct}%"></span></span></div>
        <div class="stat ms-nav"><small>Im Projekt</small><span>${prev ? `<a href="#/m/${esc(prev.id)}" title="Vorheriger Meilenstein">← ${esc(prev.name)}</a>` : `<span class="muted">erster</span>`}</span><span>${next ? `<a href="#/m/${esc(next.id)}" title="Nächster Meilenstein">${esc(next.name)} →</a>` : `<span class="muted">letzter</span>`}</span><button class="linkbtn" data-ms-tl="${esc(m.id)}">${I.flag}Zeitstrahl</button></div>
      </div>
    </section>
    <div class="p-cols">
      <div class="p-main">
        <div class="sec-head"><h2>Offene Aufgaben</h2><span>${m.open.length}</span></div>
        <div class="panel" data-sel-list>${m.open.length ? m.open.map(renderRow).join("") : `<div class="empty">Keine offenen Aufgaben. Schreib unten z. B. „Neue Aufgabe: …“, sie landet in diesem Meilenstein.</div>`}</div>
        ${m.finished.length ? `<details class="ms-done"><summary>${m.finished.length} erledigt</summary><div class="panel">${m.finished.map(renderRow).join("")}</div></details>` : ""}
        <div class="sec-head"><h2>Notizen</h2><span id="msnotes-state"></span></div>
        <div id="msnotes-host" class="notes-editor"></div>
        <section class="cmts" id="cmts" data-target="m:${esc(m.id)}"></section>
        <section class="hist" id="ms-hist">${renderHistory(m.history || [], "Meilenstein")}</section>
      </div>
    </div>
  </main>`;
  renderDock();
  mountMsNotes(m);
  loadComments("m:" + m.id);
  const nm = $("#ms-name");
  const saveName = () => { const v = nm.value.trim(); if (v && v !== S.ms.name) msPatch({ name: v }, { name: S.ms.name }, "Name"); };
  nm.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); nm.blur(); } if (e.key === "Escape") { nm.value = S.ms.name; nm.blur(); } });
  nm.addEventListener("blur", saveName);
  $("#ms-date").addEventListener("change", (e) => msPatch({ targetDate: e.target.value || null }, { targetDate: S.ms.targetDate || null }, "Zieldatum"));
}
async function msPatch(body, prevBody, label) {
  const id = S.ms.id;
  try {
    S.ms = await api("/api/milestones/" + encodeURIComponent(id), { method: "PATCH", body });
    S.project = null; S.home = null; S.searchIndex = null;
    toast(`${label} gespeichert.`, { undo: () => api("/api/milestones/" + encodeURIComponent(id), { method: "PATCH", body: prevBody }), undoLabel: `Meilenstein: ${label}` });
    if (S.view === "milestone" && S.ms.id === id) renderMilestone();
  } catch (x) { toast(x.message); }
}
let msTimer = null;
function mountMsNotes(m) {
  const host = $("#msnotes-host");
  if (S.msEditor && S.msEditor.id === m.id) { host.replaceWith(S.msEditor.el); return; }
  destroyMsNotes();
  const ed = { id: m.id, el: host, handle: null, draft: undefined, saved: m.description };
  S.msEditor = ed;
  const onChange = (md) => { ed.draft = md; const st = $("#msnotes-state"); if (st) st.textContent = "…"; clearTimeout(msTimer); msTimer = setTimeout(flushMsNotes, 1200); };
  if (window.crxsEditor) window.crxsEditor.mount(host, m.description || "", onChange).then((h) => (ed.handle = h)).catch(() => mountPlainNotes(host, m.description, onChange));
  else mountPlainNotes(host, m.description, onChange);
}
async function flushMsNotes() {
  clearTimeout(msTimer);
  const ed = S.msEditor;
  if (!ed || ed.draft === undefined || ed.draft === ed.saved) return;
  const v = ed.draft;
  try { await api("/api/milestones/" + encodeURIComponent(ed.id), { method: "PATCH", body: { description: v } }); ed.saved = v; const st = $("#msnotes-state"); if (st && ed.draft === v) st.textContent = "gespeichert"; }
  catch (e) { toast("Notizen nicht gespeichert: " + e.message); }
}
function destroyMsNotes() { flushMsNotes(); try { S.msEditor?.handle?.destroy(); } catch {} S.msEditor = null; }
document.addEventListener("click", (e) => {
  const mo = e.target.closest("[data-ms-open]");
  if (mo && !e.target.closest("[data-more]")) { e.preventDefault(); location.hash = "#/m/" + encodeURIComponent(mo.dataset.msOpen); return; }
  const tl = e.target.closest("[data-ms-tl]");
  if (tl) { const id = tl.dataset.msTl; S.pendingTimeline = id; location.hash = "#/p/" + encodeURIComponent(S.ms.project.id); }
  const th = e.target.closest(".tl-col h3[data-ms-link]");
  if (th) { closeTimeline(true); location.hash = "#/m/" + encodeURIComponent(th.dataset.msLink); }
});
