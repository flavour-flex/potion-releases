// Hilfe & FAQ: Inhalte. {K} wird durch das eigene Kürzel ersetzt (z. B. CHR), {MOD} durch ⌘.
// Absätze mit Leerzeile trennen, "- " am Zeilenanfang ergibt eine Liste, `x` wird als Taste/Code gezeigt.
window.POTION_FAQ = [
  {
    id: "start", title: "Erste Schritte", icon: "✦",
    items: [
      { q: "Wo verbinde ich Linear, Jira, Confluence oder meinen Kalender?", a: `Unter **Einstellungen → Verbindungen**. Jeder Dienst hat eine Kachel mit Status. Ein Klick öffnet die Einrichtung: Schritte, Felder, „Verbinden“ (PO-TION prüft den Zugang sofort), später auch „Verbindung testen“ und „Trennen“.

Zu jeder Verbindung steht dort, **was gelesen wird, was geschrieben wird und was den Mac verlässt**. Unter „Demnächst“ siehst du, welche Verbindungen geplant sind.

Alle Einstellungen speichern sofort, einen Speichern-Knopf gibt es nicht mehr. Oben links findest du jede Einstellung über die Suche.` },
      { q: "Was ist PO-TION?", a: `PO-TION ist dein persönlicher Assistent für Aufgaben, Projekte und Meilensteine. Du schreibst wie in einem Chat, was ansteht, und PO-TION macht daraus saubere Aufgaben, plant deinen Tag und behält den Überblick, was hängt.

Die KI läuft komplett auf deinem Mac. Deine Inhalte gehen an keine Cloud-KI.` },
      { q: "Was passiert beim ersten Start?", a: `- Du wählst, wo deine Daten liegen: „Nur auf diesem Mac“ oder „Mit Linear“.
- Du gibst deinen Namen und optional deine Rolle ein. Die Rolle hilft der KI beim Einordnen.
- PO-TION lädt einmalig die Modell-Engine und das Sprachmodell (ca. 2,5 GB). Den Fortschritt siehst du über dem Eingabefeld.

Danach läuft alles offline.` },
      { q: "Wie fange ich am besten an?", a: `Schreib unten ins Eingabefeld einfach los, zum Beispiel:
- „Bis Freitag Release-Notes prüfen, ca. 2 Stunden“
- „Leg ein Projekt Website-Relaunch an, Go-Live Mitte Dezember“
- „Plan meinen Tag“

Mit \`{MOD}K\` springst du von überall ins Eingabefeld.` },
      { q: "Was brauche ich dafür?", a: `Einen Mac mit Apple-Chip (M1 oder neuer) und rund 4 GB freien Speicher. Für das genauere Modell 8B kommen weitere 5 GB dazu. 16 GB Arbeitsspeicher oder mehr sind für „Genau“ empfehlenswert.` },
    ],
  },
  {
    id: "chat", title: "Chat & KI", icon: "✎",
    items: [
      { q: "Was kann ich in den Chat schreiben?", a: `Fast alles rund um deine Arbeit:
- Neue Aufgaben, auch mehrere auf einmal: „Mail an den Datenschutz schreiben und Workshop vorbereiten“
- Änderungen: „{K}-12 auf Mittwoch verschieben“, „{K}-12 erledigt“
- Status: „{K}-7 liegt jetzt beim Dienstleister“, „Ich warte bei {K}-9 auf die Freigabe“
- Projekte und Meilensteine: „Verschieb den Meilenstein Pilot auf den 15.12.“
- Fragen: „Was hängt?“, „Was ist diese Woche fällig?“, „Was habe ich erledigt?“
- Dateien: „Fasse die Dateien zusammen“, „Was steht in der Präsentation zu den Fristen?“
- Jira und Confluence: „Such in Confluence nach Löschkonzept“` },
      { q: "Warum fragt PO-TION nach, statt sofort anzulegen?", a: `Bei neuen Aufgaben, Meilensteinen und Projekten zeigt PO-TION erst einen Vorschlag. Darin schlägt es ein passendes Projekt vor, setzt Datum, Priorität und Checkliste und erkennt, ob es eher ein Meilenstein ist.

Du prüfst kurz, änderst bei Bedarf und bestätigst mit \`Enter\`. So entsteht auch aus einem halben Satz eine vollständige Aufgabe.` },
      { q: "Welche Befehle gehen ohne KI, also sofort?", a: `Kurze, eindeutige Sätze führt PO-TION direkt aus, auch wenn das Modell noch lädt:
- „{K}-12 erledigt“, „{K}-12 in Arbeit“, „{K}-12 in Abnahme“, „{K}-12 parken“
- „{K}-12 löschen“ (landet im Archiv)
- „{K}-12 gehört zu SF-444“ (verknüpft mit Jira)
- „Was hängt?“, „Plan meinen Tag“, „Was habe ich diese Woche erledigt?“` },
      { q: "Was bedeuten „Schnell“ und „Genau“?", a: `Das sind die zwei lokalen Sprachmodelle:
- **Schnell** (Qwen3 4B): antwortet in wenigen Sekunden, reicht für die meisten Eingaben.
- **Genau** (Qwen3 8B): versteht lange und unklare Eingaben besser und fasst Dokumente gründlicher zusammen, ist aber langsamer.

Den Schalter siehst du rechts im Eingabefeld, sobald beide geladen sind. Das genaue Modell lädst du einmal unter Einstellungen → KI-Modell.` },
      { q: "Die KI hat etwas falsch verstanden. Was tun?", a: `Unter fast jeder Änderung steht „Rückgängig“. Das stellt den vorherigen Stand wieder her.

Hilfreich ist, die ID zu nennen („{K}-12 …“) oder in die Aufgabe zu gehen und dort zu schreiben. Dann bezieht sich alles auf genau diese Aufgabe. Mehrere oder alle Aufgaben auf einmal löscht PO-TION aus Sicherheitsgründen nie.` },
      { q: "Was zeigt die Anzeige, während die KI arbeitet?", a: `Du siehst, was gerade passiert, etwa „Liest Präsentation.pptx · Abschnitt 2 von 3“, dazu die Sekunden und wie viele Token das Modell schon geschrieben hat. Solange der Zähler steigt, arbeitet sie. Das Kolben-Logo oben brodelt dabei.` },
      { q: "Weiß der Chat, wo ich gerade bin?", a: `Ja. Das Eingabefeld unten ist überall dasselbe, bezieht sich aber auf die geöffnete Seite. In einer Aufgabe meint „erledigt“ genau diese Aufgabe, in einem Projekt landen neue Aufgaben dort. Oben im Eingabefeld steht, worauf es sich gerade bezieht.` },
    ],
  },
  {
    id: "tasks", title: "Aufgaben", icon: "✓",
    items: [
      { q: "Kann ich eine Fälligkeit mit Uhrzeit setzen?", a: `Ja. Die Uhrzeit ist optional:
- **Im Chat**: „bis Freitag 14 Uhr“, „morgen um 9“, „heute 16:30“, „bis 12.11. 10:00“, „in 2 Stunden“, „bis mittag“. Nur „bis 14 Uhr“ heißt heute (oder morgen, wenn es schon später ist).
- **In der Aufgabe**: neben dem Datum steht ein Zeitfeld. Leer lassen = fällig im Laufe des Tages.
- **In der Vorschlags-Maske**: ebenfalls neben dem Datum.

Mit Uhrzeit zeigt PO-TION z. B. „Noch 45 min · 14:00“ und die Aufgabe ist ab 14:00 überfällig, nicht erst am nächsten Tag. Linear speichert nur das Datum, die Uhrzeit merkt sich PO-TION auf deinem Mac.` },
      { q: "Wie berücksichtigt „Plan meinen Tag“ die Uhrzeit?", a: `Aufgaben mit Frist-Uhrzeit plant PO-TION zuerst ein, und zwar so, dass sie **vor** der Frist fertig sind, mit deiner Schätzung als Dauer. Reicht die Zeit nicht ganz, steht „knapp“ dabei. Passt gar nichts mehr davor, sagt PO-TION das ausdrücklich und fragt, ob du verschieben willst. Danach kommen die übrigen Aufgaben nach Dringlichkeit.` },
      { q: "Erinnert mich PO-TION an Fristen?", a: `Ja, bei Fristen mit Uhrzeit kommt eine Mac-Mitteilung, standardmäßig **30 Minuten vorher**. Ein Klick darauf öffnet die Aufgabe. Den Vorlauf (15, 30, 60 Minuten oder aus) stellst du unter Einstellungen → Erinnerungen ein. Das geht nur in der PO-TION-App, und macOS fragt beim ersten Mal, ob PO-TION Mitteilungen senden darf.` },
      { q: "Welche Status gibt es und wann nutze ich welchen?", a: `- **Eingang**: neu und noch nicht einsortiert
- **Später**: bewusst geparkt
- **Geplant**: steht an, noch nicht begonnen
- **In Arbeit**: du arbeitest gerade daran
- **Beim Dienstleister**: liegt bei einem externen Partner zur Umsetzung
- **Wartet auf**: du brauchst eine Antwort oder Freigabe von jemandem
- **Abnahme**: du musst testen oder abnehmen
- **Erledigt** / **Verworfen**: abgeschlossen

„Beim Dienstleister“ und „Wartet auf“ zählen als „hängt“ und erscheinen bei „Was hängt?“.` },
      { q: "Wie funktionieren Checkliste und Notizen?", a: `Die Checkliste sind die Teilschritte. Abhaken per Klick, neue Punkte unten eintippen und \`Enter\`. „Nächster Schritt“ zeigt den ersten offenen Punkt.

Die Notizen sind ein Markdown-Editor mit Überschriften, Listen, Tabellen und Code. Alles speichert sich automatisch.` },
      { q: "Was ist eine „Entscheidung“?", a: `Schreibst du „Entscheiden: Connector oder API?“, legt PO-TION die Aufgabe als offene Entscheidung an. Entscheidungen erscheinen auf der Projektseite gesammelt unter „Offene Entscheidungen“.` },
      { q: "Welche Tastenkürzel gibt es?", a: `- \`{MOD}K\`: in den Chat schreiben
- \`{MOD}J\`: suchen (Aufgaben, Projekte, Meilensteine, Kommentare, Hilfe, Jira, Confluence)
- \`{MOD}.\`: Befehlspalette mit allen Aktionen für das, was gerade offen ist (Status, Priorität, Fälligkeit, Umwandeln, Löschen …). In der Suche zeigt ein „>“ am Anfang nur Aktionen.
- \`{MOD}Z\`: letzte Änderung rückgängig, auch mehrfach hintereinander (nicht beim Tippen in einem Feld, dort gilt das normale Rückgängig)
- \`{MOD}Enter\`: Kommentar abschicken
- In Listen: Kästchen links oder \`{MOD}\`-Klick wählt aus, \`⇧\`-Klick wählt einen Bereich, \`{MOD}A\` alle, \`Esc\` hebt die Auswahl auf` },
      { q: "Wie ändere ich mehrere Aufgaben auf einmal?", a: `Fahr in einer Liste über eine Aufgabe und klick das Kästchen links (oder \`{MOD}\`-Klick auf die Zeile). Mit \`⇧\` wählst du einen ganzen Bereich. Unten erscheint eine Leiste: Status, Priorität, Fälligkeit, Projekt oder Löschen. PO-TION zeigt vorher, was passiert („2 Aufgaben: Status → Erledigt?“), erst „Anwenden“ ändert. Danach geht alles mit **Rückgängig** bzw. \`{MOD}Z\` zurück.` },
      { q: "Was zeigt die Meilenstein-Seite?", a: `Ein Klick auf einen Meilenstein im Projekt (oder auf seinen Namen im Zeitstrahl) öffnet seine Seite: Name und Zieldatum direkt bearbeiten, offene und erledigte Aufgaben, Notizen, Kommentare und den Verlauf. Neue Aufgaben, die du dort im Chat anlegst, landen automatisch in diesem Meilenstein. Mit den Pfeilen springst du zum vorherigen oder nächsten Meilenstein.` },
      { q: "Was bedeutet „Gestützt auf“ unter einer Antwort?", a: `Darunter steht, woraus die Antwort stammt, z. B. „4 Kommentare, davon 2 aus Jira“ oder „Datei Angebot.pdf“. Steht dort **Feste Auswertung**, kam die Antwort ohne Sprachmodell direkt aus deinen Daten, etwa bei „Was ist bis Montag fällig?“. Das ist schnell und immer gleich.` },
      { q: "Wie sehe ich die Einführung noch einmal?", a: `In der Hilfe oben auf „Einführung ansehen“, oder \`{MOD}.\` und „Einführung“ tippen.` },
      { q: "Wie funktionieren Kommentare?", a: `Unter den Notizen jeder Aufgabe und jedes Projekts steht der Bereich **Kommentare**. Schreiben, mit \`{MOD}Enter\` absenden, eigene Kommentare lassen sich bearbeiten und löschen. **Fett**, Links und Listen mit „- “ funktionieren.
- **Speicherort:** Mit Linear landen Kommentare an Aufgaben in Linear, im lokalen Modus auf deinem Mac. Projekt-Kommentare liegen immer in PO-TION, Linear kennt dort keine einfachen Kommentare.
- **Jira:** Ist ein Ticket verknüpft, stehen seine Kommentare im selben Strang. Beim Schreiben kannst du „Auch in Jira posten“ ankreuzen. Ohne Haken bleibt der Kommentar nur in PO-TION bzw. Linear.
- **Verlauf:** Kommentare erscheinen dort als Sprechblasen zwischen den Änderungen. Oben lässt sich nach „Kommentare“ oder „Änderungen“ filtern.
- **KI:** „Zusammenfassen“ fasst alle Kommentare zusammen, mit offenen Punkten und Entscheidungen. Offene Punkte übernimmst du per Klick in die Checkliste. Im Chat gehen auch Fragen wie „Was hat der Dienstleister geschrieben?“, „Fasse die Kommentare zu {K}-12 zusammen“ oder „Kommentar: Rückruf am Dienstag“. Bei Projekten liest die KI auch die Kommentare aller Aufgaben im Projekt.` },
      { q: "Kann PO-TION Jira-Tickets ändern?", a: `Ja, aber **nur wenn du es bestätigst**, nie von selbst.
- **Nach einem Statuswechsel:** Ist eine Aufgabe mit einem Jira-Ticket verknüpft und du änderst ihren Status, fragt PO-TION unten rechts, ob Jira mitziehen soll. Den passenden Jira-Status schlägt es vor. Du kannst einen anderen wählen oder „Nein, Jira so lassen“ klicken.
- **Direkt in der Aufgabe:** In der Jira-Karte gibt es „Status ändern“ und „Bearbeiter“. Erst „Ja, in Jira ändern“ schickt die Änderung ab.
- Statuswechsel lassen sich direkt danach mit **Rückgängig** zurücknehmen, sofern Jira den Weg zurück erlaubt. Jede Änderung steht im Verlauf der Aufgabe.

PO-TION kann nur, was dein Jira-Konto darf. Erlaubt euer Workflow einen Wechsel nicht, taucht er nicht in der Auswahl auf.` },
      { q: "Falsch angelegt? Aufgabe, Projekt oder Meilenstein umwandeln", a: `Über das **⋯** oben rechts in einer Aufgabe oder einem Projekt, bei Meilensteinen über das ⋯ auf der Meilenstein-Karte:
- **Aufgabe → Checklisten-Punkt** einer anderen Aufgabe (Notizen wandern mit), **→ Projekt** (Checklisten-Punkte werden Aufgaben) oder **→ Meilenstein** (Fälligkeit wird Zieldatum)
- **Projekt → Aufgabe**: offene Aufgaben werden Checklisten-Punkte, das Projekt kommt ins Archiv
- **Meilenstein → Aufgabe**: Zieldatum wird Fälligkeit, seine Aufgaben bleiben im Projekt
- **Checklisten-Punkt → eigene Aufgabe**: das ⇄ rechts neben dem Punkt

Im Chat geht es auch: „mach aus {K}-12 ein Projekt“, „{K}-12 in die Checkliste von {K}-14“, „Punkt Review aus {K}-12 als Aufgabe“, „Projekt Releases in eine Aufgabe umwandeln“.

Jede Umwandlung lässt sich direkt danach mit **Rückgängig** zurücknehmen.` },
      { q: "Wie lösche ich Projekte und Meilensteine?", a: `Über **⋯ → Löschen** oder im Chat („lösch Projekt Releases“, „lösch Meilenstein Ist-Analyse“). Bei einem Projekt mit offenen Aufgaben fragt PO-TION, ob die mitgelöscht werden oder ohne Projekt bleiben. Beim Meilenstein bleiben die Aufgaben im Projekt. Alles landet im Archiv und lässt sich rückgängig machen.` },
      { q: "Was passiert beim Löschen?", a: `Gelöschte Aufgaben landen im **Archiv** (Symbol oben rechts) und lassen sich dort mit „Wieder öffnen“ zurückholen. Auch erledigte und verworfene Aufgaben findest du dort.` },
      { q: "Was steht im Verlauf einer Aufgabe?", a: `Ganz unten in jeder Aufgabe und jedem Projekt steht jede Änderung mit Uhrzeit: Status, Fälligkeit, Checkpunkte, Dateien, Jira-Verknüpfungen, KI-Zusammenfassungen. Bei Linear als Datenquelle kommen auch Änderungen und Kommentare dazu, die direkt in Linear passiert sind.` },
    ],
  },
  {
    id: "projects", title: "Projekte & Meilensteine", icon: "▤",
    items: [
      { q: "Wie lege ich ein Projekt an?", a: `Zum Beispiel: „Leg ein Projekt Loyalty-Programm an, Ziel: Punkte im Onlineshop, Meilensteine Konzept 15.11. und Go-Live 31.03.“. PO-TION zeigt einen Vorschlag mit Ziel, Zieldatum und Meilensteinen, den du bestätigst.

Auf der Startseite gibt es dafür auch den Knopf „Neues Projekt“.` },
      { q: "Wann Aufgabe, wann Meilenstein?", a: `Ein **Meilenstein** ist ein fester Termin oder ein Ergebnis im Projekt, zum Beispiel Abnahme, Go-Live, Präsentation oder Workshop. **Aufgaben** sind die Arbeit, die dorthin führt, und können einem Meilenstein zugeordnet werden.

PO-TION erkennt typische Meilenstein-Wörter und fragt im Vorschlag nach.` },
      { q: "Was zeigt die Projektseite?", a: `- Fortschritt, nächster Meilenstein und was hängt (oben)
- Meilensteine als Karten. Ein Klick öffnet den Zeitstrahl.
- Einen Hinweis auf das größte Risiko, etwa „Meilenstein X hängt an Y“
- Breit: Dateien und Projekt-Notizen
- Rechts: Jetzt dran, Hängt (mit „Nachhaken“), offene Entscheidungen und alle Aufgaben nach Meilenstein` },
      { q: "Was ist der Zeitstrahl?", a: `Klick auf einen Meilenstein oder „Zeitstrahl ansehen“. Du siehst alle Meilensteine auf einer Zeitachse mit „Heute“-Markierung und Fortschrittsringen. Darunter hat jeder Meilenstein eine Spalte mit seinen Aufgaben. \`Esc\` schließt.` },
      { q: "Was macht „Nachhaken“?", a: `Bei Aufgaben, die bei jemandem hängen, vermerkt „Nachhaken“ das Datum in der Aufgabe. Dazu bekommst du einen kurzen, höflichen Nachfrage-Text zum Kopieren.` },
    ],
  },
  {
    id: "files", title: "Dateien", icon: "📎",
    items: [
      { q: "Wie lege ich einen Screenshot ab?", a: `Drück überall am Mac **⌘⇧2** (änderbar unter Einstellungen → Screenshots). Dann ziehst du einen Bereich auf, wie mit ⌘⇧4. Mit der Leertaste nimmst du stattdessen ein ganzes Fenster, Esc bricht ab.

Danach erscheint ein kleines Fenster:
- **Wohin?** Oben stehen die Aufgaben, an denen du zuletzt gearbeitet hast. Tipp etwas ein, um zu suchen, oder tipp einen Titel und wähl „Neue Aufgabe anlegen“.
- **Name**: vorausgefüllt mit der Uhrzeit, kannst du ändern.
- **Text auslesen und zusammenfassen**: liest den Text im Bild und schreibt eine Zusammenfassung mit nächsten Schritten, Fristen und offenen Fragen in die Notizen.

\`↵\` legt ab, \`esc\` verwirft die Aufnahme.` },
      { q: "Wie liest PO-TION den Text aus einem Screenshot?", a: `Mit der Texterkennung von macOS (Apple Vision), direkt auf deinem Mac. Danach fasst das lokale Sprachmodell zusammen. Nichts davon geht ins Internet.

Gut geeignet sind E-Mails, Chats, Tickets, Folien oder Tabellen. Der erkannte Text wird gemerkt. Du kannst später im Chat fragen, z. B. „Was steht im Screenshot zu den Fristen?“ oder „Fasse den Screenshot zusammen“.` },
      { q: "Der Screenshot zeigt nur den Schreibtisch. Was tun?", a: `macOS hat PO-TION die **Bildschirmaufnahme** noch nicht erlaubt. Öffne Systemeinstellungen → Datenschutz & Sicherheit → Bildschirm- & Systemaudioaufnahme, schalte PO-TION ein und starte PO-TION neu. Unter Einstellungen → Screenshots führt „Freigabe prüfen“ direkt dorthin.

Nach einem großen Update (alle paar Monate) kann macOS erneut fragen. Bei den normalen, kleinen Updates bleibt die Freigabe erhalten.` },
      { q: "Das Kürzel tut nichts. Woran liegt das?", a: `- Es funktioniert nur in der PO-TION-App, nicht im Browser.
- Eine andere App nutzt dasselbe Kürzel. Unter Einstellungen → Screenshots siehst du das und kannst ein anderes wählen.
- PO-TION muss laufen. Auch mit geschlossenem Fenster ist es weiter aktiv, solange du es nicht beendest.` },
      { q: "Wie lege ich Dateien ab?", a: `Zieh eine Datei einfach ins Fenster. PO-TION liest den Inhalt, schlägt die passende Aufgabe vor (oder eine neue) und legt die Datei sortiert im Ablageordner ab: \`Ablage/Projekt/Aufgabe/Datum_Name\`. In einer geöffneten Aufgabe landet sie direkt dort.` },
      { q: "Kann die KI Dateien lesen und zusammenfassen?", a: `Ja. PO-TION liest PDF, PowerPoint (inklusive Sprechernotizen), Word, Excel und Textdateien:
- „Fasse die Dateien zusammen“ oder der Knopf „Dateien zusammenfassen“ schreibt Kurzfassung, Kernpunkte, Entscheidungen, nächste Schritte, offene Fragen und Termine in die Notizen.
- „Was steht in der Präsentation zu …?“ beantwortet Fragen mit Quelle (Datei, Folie).
- Gefundene nächste Schritte lassen sich per Klick als Checkliste übernehmen.

Eingescannte PDFs ohne Text kann PO-TION nicht lesen.` },
      { q: "Wo liegt der Ablageordner?", a: `Standardmäßig unter \`~/crxs/Ablage\`. Ändern kannst du ihn unter Einstellungen → Planung → Ablageordner.` },
    ],
  },
  {
    id: "jira", title: "Jira & Confluence", icon: "J",
    items: [
      { q: "Wie verbinde ich Jira und Confluence?", a: `Unter Einstellungen → Verbindungen → Jira trägst du drei Dinge ein:
- die Atlassian-Adresse deiner Firma (z. B. \`https://firma.atlassian.net\`)
- deine E-Mail
- einen API-Token, den du auf id.atlassian.com → Sicherheit → API-Tokens anlegst

PO-TION liest nur und ändert in Jira nichts. Confluence nutzt denselben Zugang.` },
      { q: "Was ist der Jira-Eingang oben rechts?", a: `Der Knopf „Jira“ zeigt dir zugewiesene, offene Tickets, die noch mit keiner Aufgabe verknüpft sind. Pro Ticket kannst du „Neue Aufgabe“ wählen oder es einer vorhandenen Aufgabe zuordnen. Das passiert nur auf Klick, nie automatisch.` },
      { q: "Wie suche ich in Jira und Confluence?", a: `Frag im Chat, zum Beispiel „Such in Jira und Confluence nach Earn & Burn“ oder „Gibt es in Confluence was zum Löschkonzept?“.

PO-TION sucht mehrere Schreibweisen, zeigt bis zu 50 Treffer als Karten und fasst sie kurz zusammen. Über „Alle in Jira öffnen“ siehst du dieselbe Suche im Browser. Begriffe in Anführungszeichen werden genau so gesucht.` },
      { q: "Jira meldet 401 oder 403. Was heißt das?", a: `- **401**: E-Mail und Token passen nicht zusammen. Die E-Mail muss die deines Atlassian-Kontos sein, der Token komplett kopiert.
- **403**: Der Token ist gültig, aber der Zugriff ist gesperrt. Oft erlaubt die Atlassian-Verwaltung deiner Firma keine API-Tokens, dann hilft nur die IT.` },
    ],
  },
  {
    id: "calendar", title: "Kalender & Planung", icon: "◷",
    items: [
      { q: "Mein Kalender zeigt nur „Gebucht“. Was kann ich tun?", a: `Viele Firmen erlauben im ICS-Link nur „frei/belegt“. Dann gibst du Terminen in PO-TION selbst einen Namen: **Doppelklick auf den Termin** in der Kalenderansicht (oder Klick → „Benennen & verknüpfen“).

- **Name**: z. B. „Jour fixe adesso“. Er gilt nur in PO-TION.
- **Zuordnung**: Projekt oder Aufgabe suchen und wählen.
- **Wiederkehrende Termine** erkennt PO-TION an der Serie oder daran, dass sie immer am gleichen Wochentag zur gleichen Uhrzeit liegen. Übernommen wird das **nur, wenn du es bestätigst**: Nach dem Speichern fragt PO-TION „Für alle übernehmen?“. Passende Termine, die noch keinen Namen haben, zeigt der Kalender gestrichelt mit Fragezeichen als Vorschlag, bis du „Ja“ oder „Nein“ sagst.` },
      { q: "Wie nutze ich Termine für Vor- und Nachbereitung?", a: `Im Termin-Fenster (Doppelklick auf den Termin):
- **Vorbereitung**: Bei verknüpftem Projekt stehen die offenen Punkte da, zuerst was hängt, offene Entscheidungen und Überfälliges. Dazu die Notizen vom letzten Termin derselben Serie.
- **Notizen**: Stichpunkte während oder nach dem Termin, werden sofort gespeichert.
- **Zusammenfassen & Aufgaben ableiten**: Die KI fasst deine Stichpunkte zusammen (Kernpunkte, Entscheidungen, offene Fragen) und schlägt Punkte vor. Die Zusammenfassung bleibt beim Termin, in die Notizen von Aufgaben oder Projekten schreibt PO-TION nichts.

Wohin die Punkte gehen, hängt von der Verknüpfung ab:
- **Aufgabe**: standardmäßig als **Checkliste** der Aufgabe. Pro Punkt kannst du auf „Aufgabe“ umschalten, dann wird es eine eigene Aufgabe im selben Projekt („Gehört zu CHR-12“).
- **Meilenstein**: als Aufgaben in diesem Meilenstein.
- **Projekt**: als Aufgaben im Projekt.

Beim nächsten Termin derselben Serie zeigt die Vorbereitung **„Offen aus dem letzten Termin“** mit Haken an allem, was schon erledigt ist. Termine lassen sich mit Aufgaben, Projekten und **Meilensteinen** verknüpfen. Gibt es noch nichts Passendes, legst du es direkt im Termin-Fenster neu an.` },
      { q: "Wo sehe ich meinen Kalender?", a: `Klick oben auf den **Termin-Hinweis** (z. B. „Belegt ab 13:00“) oder im Bereich **Heute** auf „Kalender öffnen“.

Die Kalenderansicht zeigt in **Woche** oder **Monat**:
- Termine aus **Outlook/ICS** (blau) und dem **Apple Kalender** (grün)
- **Fälligkeiten** deiner Aufgaben: mit Uhrzeit als Markierung zur Uhrzeit, ohne Uhrzeit oben bei „Ganztägig“
- **Meilensteine** und **Projekt-Zieltermine** (orange)
- heute die **Vorschläge** aus „Plan meinen Tag“ (gestrichelt)

Oben schaltest du jede Ebene ein und aus. Ein Klick auf eine Aufgabe öffnet sie, auf einen Meilenstein den Zeitstrahl, auf einen Termin die Details mit „Aufgabe dazu anlegen“. Tasten: ← → blättern, T heute, W Woche, M Monat.

Termintitel werden nur auf deinem Mac angezeigt. Wer das nicht will, schaltet sie je Kalender unter Einstellungen → Verbindungen aus, dann steht dort „Belegt“.` },
      { q: "Wie binde ich meinen Kalender ein?", a: `Es gibt zwei Wege, die du auch **gleichzeitig** nutzen kannst. PO-TION führt die belegten Zeiten zusammen.
- **Apple Kalender** (Einstellungen → Verbindungen → Apple Kalender): der Kalender von Mac und iPhone, mit allen Konten, die dort eingerichtet sind (iCloud, Exchange, Google). „Verbinden & Zugriff erlauben“ klicken, in macOS „Vollzugriff“ erlauben, Kalender auswählen.
- **ICS-Link** (Einstellungen → Verbindungen → Kalender (ICS)): z. B. für einen Outlook-Kalender, der nicht auf dem Mac eingerichtet ist. In Outlook im Web: Einstellungen → Kalender → Freigegebene Kalender → „Kalender veröffentlichen“ → „Kann sehen, wann ich beschäftigt bin“ → ICS-Link kopieren.

PO-TION nutzt nur „frei/belegt“, keine Titel, Orte oder Teilnehmer. Ganztägige und als „frei“ markierte Termine blockieren keine Zeit.` },
      { q: "Kann PO-TION Termine in meinen Kalender eintragen?", a: `Ja, beim Apple Kalender mit **„Lesen & schreiben“**. Dann trägt PO-TION Fristen mit Uhrzeit als kurzen Termin ein (15 Minuten, endet zur Frist), z. B. „Frist: CHR-12 Konzept schicken“. Ändert sich die Frist oder ist die Aufgabe erledigt, zieht PO-TION den Termin nach oder entfernt ihn.

Am besten wählst du „Neuer Kalender ‚PO-TION‘“: Den kannst du am iPhone ein- und ausblenden, und er zählt nicht als belegt. Stellst du auf „Nur lesen“ zurück oder trennst die Verbindung, entfernt PO-TION alle Termine wieder, die es selbst eingetragen hat. Andere Termine fasst PO-TION nie an.` },
      { q: "Der Apple Kalender meldet „Kein Zugriff“. Was tun?", a: `macOS hat den Zugriff abgelehnt oder nur „Schreiben“ erlaubt. Öffne Systemeinstellungen → Datenschutz & Sicherheit → Kalender und stell PO-TION auf **Vollzugriff**. Danach in PO-TION unter Verbindungen → Apple Kalender „Verbindung testen“.` },
      { q: "Was macht „Plan meinen Tag“?", a: `PO-TION legt deine wichtigsten Aufgaben in die freien Zeiten zwischen deinen Terminen. Dabei richtet es sich nach Dringlichkeit, Fälligkeit und geschätztem Aufwand. Arbeitszeit und Arbeitstage stellst du unter Einstellungen → Planung ein.` },
    ],
  },
  {
    id: "keys", title: "Suche & Tastenkürzel", icon: "⌘",
    items: [
      { q: "Welche Tastenkürzel gibt es?", a: `- \`{MOD}K\`: in den Chat schreiben, von überall (steht auch unten im Chatfeld)
- \`⌘⇧2\`: Screenshot aufnehmen und ablegen, überall am Mac (änderbar)
- \`{MOD}J\`: interne Suche über Aufgaben, Projekte und Meilensteine (auch Archiv). Alternativ ein Klick auf die Suchleiste oben
- \`↑\` \`↓\` und \`Enter\`: Treffer in der Suche wählen
- \`Enter\`: Vorschlag anlegen, \`Shift+Enter\`: neue Zeile im Chat
- \`Esc\`: Suche, Zeitstrahl oder Aufgabe schließen
- \`{MOD},\`: Einstellungen` },
      { q: "Was durchsucht die Suche?", a: `\`{MOD}J\` oder ein Klick auf die Suchleiste oben durchsucht alles auf einmal:
- **Aufgaben, Projekte und Meilensteine**: Titel, IDs und Notizen, auch erledigte und archivierte. Ein Meilenstein-Treffer öffnet direkt den Zeitstrahl.
- **Hilfe**: passende Fragen aus dieser FAQ. Ein Klick öffnet die Antwort.
- **Jira und Confluence** (wenn verbunden): ab 3 Zeichen, die Treffer kommen nach einem Moment dazu. Über „Alle Treffer“ geht es direkt in die Jira- bzw. Confluence-Suche.

Findest du nichts, kannst du stattdessen die KI fragen.` },
    ],
  },
  {
    id: "data", title: "Daten & Datenschutz", icon: "🔒",
    items: [
      { q: "Wo liegen meine Daten?", a: `- **Nur auf diesem Mac**: Aufgaben, Projekte und Notizen liegen in \`~/Library/Application Support/crxs/local-data.json\`, mit täglicher Sicherung im Ordner \`backups\` für 14 Tage.
- **Mit Linear**: Aufgaben und Projekte liegen in deinem Linear-Workspace, Dateien und Verlauf trotzdem lokal.

Schlüssel und Tokens speichert PO-TION im macOS-Schlüsselbund.` },
      { q: "Was geht ins Internet?", a: `Die KI läuft lokal, deine Inhalte gehen an keine Cloud-KI. Nach außen spricht PO-TION nur mit:
- den Diensten, die du selbst einträgst (Linear, Jira/Confluence, Kalender-Abo)
- GitHub und Hugging Face beim einmaligen Laden von Engine und Modell
- GitHub für die Update-Prüfung

Im Modus „Nur auf diesem Mac“ ohne Jira und Kalender bleibt alles offline.` },
      { q: "Wie wechsle ich zwischen Linear und lokal?", a: `Unter Einstellungen → Datenquelle:
- **Linear → lokal**: „Alles aus Linear übernehmen“ holt offene, erledigte und archivierte Aufgaben, Projekte, Meilensteine und Notizen. Die IDs bleiben gleich.
- **Im lokalen Modus**: „Aus Linear übernehmen“ ergänzt fehlende Daten oder ersetzt alles.
- **Lokal → Linear**: „Zurück zu Linear“ überträgt deine Daten. Die Aufgaben bekommen dort neue Nummern.

In Linear wird beim Übernehmen nie etwas gelöscht.` },
      { q: "Was ist das Linear-Kontingent?", a: `Im kostenlosen Linear-Plan sind 250 aktive Vorgänge pro Workspace erlaubt. Erledigte und verworfene zählen mit, archivierte nicht. Unter Einstellungen → Linear-Kontingent siehst du den Stand und kannst alte, abgeschlossene Aufgaben archivieren. Im lokalen Modus gibt es kein Limit.` },
      { q: "Was zählt der Token-Zähler?", a: `Wie viel das lokale Modell gelesen und geschrieben hat, pro Tag, Woche und insgesamt. Zum Vergleich zeigt PO-TION, was dieselben Token über eine Cloud-API ungefähr gekostet hätten. Lokal kostet es nichts.` },
    ],
  },
  {
    id: "install", title: "Installation & Updates", icon: "↓",
    items: [
      { q: "Wie installiere ich PO-TION auf einem anderen Mac?", a: `Terminal öffnen und einfügen:

\`curl -fsSL https://raw.githubusercontent.com/flavour-flex/potion-releases/main/install.sh | bash\`

Der Installer legt PO-TION nach \`~/Applications\` und startet es. Ein Doppelklick auf eine heruntergeladene ZIP funktioniert nicht, weil die App nicht von Apple notarisiert ist.` },
      { q: "Wie bekomme ich Updates?", a: `PO-TION prüft regelmäßig, ob es eine neue Version gibt. Dann erscheint oben rechts „Update …“. Unter Einstellungen → App → „Jetzt aktualisieren“ lädt PO-TION die neue Version, prüft sie, tauscht sich aus und startet neu. Deine Daten bleiben unverändert. Installiert wird nur auf Klick.` },
      { q: "Wie beende oder deinstalliere ich PO-TION?", a: `Beenden über das Menü PO-TION → Beenden (\`{MOD}Q\`) oder Einstellungen → App → „PO-TION beenden“. Schließt du nur das Fenster, bleibt PO-TION im Dock.

Deinstallieren: \`~/Applications/PO-TION.app\` löschen. Deine Daten liegen in \`~/Library/Application Support/crxs\`.` },
    ],
  },
  {
    id: "help", title: "Probleme lösen", icon: "?",
    items: [
      { q: "Das Modell lädt sehr lange oder startet nicht", a: `- Beim ersten Mal lädt PO-TION mehrere GB herunter. Über dem Eingabefeld siehst du Fortschritt und Restzeit.
- Beim Start zeigt der Streifen die Phase, etwa „Lädt das Modell in den Grafikspeicher“. Das genaue Modell braucht länger.
- Bei „Modell: Fehler“ steht der Grund in den Einstellungen unter KI-Modell, dort gibt es auch „Erneut versuchen“.
- Details stehen in \`~/Library/Application Support/crxs/llama.log\`.` },
      { q: "Linear meldet einen Fehler", a: `- „Key ungültig“: In Linear unter Einstellungen → Sicherheit & Zugriff einen neuen persönlichen API-Key anlegen und eintragen.
- „Nicht erreichbar“: PO-TION merkt sich die Eingabe und führt sie aus, sobald die Verbindung wieder da ist („… wartet“ im Eingabefeld).
- Neue Aufgaben gehen nicht mehr: Vermutlich ist das Linear-Limit von 250 erreicht, siehe Linear-Kontingent.` },
      { q: "Wo finde ich Protokolle für die Fehlersuche?", a: `Im Ordner \`~/Library/Application Support/crxs\`: \`crxs.log\` für den Dienst und \`llama.log\` für das Sprachmodell. Im Finder erreichst du ihn über Gehe zu → Gehe zum Ordner.` },
    ],
  },
];
