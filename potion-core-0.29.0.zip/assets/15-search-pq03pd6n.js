// PO-TION Oberfläche · 15-search.js
// Klassische Skripte im gemeinsamen globalen Bereich, Reihenfolge laut ui/js (Dateiname). Start in 99-boot.js.
"use strict";
// ---------- Interne Suche (⌘J) ----------
async function openSearch(prefill = "") {
  if ($(".sp")) { const i = $(".sp input"); if (prefill) { i.value = prefill; drawSearch(prefill); } i.focus(); return; }
  document.body.insertAdjacentHTML("beforeend", `<div class="sp" role="dialog" aria-modal="true" aria-label="Suche"><div class="sp-box">
    <label class="sp-in">${I.search}<input placeholder="Aufgaben, Projekte, Hilfe, Jira und Confluence durchsuchen …" autocomplete="off" spellcheck="false"><kbd>esc</kbd></label>
    <div class="sp-res">${spHint()}</div>
    <div class="sp-foot"><span><kbd>↑</kbd><kbd>↓</kbd> wählen</span><span><kbd>↵</kbd> öffnen</span><span><kbd>&gt;</kbd> nur Aktionen</span><span><kbd>${MOD}K</kbd> stattdessen fragen</span></div>
  </div></div>`);
  const sp = $(".sp");
  requestAnimationFrame(() => sp.classList.add("in"));
  const input = sp.querySelector("input");
  input.focus();
  if (prefill) { input.value = prefill; }
  drawSearch(input.value);
  if (!S.searchIndex || Date.now() - S.searchIndex.at > 60000) {
    api("/api/search-index").then((r) => { S.searchIndex = { at: Date.now(), items: r.items }; if (input.value) drawSearch(input.value); }).catch(() => {});
  }
  input.addEventListener("input", () => drawSearch(input.value));
  input.addEventListener("keydown", (e) => {
    const res = [...sp.querySelectorAll(".sp-item")];
    let k = res.findIndex((x) => x.classList.contains("sel"));
    if (e.key === "ArrowDown" || e.key === "ArrowUp") {
      e.preventDefault();
      k = e.key === "ArrowDown" ? Math.min(res.length - 1, k + 1) : Math.max(0, k - 1);
      res.forEach((x, j) => x.classList.toggle("sel", j === k));
      res[k]?.scrollIntoView({ block: "nearest" });
    } else if (e.key === "Enter") { e.preventDefault(); (res[k] || res[0])?.click(); }
  });
}
function scoreItem(it, words) {
  const t = it.title.toLowerCase(), id = (it.t === "task" ? it.id : "").toLowerCase(), sub = (it.sub || "").toLowerCase(), tx = (it.text || "").toLowerCase();
  let sc = 0;
  for (const w of words) {
    if (id && id === w) sc += 100;
    else if (id && w.length >= 2 && /\d/.test(w) && id.includes(w)) sc += 60;
    else if (t.startsWith(w)) sc += 30;
    else if (t.split(/[^a-z0-9äöüß]+/).some((x) => x.startsWith(w))) sc += 20;
    else if (t.includes(w)) sc += 12;
    else if (sub.includes(w)) sc += 6;
    else if (tx.includes(w)) sc += 3;
    else return 0;
  }
  return sc + (it.t === "project" ? 6 : it.t === "milestone" ? 3 : 0) - (it.done ? 8 : 0);
}
function mark(text, words) {
  let h = esc(text);
  for (const w of words) if (w.length > 1) h = h.replace(new RegExp(`(${w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")})`, "ig"), "<mark>$1</mark>");
  return h;
}
function spHint() {
  const ext = S.status?.jira?.configured;
  return `<div class="sp-hint"><p>Tippe los. Durchsucht werden:</p><div class="sp-scopes">
    <span>${I.task}Aufgaben & Notizen</span><span>${I.proj}Projekte</span><span>${I.flag}Meilensteine</span><span>${I.help}Hilfe</span>
    ${ext ? `<span><b class="sp-j">J</b>Jira</span><span>${I.conf}Confluence</span>` : `<span class="off" title="Unter Einstellungen → Verbindungen einrichten">Jira & Confluence nicht verbunden</span>`}
  </div></div>`;
}
// Hilfe-Einträge als Suchindex (einmal aufgebaut)
function faqIndex() {
  if (S.faqIndex) return S.faqIndex;
  const plain = (t) => faqText(t).replace(/\*\*|`/g, "").replace(/^\s*[-*]\s+/gm, "").replace(/\s+/g, " ").trim();
  S.faqIndex = (window.POTION_FAQ || []).flatMap((c) => c.items.map((it, k) => ({ id: `${c.id}-${k}`, cat: c.title, q: faqText(it.q), a: plain(it.a) })));
  return S.faqIndex;
}
function scoreFaq(f, words) {
  const q = f.q.toLowerCase(), a = f.a.toLowerCase(), c = f.cat.toLowerCase();
  let sc = 0;
  for (const w of words) {
    if (q.split(/[^a-z0-9äöüß]+/).some((x) => x.startsWith(w))) sc += 14;
    else if (q.includes(w)) sc += 9;
    else if (c.includes(w)) sc += 5;
    else if (a.includes(w)) sc += 3;
    else return 0;
  }
  return sc;
}
function faqSnippet(a, words) {
  const low = a.toLowerCase();
  const at = Math.max(0, Math.min(...words.map((w) => { const i = low.indexOf(w); return i < 0 ? 1e9 : i; })));
  const from = at > 1e8 ? 0 : Math.max(0, at - 40);
  return (from ? "… " : "") + a.slice(from, from + 130) + (a.length > from + 130 ? " …" : "");
}
function spItems(list, words, start) {
  return list.map(({ it }, j) => {
    const attr = it.t === "task" ? `data-open="${esc(it.id)}"` : it.t === "project" ? `data-project="${esc(it.id)}"` : `data-sp-ms="${esc(it.id)}|${esc(it.ms)}"`;
    const ico = it.t === "task" ? (it.done ? I.check("currentColor", 13) : I.task) : it.t === "project" ? I.proj : I.flag;
    return `<button class="sp-item t-${it.t}${it.done ? " is-done" : ""}" ${attr} style="--i:${Math.min(start + j, 12)}"><span class="sp-ico">${ico}</span><span class="sp-main"><span class="sp-title">${it.t === "task" ? `<span class="idf">${esc(it.id)}</span>` : ""}<span class="sp-t">${mark(it.title, words)}</span></span><span class="sp-sub">${mark(it.sub || "", words)}${it.done ? " · im Archiv" : ""}</span></span><span class="sp-go">↵</span></button>`;
  }).join("");
}
function drawSearch(q) {
  const box = $(".sp-res");
  if (!box) return;
  const onlyActs = /^\s*>/.test(q);
  const words = q.replace(/^\s*>/, "").toLowerCase().trim().split(/\s+/).filter(Boolean);
  clearTimeout(S.extTimer);
  const acts = paletteActions();
  const actHits = (words.length ? acts.map((a) => ({ a, sc: words.every((w) => (a.label + " " + (a.sub || "") + " " + (a.keys || "")).toLowerCase().includes(w)) ? 1 : 0 })).filter((x) => x.sc) : acts.filter((a) => a.ctx || onlyActs).map((a) => ({ a }))).slice(0, onlyActs ? 30 : words.length ? 5 : 8);
  SP_ACTS.list = actHits.map((x) => x.a);
  const actHtml = actHits.length ? `<div class="sp-sec"><div class="sp-sec-h">Aktionen${acts.some((a) => a.ctx) ? ` · ${esc(paletteScopeLabel())}` : ""}</div>${actHits.map((x, j) => `<button class="sp-item t-act" data-sp-act="${j}" style="--i:${j}"><span class="sp-ico">${x.a.icon || I.spark}</span><span class="sp-main"><span class="sp-title"><span class="sp-t">${esc(x.a.label)}</span></span>${x.a.sub ? `<span class="sp-sub">${esc(x.a.sub)}</span>` : ""}</span><span class="sp-go">${x.a.danger ? "↵ ↵" : "↵"}</span></button>`).join("")}</div>` : "";
  if (onlyActs) { box.innerHTML = actHtml || `<p class="sp-hint">Keine passende Aktion.</p>`; return; }
  if (!words.length) { box.innerHTML = actHtml + spHint(); return; }
  if (!S.searchIndex) { box.innerHTML = `<p class="sp-hint">Lade Index …</p>`; return; }
  const hits = S.searchIndex.items.map((it) => ({ it, sc: scoreItem(it, words) })).filter((x) => x.sc > 0).sort((a, b) => b.sc - a.sc).slice(0, 30);
  const faqs = faqIndex().map((f) => ({ f, sc: scoreFaq(f, words) })).filter((x) => x.sc > 0).sort((a, b) => b.sc - a.sc).slice(0, 4);
  const sec = { project: "Projekte", milestone: "Meilensteine", task: "Aufgaben" };
  let n = 0, html = actHtml;
  const cap = { project: 4, milestone: 4, task: 8 };
  for (const t of ["project", "milestone", "task"]) {
    const hs = hits.filter((h) => h.it.t === t).slice(0, cap[t]);
    if (!hs.length) continue;
    html += `<div class="sp-sec"><div class="sp-sec-h">${sec[t]}</div>${spItems(hs, words, n)}</div>`;
    n += hs.length;
  }
  if (faqs.length) {
    html += `<div class="sp-sec"><div class="sp-sec-h">Hilfe</div>${faqs.map(({ f }, j) => `<button class="sp-item t-faq" data-sp-faq="${esc(f.id)}" style="--i:${Math.min(n + j, 12)}"><span class="sp-ico">${I.help}</span><span class="sp-main"><span class="sp-title"><span class="sp-t">${mark(f.q, words)}</span></span><span class="sp-sub">${esc(f.cat)} · ${mark(faqSnippet(f.a, words), words)}</span></span><span class="sp-go">↵</span></button>`).join("")}</div>`;
    n += faqs.length;
  }
  if (!n) html += `<p class="sp-hint sp-none">In PO-TION nichts gefunden. <button class="linkbtn" data-sp-ask="${esc(q)}">Stattdessen die KI fragen</button></p>`;
  // Jira & Confluence: Platz reservieren, Ergebnis kommt nach
  const ext = S.status?.jira?.configured;
  const key = q.trim().toLowerCase();
  if (ext && key.length >= 3) html += `<div class="sp-ext" data-q="${esc(key)}">${S.extCache?.[key] ? extHtml(S.extCache[key], words) : extLoading()}</div>`;
  else if (ext) html += `<p class="sp-hint sp-ext-min">Jira und Confluence ab 3 Zeichen.</p>`;
  box.innerHTML = html;
  box.querySelector(".sp-item")?.classList.add("sel");
  if (ext && key.length >= 3 && !S.extCache?.[key]) S.extTimer = setTimeout(() => loadExt(key, words), 380);
}
function extLoading() {
  const row = `<span class="sp-skel" aria-hidden="true"><span class="sp-ico"></span><span class="sp-main"><i></i><i></i></span></span>`;
  return `<div class="sp-sec"><div class="sp-sec-h">Jira & Confluence <span class="sp-load"><i></i><i></i><i></i></span></div>${row}${row}</div>`;
}
async function loadExt(key, words) {
  let r;
  try { r = await api("/api/ext-search?q=" + encodeURIComponent(key)); } catch (e) { r = { configured: true, jira: { hits: [], error: e.message }, conf: { hits: [] } }; }
  S.extCache = S.extCache || {};
  S.extCache[key] = r;
  const slot = document.querySelector(`.sp-ext[data-q="${CSS.escape(key)}"]`);
  if (!slot) return;
  const hadSel = !!document.querySelector(".sp-res .sp-item.sel");
  slot.innerHTML = extHtml(r, words);
  slot.classList.add("in");
  if (!hadSel) slot.querySelector(".sp-item")?.classList.add("sel");
}
function extHtml(r, words) {
  if (!r?.configured) return "";
  const part = (label, res, kind) => {
    if (res?.error) return `<div class="sp-sec"><div class="sp-sec-h">${label}</div><p class="sp-hint sp-err">${esc(label)} ${esc(res.error)}</p></div>`;
    if (!res?.hits?.length) return `<div class="sp-sec"><div class="sp-sec-h">${label}</div><p class="sp-hint">Keine Treffer in ${label}.</p></div>`;
    return `<div class="sp-sec"><div class="sp-sec-h">${label}${res.openUrl ? `<a class="sp-all" href="${esc(res.openUrl)}" target="_blank" rel="noopener">${res.more ? "Alle Treffer" : "In " + label + " öffnen"} ${I.out}</a>` : ""}</div>${res.hits.map((h, j) => `<a class="sp-item t-${kind}" href="${esc(h.url)}" target="_blank" rel="noopener" style="--i:${j}"><span class="sp-ico">${kind === "jira" ? `<b class="sp-j">J</b>` : I.conf}</span><span class="sp-main"><span class="sp-title">${h.key ? `<span class="idf">${esc(h.key)}</span>` : ""}<span class="sp-t">${mark(h.title, words)}</span></span><span class="sp-sub">${mark([h.sub, h.snippet].filter(Boolean).join(" · ").slice(0, 150), words)}</span></span><span class="sp-go">${I.out}</span></a>`).join("")}</div>`;
  };
  return part("Jira", r.jira, "jira") + part("Confluence", r.conf, "conf");
}
function closeSearch(instant) {
  const sp = $(".sp");
  if (!sp) return;
  if (instant) return sp.remove();
  sp.classList.remove("in");
  setTimeout(() => sp.remove(), 180);
}
function focusChat() {
  closeSearch(true);
  const box = $("#cmd");
  if (box) { box.focus(); box.closest(".composer")?.classList.add("flash"); setTimeout(() => box.closest(".composer")?.classList.remove("flash"), 700); }
  else { location.hash = "#/"; setTimeout(() => $("#cmd")?.focus(), 300); }
}
document.addEventListener("keydown", (e) => {
  if ((e.metaKey || e.ctrlKey) && !e.shiftKey && !e.altKey) {
    const k = e.key.toLowerCase();
    if (k === "j") { e.preventDefault(); e.stopPropagation(); $(".sp") ? closeSearch() : openSearch(); return; }
    if (k === ".") { e.preventDefault(); e.stopPropagation(); openSearch(">"); return; }
    if (k === "k") { e.preventDefault(); e.stopPropagation(); focusChat(); return; }
  }
  if (e.key === "Escape" && $(".sp")) { e.stopPropagation(); closeSearch(); }
}, true);


// Treffer aus Jira und Confluence im Chat
function renderLinks(links, more = []) {
  const SHOW = 8;
  const card = (h, i) => `<a class="ext-card k-${h.kind}${i >= SHOW ? " ext-more" : ""}" href="${esc(h.url)}" target="_blank" rel="noopener" style="--i:${Math.min(i, SHOW)}">
    <span class="ext-ico">${h.kind === "jira" ? "J" : I.conf}</span>
    <span class="ext-main"><span class="ext-title">${h.key ? `<span class="idf">${esc(h.key)}</span>` : ""}${esc(h.title)}</span><span class="ext-sub">${esc(h.kind === "jira" ? "Jira" : "Confluence")}${h.sub ? " · " + esc(h.sub) : ""}</span>${h.snippet ? `<span class="ext-snip">${esc(h.snippet.slice(0, 180))}${h.snippet.length > 180 ? " …" : ""}</span>` : ""}</span>
    <span class="ext-go">${I.out}</span></a>`;
  return `<div class="ext-list${links.length > SHOW ? " clipped" : ""}">${links.map(card).join("")}</div>
    <div class="ext-actions">${links.length > SHOW ? `<button class="chip" data-act="ext-all">Alle ${links.length} Treffer zeigen</button>` : ""}${more.map((m) => `<a class="chip" href="${esc(m.url)}" target="_blank" rel="noopener">${esc(m.label)} ${I.out}</a>`).join("")}</div>`;
}
