// PO-TION Oberfläche · 13-timeline.js
// Klassische Skripte im gemeinsamen globalen Bereich, Reihenfolge laut ui/js (Dateiname). Start in 99-boot.js.
"use strict";
// ---------- Zeitstrahl der Meilensteine ----------
function openTimeline(focusId, quiet) {
  const p = S.project;
  if (!p?.timeline) return;
  const t = p.timeline;
  const DAY = 86400000;
  const ts = (d) => new Date(d + "T12:00:00").getTime();
  const dated = t.milestones.filter((m) => m.dateRaw);
  const points = [...dated.map((m) => ts(m.dateRaw)), ts(t.today)];
  if (t.start) points.push(ts(t.start));
  let min = Math.min(...points), max = Math.max(...points);
  const pad = Math.max(7 * DAY, (max - min) * 0.08);
  min -= pad; max += pad;
  const undated = t.milestones.filter((m) => !m.dateRaw);
  const span = undated.length ? 88 : 100; // rechts Platz für Meilensteine ohne Datum
  const pos = (d) => ((ts(d) - min) / (max - min)) * span;
  const todayPos = pos(t.today);
  // Monatsmarken
  const months = [];
  const c = new Date(min); c.setDate(1); c.setHours(12);
  while (c.getTime() <= max) {
    if (c.getTime() >= min) months.push({ x: ((c.getTime() - min) / (max - min)) * span, label: c.toLocaleDateString("de-DE", { month: "short", year: c.getMonth() === 0 ? "2-digit" : undefined }).replace(".", "") });
    c.setMonth(c.getMonth() + 1);
  }
  const nodes = t.milestones.map((m, i) => {
    const x = m.dateRaw ? pos(m.dateRaw) : span + ((undated.indexOf(m) + 1) / (undated.length + 1)) * (100 - span);
    return { ...m, x, up: i % 2 === 0 };
  });
  const stateLabel = { reached: "Erreicht", soon: "Bald", late: "Überfällig", planned: "Geplant" };
  const ring = (k) => ({ done: "ring done", wait: "ring wait", started: "ring half", vendor: "ring vendor", review: "ring review", open: "ring", backlog: "ring dim" })[k] || "ring";
  const taskRow = (i) => `<button class="tl-task ${i.kind === "done" ? "is-done" : ""}" data-open="${esc(i.identifier)}" draggable="true" data-drag="${esc(i.identifier)}" title="Ziehen, um den Meilenstein zu wechseln"><span class="${ring(i.kind)}"></span><span class="tl-task-main"><span class="tl-task-title">${esc(i.title)}</span><span class="tl-task-meta"><span class="idf">${esc(i.identifier)}</span>${i.meta ? `<span>${esc(i.meta)}</span>` : ""}</span></span></button>`;
  const cols = nodes.map((m, i) => `<section class="tl-col st-${m.state}" id="tlc-${esc(m.id)}" data-drop-ms="${esc(m.id)}" data-ms-name="${esc(m.name)}" style="--d:${0.5 + i * 0.08}s">
      <header><span class="tl-col-date">${esc(m.date)}</span><span class="tl-col-tag">${esc(m.tag)}</span></header>
      <h3 data-ms-link="${esc(m.id)}" title="Meilenstein öffnen">${esc(m.name)}</h3>
      <div class="tl-col-prog"><span class="tl-col-bar"><i style="width:${m.pct}%"></i></span><span>${m.done}/${m.total}</span></div>
      <div class="tl-tasks">${m.tasks.length ? m.tasks.map(taskRow).join("") : `<p class="muted tl-empty">Noch keine Aufgaben. Sag z. B. „Neue Aufgabe für ${esc(m.name)}: …“</p>`}</div>
    </section>`).join("") + (t.loose.length || t.milestones.length ? `<section class="tl-col st-loose" data-drop-ms="" data-ms-name="ohne Meilenstein" style="--d:${0.5 + nodes.length * 0.08}s"><header><span class="tl-col-date">ohne Meilenstein</span></header><h3>Weitere Aufgaben</h3><div class="tl-tasks">${t.loose.length ? t.loose.map(taskRow).join("") : `<p class="muted tl-empty">Hierher ziehen, um eine Aufgabe vom Meilenstein zu lösen.</p>`}</div></section>` : "");

  document.body.insertAdjacentHTML("beforeend", `<div class="tl${quiet ? " quiet in" : ""}" role="dialog" aria-modal="true" aria-label="Zeitstrahl ${esc(p.name)}">
    <div class="tl-panel">
      <header class="tl-head"><div><span class="kind-badge proj">${I.flag}Zeitstrahl</span><h2>${esc(p.name)}</h2></div><button class="dock-close" data-act="tl-close" aria-label="Schließen">${I.x}</button></header>
      <div class="tl-track-wrap"><div class="tl-track">
        ${months.map((mo) => `<span class="tl-month" style="left:${mo.x}%">${esc(mo.label)}</span>`).join("")}
        <span class="tl-line"></span>
        <span class="tl-past" style="width:${Math.max(0, Math.min(100, todayPos))}%"></span>
        <span class="tl-today" style="left:${todayPos}%"><b>Heute</b></span>
        ${undated.length ? `<span class="tl-undated" style="left:${span}%">ohne Datum</span>` : ""}
        ${nodes.map((m, i) => `<button class="tl-node st-${m.state} ${m.up ? "up" : "down"}" style="left:${m.x}%;--d:${0.35 + i * 0.12}s" data-tl-focus="${esc(m.id)}" aria-label="${esc(m.name)}, ${esc(m.date)}, ${stateLabel[m.state]}">
          <span class="tl-dot"><svg class="pr" viewBox="0 0 36 36" aria-hidden="true"><circle class="bg" cx="18" cy="18" r="15"/><circle class="fg" cx="18" cy="18" r="15" style="stroke-dasharray:${(m.pct / 100) * 94.2} 94.2"/></svg>${m.state === "reached" ? I.check("currentColor", 12) : ""}</span>
          <span class="tl-label"><b>${esc(m.name)}</b><small>${esc(m.date)} · ${m.done}/${m.total}</small></span>
        </button>`).join("")}
      </div></div>
      <div class="tl-cols">${cols}</div>
    </div>
  </div>`);
  requestAnimationFrame(() => document.querySelector(".tl")?.classList.add("in"));
  if (focusId) setTimeout(() => focusTimeline(focusId), 650);
}
function focusTimeline(id) {
  document.querySelectorAll(".tl-col.focus, .tl-node.focus").forEach((x) => x.classList.remove("focus"));
  const col = document.getElementById("tlc-" + id);
  const node = document.querySelector(`.tl-node[data-tl-focus="${CSS.escape(id)}"]`);
  node?.classList.add("focus");
  if (col) { col.classList.add("focus"); col.scrollIntoView({ behavior: "smooth", inline: "center", block: "nearest" }); }
}
function closeTimeline(instant) {
  const tl = document.querySelector(".tl");
  if (!tl) return;
  if (TLD.dirty && !instant) { TLD.dirty = false; setTimeout(() => S.project && openProject(S.project.id), 270); }
  if (instant) return tl.remove();
  tl.classList.remove("in");
  tl.classList.add("out");
  setTimeout(() => tl.remove(), 260);
}
// Aufgaben im Zeitstrahl zwischen Meilensteinen ziehen
const TLD = { id: null, from: null, dirty: false };
document.addEventListener("dragstart", (e) => {
  const t = e.target.closest?.("[data-drag]");
  if (!t || !t.closest(".tl")) return;
  TLD.id = t.dataset.drag; TLD.from = t.closest("[data-drop-ms]")?.dataset.dropMs ?? null; TLD.fromName = t.closest("[data-drop-ms]")?.dataset.msName || "";
  e.dataTransfer.effectAllowed = "move";
  e.dataTransfer.setData("text/plain", TLD.id);
  t.classList.add("dragging");
  document.querySelector(".tl")?.classList.add("is-dragging");
});
document.addEventListener("dragend", () => {
  document.querySelectorAll(".tl .dragging").forEach((x) => x.classList.remove("dragging"));
  document.querySelectorAll(".tl-col.drop-over").forEach((x) => x.classList.remove("drop-over"));
  document.querySelector(".tl")?.classList.remove("is-dragging");
});
document.addEventListener("dragover", (e) => {
  if (!TLD.id) return;
  const col = e.target.closest?.(".tl [data-drop-ms]");
  document.querySelectorAll(".tl-col.drop-over").forEach((x) => x !== col && x.classList.remove("drop-over"));
  if (!col || col.dataset.dropMs === TLD.from) return;
  e.preventDefault(); e.dataTransfer.dropEffect = "move";
  col.classList.add("drop-over");
});
document.addEventListener("drop", async (e) => {
  const col = e.target.closest?.(".tl [data-drop-ms]");
  const id = TLD.id; TLD.id = null;
  if (!col || !id || col.dataset.dropMs === TLD.from) return;
  e.preventDefault();
  col.classList.remove("drop-over");
  const card = document.querySelector(`.tl [data-drag="${CSS.escape(id)}"]`);
  const list = col.querySelector(".tl-tasks");
  list.querySelector(".tl-empty")?.remove();
  if (card) list.prepend(card);
  const scroll = document.querySelector(".tl-cols")?.scrollLeft || 0;
  try {
    await api("/api/issues/" + encodeURIComponent(id), { method: "PATCH", body: { milestoneId: col.dataset.dropMs || null } });
    TLD.dirty = true; S.home = null;
    S.project = await api("/api/projects/" + encodeURIComponent(S.project.id));
    closeTimeline(true); openTimeline(null, true);
    const cols = document.querySelector(".tl-cols"); if (cols) cols.scrollLeft = scroll;
    document.querySelector(`.tl [data-drag="${CSS.escape(id)}"]`)?.classList.add("just-moved");
    const back = TLD.from, backName = TLD.fromName;
    toast(`${id} → ${col.dataset.msName}`, { undo: () => api("/api/issues/" + encodeURIComponent(id), { method: "PATCH", body: { milestoneId: back || null } }), undoLabel: `${id} zurück nach „${backName}“` });
  } catch (x) {
    toast(x.message);
    S.project = await api("/api/projects/" + encodeURIComponent(S.project.id)).catch(() => S.project);
    closeTimeline(true); openTimeline(null, true);
  }
});
document.addEventListener("keydown", (e) => { if (e.key === "Escape" && document.querySelector(".tl")) { e.stopPropagation(); closeTimeline(); } }, true);


// ---------- Token-Zähler ----------
const PRICE = { in: 0.10, out: 0.50 }; // Claude Haiku 5.5, USD je 1 Mio. Token (Prompts unter 100K)
const fmtTok = (n) => (n >= 1e6 ? (n / 1e6).toFixed(1).replace(".", ",") + " Mio." : n >= 1e4 ? Math.round(n / 1e3) + " Tsd." : n.toLocaleString("de-DE"));
async function loadUsage() {
  const box = $("#usage-box");
  if (!box) return;
  let u;
  try { u = await api("/api/usage"); } catch (e) { box.innerHTML = `<p class="err" style="padding:20px">${esc(e.message)}</p>`; return; }
  // Vergleich: was dieselben Token bei Claude Haiku 5.5 über die API gekostet hätten (0,10 $ / 0,50 $ je Mio. Ein-/Ausgabe)
  const usd = (x) => (x.p / 1e6) * PRICE.in + (x.c / 1e6) * PRICE.out;
  const money = (v) => v < 0.01 ? "< 0,01 $" : v.toLocaleString("de-DE", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " $";
  const tile = (label, x, sub) => `<div class="u-tile"><span class="u-label">${label}</span><b class="u-num">${fmtTok(x.p + x.c)}</b><span class="u-sub">${sub ?? `${fmtTok(x.p)} gelesen · ${fmtTok(x.c)} geschrieben`}</span><span class="u-sub">${x.n} ${x.n === 1 ? "Anfrage" : "Anfragen"}</span><span class="u-save" title="So viel hätten diese Token über die Claude-API (Haiku 5.5) gekostet">gespart ≈ ${money(usd(x))}</span></div>`;
  const speed = u.total.ms ? Math.round(u.total.c / (u.total.ms / 1000)) : 0;
  const maxDay = Math.max(1, ...u.days.map((d) => d.p + d.c));
  const H = 120;
  const bars = u.days.map((d, i) => {
    const hp = Math.round((d.p / maxDay) * H), hc = Math.round((d.c / maxDay) * H);
    const day = new Date(d.date + "T12:00:00");
    const lab = i % 2 === 1 || i === 13 ? day.toLocaleDateString("de-DE", { day: "numeric", month: "numeric" }) : "";
    const tip = `${day.toLocaleDateString("de-DE", { weekday: "short", day: "numeric", month: "numeric" })}: ${fmtTok(d.p)} gelesen, ${fmtTok(d.c)} geschrieben, ${d.n} Anfragen`;
    return `<div class="u-day" tabindex="0" title="${esc(tip)}" aria-label="${esc(tip)}"><div class="u-stack" style="height:${H}px">${hc ? `<span class="u-c" style="height:${hc}px"></span>` : ""}${hp ? `<span class="u-p" style="height:${hp}px"></span>` : ""}</div><span class="u-x">${lab}</span></div>`;
  }).join("");
  const models = Object.entries(u.models).map(([k, v]) => `<span>${k === "8b" ? "Genau (8B)" : "Schnell (4B)"}: <b>${fmtTok(v.p + v.c)}</b> in ${v.n} Anfragen</span>`).join("");
  box.innerHTML = `<div class="u-tiles">${tile("Heute", u.today)}${tile("Letzte 7 Tage", u.week)}${tile("Insgesamt", u.total)}</div>
    <div class="u-chart"><div class="u-chart-head"><span>Letzte 14 Tage</span><span class="u-legend"><span><i class="u-p"></i>Gelesen</span><span><i class="u-c"></i>Geschrieben</span></span></div>
      <div class="u-bars" role="img" aria-label="Token pro Tag, letzte 14 Tage">${bars}</div></div>
    <div class="u-compare">
      <div><b>Vergleichbar mit Claude Haiku</b><span>Qwen3 4B und 8B spielen in der Klasse der kleinen, schnellen Modelle, am ehesten vergleichbar mit Claude Haiku. Haiku ist dabei spürbar stärker, für Aufgaben sortieren, kurze Zusammenfassungen und Rückfragen reicht das lokale Modell.</span></div>
      <div><b>Gespart bisher ≈ ${money(usd(u.total))}</b><span>Gerechnet mit den API-Preisen von Claude Haiku 5.5 (0,10 $ je Mio. Eingabe-, 0,50 $ je Mio. Ausgabe-Token, Stand Oktober 2026). Ein Claude-Pro-Abo kostet rund 20 $ im Monat; für diese Aufgaben brauchst du keins, PO-TION läuft komplett auf deinem Mac.</span></div>
    </div>
    <div class="u-foot">${speed ? `<span>Ø Schreibtempo: <b>${speed} Token/s</b></span>` : ""}${models}${u.since ? `<span class="muted">gezählt seit ${new Date(u.since + "T12:00:00").toLocaleDateString("de-DE")}</span>` : `<span class="muted">Noch nichts gezählt. Stell PO-TION eine Frage, dann geht es los.</span>`}</div>`;
}
