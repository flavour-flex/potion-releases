// PO-TION Oberfläche · 18-jira-write.js
// Klassische Skripte im gemeinsamen globalen Bereich, Reihenfolge laut ui/js (Dateiname). Start in 99-boot.js.
"use strict";
// ================= Jira ändern: immer nur nach Rückfrage =================
let jiraAskT;
function jiraAskSoon() { clearTimeout(jiraAskT); jiraAskT = setTimeout(checkJiraAsks, 450); }
async function checkJiraAsks() {
  let r;
  try { r = await api("/api/jira/asks"); } catch { return; }
  const box = $("#jira-ask");
  if (!r.asks.length) { box?.remove(); return; }
  const html = r.asks.map((a) => `<div class="ja-item" data-ja="${esc(a.identifier)}">
      <p class="ja-q"><b>${esc(a.identifier)}</b> steht jetzt auf „${esc(a.state)}“. Auch in Jira ändern?</p>
      ${a.items.map((it) => `<div class="ja-row" data-ja-key="${esc(it.key)}">
        <a class="jira-key" href="${esc(it.url)}" target="_blank" rel="noopener">${esc(it.key)} ${I.out}</a>
        <span class="jira-badge">${esc(it.status)}</span><span class="muted">→</span>
        <select class="ja-sel" aria-label="Neuer Jira-Status für ${esc(it.key)}">${it.suggested ? "" : `<option value="">Status wählen …</option>`}${it.transitions.map((t) => `<option value="${esc(t.id)}" ${t.id === it.suggested ? "selected" : ""}>${esc(t.to)}${t.name !== t.to ? ` (${esc(t.name)})` : ""}</option>`).join("")}</select>
        <button class="btn small primary" data-ja-go>In Jira ändern</button>
      </div>`).join("")}
      <div class="ja-foot"><button class="linkbtn" data-ja-no>Nein, Jira so lassen</button></div>
    </div>`).join("");
  if (box) box.querySelector(".ja-body").innerHTML = html;
  else document.body.insertAdjacentHTML("beforeend", `<div id="jira-ask" class="jira-ask" role="dialog" aria-label="Jira anpassen?"><div class="ja-head"><span class="kind-badge">Jira</span><span class="muted">PO-TION ändert Jira nur, wenn du klickst.</span><button class="tu-x" data-ja-close aria-label="Schließen">${I.x}</button></div><div class="ja-body">${html}</div></div>`);
}
async function jiraTransition(key, body, identifier) {
  const r = await api(`/api/jira/issue/${encodeURIComponent(key)}/transition`, { method: "POST", body: { ...body, identifier, confirmed: true } });
  toastJira(r.message, r.undo ? async () => { await api(`/api/jira/issue/${encodeURIComponent(key)}/transition`, { method: "POST", body: { to: r.undo.to, identifier, confirmed: true } }); } : null);
  refreshJiraDetail();
  return r;
}
function toastJira(msg, undoFn) { toast(msg, { undo: undoFn }); }
function refreshJiraDetail() { if (S.view === "detail" && S.detail) openDetail(S.detail.identifier); }
function jwClose() { document.querySelector(".jw-pop")?.remove(); }
document.addEventListener("click", async (e) => {
  const go = e.target.closest("[data-ja-go]");
  if (go) {
    const row = go.closest("[data-ja-key]"), item = go.closest("[data-ja]"), id = row.querySelector(".ja-sel").value;
    if (!id) { toast("Bitte erst den neuen Jira-Status wählen."); return; }
    go.disabled = true; go.textContent = "Ändere …";
    try { await jiraTransition(row.dataset.jaKey, { id }, item.dataset.ja); row.remove(); if (!item.querySelector("[data-ja-key]")) { item.remove(); if (!document.querySelector("#jira-ask .ja-item")) $("#jira-ask")?.remove(); } }
    catch (x) { toast(x.message); go.disabled = false; go.textContent = "In Jira ändern"; }
    return;
  }
  const no = e.target.closest("[data-ja-no]");
  if (no) { const item = no.closest("[data-ja]"); await api("/api/jira/asks/dismiss", { method: "POST", body: { identifier: item.dataset.ja } }).catch(() => {}); item.remove(); if (!document.querySelector("#jira-ask .ja-item")) $("#jira-ask")?.remove(); return; }
  if (e.target.closest("[data-ja-close]")) { await api("/api/jira/asks/dismiss", { method: "POST", body: {} }).catch(() => {}); $("#jira-ask")?.remove(); return; }

  // Jira-Karte in der Aufgabe: Status ändern
  const st = e.target.closest("[data-jw-status]");
  if (st) {
    e.stopPropagation(); jwClose();
    const key = st.dataset.jwStatus;
    st.closest(".jw-row").insertAdjacentHTML("afterend", `<div class="jw-pop" data-jw-key="${esc(key)}"><p class="muted">Lade Statuswechsel …</p></div>`);
    const pop = $(".jw-pop");
    try {
      const r = await api(`/api/jira/issue/${encodeURIComponent(key)}/transitions`);
      pop.innerHTML = r.transitions.length ? `<p class="jw-h">Neuer Status in Jira</p>${r.transitions.map((t) => `<button class="jw-opt" data-jw-t="${esc(t.id)}" data-jw-to="${esc(t.to)}"><span class="jw-cat c-${esc(t.category)}"></span>${esc(t.to)}${t.name !== t.to ? `<small>${esc(t.name)}</small>` : ""}</button>`).join("")}<div class="jw-confirm" hidden></div>` : `<p class="muted">Von hier aus erlaubt Jira keinen Statuswechsel.</p>`;
    } catch (x) { pop.innerHTML = `<p class="hot">${esc(x.message)}</p>`; }
    return;
  }
  const opt = e.target.closest("[data-jw-t]");
  if (opt) {
    const pop = opt.closest(".jw-pop"), c = pop.querySelector(".jw-confirm");
    pop.querySelectorAll(".jw-opt.sel").forEach((x) => x.classList.remove("sel")); opt.classList.add("sel");
    c.hidden = false;
    c.innerHTML = `<span>${esc(pop.dataset.jwKey)} in Jira auf „${esc(opt.dataset.jwTo)}“ setzen?</span><button class="btn small primary" data-jw-do-t="${esc(opt.dataset.jwT)}">Ja, in Jira ändern</button><button class="linkbtn" data-jw-cancel>Abbrechen</button>`;
    return;
  }
  const dot = e.target.closest("[data-jw-do-t]");
  if (dot) { dot.disabled = true; try { await jiraTransition(dot.closest(".jw-pop").dataset.jwKey, { id: dot.dataset.jwDoT }, S.detail?.identifier); } catch (x) { toast(x.message); dot.disabled = false; } return; }
  if (e.target.closest("[data-jw-cancel]")) { jwClose(); return; }

  // Bearbeiter ändern
  const as = e.target.closest("[data-jw-assign]");
  if (as) {
    e.stopPropagation(); jwClose();
    const key = as.dataset.jwAssign;
    as.closest(".jw-row").insertAdjacentHTML("afterend", `<div class="jw-pop" data-jw-key="${esc(key)}"><p class="jw-h">Bearbeiter in Jira</p><label class="cap-q cm-q">${I.search}<input class="jw-q" placeholder="Name suchen …" autocomplete="off"></label><div class="jw-users"><p class="muted">Lade …</p></div><div class="jw-confirm" hidden></div></div>`);
    const pop = $(".jw-pop"), q = pop.querySelector(".jw-q");
    let seq = 0;
    const load = async () => {
      const my = ++seq;
      try {
        const r = await api(`/api/jira/issue/${encodeURIComponent(key)}/assignable?q=${encodeURIComponent(q.value.trim())}`);
        if (my !== seq) return;
        pop.querySelector(".jw-users").innerHTML = (r.users.length ? r.users.map((u) => `<button class="jw-opt" data-jw-u="${esc(u.accountId)}" data-jw-name="${esc(u.name)}">${u.avatar ? `<img src="${esc(u.avatar)}" alt="" width="18" height="18">` : `<span class="jw-av">${esc(u.name.slice(0, 1))}</span>`}${esc(u.name)}${u.email ? `<small>${esc(u.email)}</small>` : ""}</button>`).join("") : `<p class="muted">Niemand gefunden, der das Ticket übernehmen darf.</p>`) + `<button class="jw-opt" data-jw-u="" data-jw-name="niemand"><span class="jw-av">–</span>Niemand zuweisen</button>`;
      } catch (x) { pop.querySelector(".jw-users").innerHTML = `<p class="hot">${esc(x.message)}</p>`; }
    };
    let t; q.addEventListener("input", () => { clearTimeout(t); t = setTimeout(load, 250); });
    q.focus(); load();
    return;
  }
  const uo = e.target.closest("[data-jw-u]");
  if (uo) {
    const pop = uo.closest(".jw-pop"), c = pop.querySelector(".jw-confirm");
    pop.querySelectorAll(".jw-opt.sel").forEach((x) => x.classList.remove("sel")); uo.classList.add("sel");
    c.hidden = false;
    c.innerHTML = `<span>${esc(pop.dataset.jwKey)} in Jira ${uo.dataset.jwU ? `${esc(uo.dataset.jwName)} zuweisen` : "ohne Bearbeiter lassen"}?</span><button class="btn small primary" data-jw-do-u="${esc(uo.dataset.jwU)}">Ja, in Jira ändern</button><button class="linkbtn" data-jw-cancel>Abbrechen</button>`;
    return;
  }
  const du = e.target.closest("[data-jw-do-u]");
  if (du) {
    du.disabled = true;
    try {
      const key = du.closest(".jw-pop").dataset.jwKey, ident = S.detail?.identifier;
      const r = await api(`/api/jira/issue/${encodeURIComponent(key)}/assignee`, { method: "POST", body: { accountId: du.dataset.jwDoU || null, identifier: ident, confirmed: true } });
      toast(r.message, { undo: r.undo ? () => api(`/api/jira/issue/${encodeURIComponent(key)}/assignee`, { method: "POST", body: { accountId: r.undo.accountId, identifier: ident, confirmed: true } }) : null, undoLabel: `Bearbeiter von ${key}` });
      refreshJiraDetail();
    }
    catch (x) { toast(x.message); du.disabled = false; }
    return;
  }
});
