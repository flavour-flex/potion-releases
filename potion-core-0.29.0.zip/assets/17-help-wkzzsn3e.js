// PO-TION Oberfläche · 17-help.js
// Klassische Skripte im gemeinsamen globalen Bereich, Reihenfolge laut ui/js (Dateiname). Start in 99-boot.js.
"use strict";
// ---------- Hilfe & FAQ ----------
function faqText(t) {
  const key = (S.home?.next?.[0]?.identifier || S.searchIndex?.items?.find((x) => x.t === "task")?.id || "CHR-1").split("-")[0];
  return t.replace(/\{K\}/g, key).replace(/\{MOD\}/g, MOD.trim() || "⌘");
}
function faqHtml(a) {
  const inline = (x) => esc(x).replace(/`([^`]+)`/g, "<code>$1</code>").replace(/\*\*([^*]+)\*\*/g, "<b>$1</b>");
  return faqText(a).trim().split(/\n\s*\n/).map((block) => {
    const lines = block.split("\n");
    if (lines.every((l) => /^- /.test(l))) return `<ul>${lines.map((l) => `<li>${inline(l.slice(2))}</li>`).join("")}</ul>`;
    const head = lines.filter((l) => !/^- /.test(l)), list = lines.filter((l) => /^- /.test(l));
    return (head.length ? `<p>${inline(head.join(" "))}</p>` : "") + (list.length ? `<ul>${list.map((l) => `<li>${inline(l.slice(2))}</li>`).join("")}</ul>` : "");
  }).join("");
}
function renderHelp() {
  S.view = "help";
  setViewTheme("help");
  renderDock();
  const cats = window.POTION_FAQ || [];
  const open = decodeURIComponent((location.hash.split("/")[2] || ""));
  app.innerHTML = topbar() + `<main class="help">
    <header class="help-head"><span class="kind-badge proj">${I.help}Hilfe</span><h1>Wie funktioniert PO-TION?</h1><button class="btn small in-again" data-act="intro">${I.spark}Einführung ansehen</button>
      <label class="help-search">${I.search}<input id="faq-q" placeholder="Frage eintippen, z. B. „Meilenstein“ oder „Jira“" autocomplete="off"></label>
      <div class="help-quick">${["Was kann ich in den Chat schreiben?", "Wann Aufgabe, wann Meilenstein?", "Wo liegen meine Daten?", "Welche Tastenkürzel gibt es?"].map((q) => `<button class="chip" data-faq-jump="${esc(q)}">${esc(q)}</button>`).join("")}</div>
    </header>
    <div class="help-layout">
      <nav class="set-nav help-nav" aria-label="Themen">${cats.map((c) => `<a href="#/hilfe/${c.id}" data-scroll="faq-${c.id}"><span class="hn-ico">${c.icon}</span>${esc(c.title)}</a>`).join("")}</nav>
      <div class="help-main" id="faq-list">${cats.map((c, ci) => `<section class="faq-sec" id="faq-${c.id}" style="--i:${ci}"><h2><span class="hn-ico">${c.icon}</span>${esc(c.title)}</h2>
        ${c.items.map((it, k) => `<details class="faq" id="faq-${c.id}-${k}" data-text="${esc((it.q + " " + it.a).toLowerCase())}"><summary><span>${esc(faqText(it.q))}</span><i aria-hidden="true">${I.plus}</i></summary><div class="faq-a">${faqHtml(it.a)}</div></details>`).join("")}
      </section>`).join("")}
        <p class="muted faq-none" hidden>Dazu habe ich keinen Eintrag. <button class="linkbtn" data-act="faq-ask">Frag stattdessen PO-TION im Chat</button></p>
        <section class="faq-more"><b>Nicht gefunden?</b><span>Frag PO-TION direkt im Chat (\`${MOD.trim()}K\`), zum Beispiel „Wie verschiebe ich einen Meilenstein?“. Oder schau ins Protokoll unter <code>~/Library/Application Support/crxs</code>.</span></section>
      </div>
    </div>
  </main>`;
  const q = $("#faq-q");
  q.addEventListener("input", () => filterFaq(q.value));
  const target = open && document.getElementById("faq-" + open);
  if (target?.tagName === "DETAILS") {
    target.open = true;
    setTimeout(() => { target.scrollIntoView({ behavior: "smooth", block: "center" }); target.classList.add("flash"); setTimeout(() => target.classList.remove("flash"), 1400); }, 60);
  } else {
    if (target) setTimeout(() => target.scrollIntoView({ behavior: "smooth", block: "start" }), 50);
    q.focus();
  }
}
function filterFaq(v) {
  const words = v.toLowerCase().trim().split(/\s+/).filter(Boolean);
  let shown = 0;
  document.querySelectorAll(".faq").forEach((d) => {
    const hit = !words.length || words.every((w) => d.dataset.text.includes(w));
    d.hidden = !hit;
    if (hit) shown++;
    if (words.length && hit && shown <= 2) d.open = true;
    if (!words.length) d.open = false;
  });
  document.querySelectorAll(".faq-sec").forEach((sec) => (sec.hidden = ![...sec.querySelectorAll(".faq")].some((d) => !d.hidden)));
  $(".faq-none").hidden = shown > 0;
}
document.addEventListener("click", (e) => {
  const fq = e.target.closest("[data-sp-faq]");
  if (fq) { closeSearch(true); const h = "#/hilfe/" + fq.dataset.spFaq; if (location.hash === h) renderHelp(); else location.hash = h; return; }
  const j = e.target.closest("[data-faq-jump]");
  if (j) {
    const d = [...document.querySelectorAll(".faq")].find((x) => x.querySelector("summary span").textContent === j.dataset.faqJump);
    if (d) { d.open = true; d.scrollIntoView({ behavior: "smooth", block: "center" }); d.classList.add("flash"); setTimeout(() => d.classList.remove("flash"), 1200); }
  }
  if (e.target.closest("[data-act=faq-ask]")) { const v = $("#faq-q")?.value || ""; location.hash = "#/"; setTimeout(() => { const c = $("#cmd"); if (c) { c.value = v; c.focus(); } }, 400); }
});
window.addEventListener("hashchange", () => closeMore());

// Startseite: Höhe zwischen „Als Nächstes“ und Chat verschiebbar (Standard: 3 Aufgaben)
const HSPLIT_KEY = "potion.homeGridH";
function homeGridDefault() {
  const grid = $(".home-top .grid"), panel = $(".next-panel");
  if (!grid || !panel) return 0;
  const rows = [...panel.querySelectorAll(".row")].slice(0, 3);
  const rowsH = rows.length ? rows.reduce((a, r) => a + r.offsetHeight, 0) : 80;
  return panel.offsetTop - grid.offsetTop + rowsH + 2;
}
function homeGridMax() {
  const grid = $(".home-top .grid"), chat = $(".home-chat");
  if (!grid || !chat) return 600;
  return grid.offsetHeight + Math.max(0, chat.clientHeight - 120);
}
function sizeHomeGrid(px) {
  const grid = $(".home-top .grid");
  if (!grid || window.innerWidth <= 860) { if (grid) grid.style.height = ""; return; }
  let h = px;
  if (h == null) { try { h = Number(localStorage.getItem(HSPLIT_KEY)) || 0; } catch { h = 0; } }
  const min = Math.min(homeGridDefault(), 160);
  if (!h) h = homeGridDefault();
  grid.style.height = Math.round(Math.max(min, Math.min(h, homeGridMax()))) + "px";
}
document.addEventListener("pointerdown", (e) => {
  const sp = e.target.closest(".home-split");
  if (!sp) return;
  const grid = $(".home-top .grid");
  if (!grid) return;
  e.preventDefault();
  const y0 = e.clientY, h0 = grid.offsetHeight;
  sp.setPointerCapture(e.pointerId);
  document.body.classList.add("splitting");
  const move = (ev) => { sizeHomeGrid(h0 + ev.clientY - y0); };
  const up = () => {
    sp.removeEventListener("pointermove", move); sp.removeEventListener("pointerup", up); sp.removeEventListener("pointercancel", up);
    document.body.classList.remove("splitting");
    try { localStorage.setItem(HSPLIT_KEY, String(grid.offsetHeight)); } catch {}
    scrollThread();
  };
  sp.addEventListener("pointermove", move); sp.addEventListener("pointerup", up); sp.addEventListener("pointercancel", up);
});
document.addEventListener("dblclick", (e) => {
  if (!e.target.closest(".home-split")) return;
  try { localStorage.removeItem(HSPLIT_KEY); } catch {}
  sizeHomeGrid();
});
window.addEventListener("resize", () => { if (S.view === "home") sizeHomeGrid(); });
